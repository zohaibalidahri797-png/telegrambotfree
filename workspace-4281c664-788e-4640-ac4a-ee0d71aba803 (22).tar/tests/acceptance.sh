#!/usr/bin/env bash
# BotDock Cloud — 22-step acceptance test (master-prompt §22).
# Run against a FRESH database (bun run db:reset) for full bootstrap coverage.
# Phase A (this script): steps 1-17, 19, 20. Step 18 (persistence across app
# restart) is verified by tests/acceptance-phase2.sh after restarting the app.
set -u
BASE="http://localhost:3000"
PASS=0; FAIL=0
TD=/home/z/my-project/tests/tmp
mkdir -p "$TD"
JA="$TD/acc-a.jar"; JB="$TD/acc-b.jar"
rm -f "$JA" "$JB"

check() { # step name expected actual
  if echo "$3" | grep -q "$2"; then echo "PASS  [$1] $2"; PASS=$((PASS+1));
  else echo "FAIL  [$1] expected: $2"; echo "      actual: $(echo "$3" | head -c 400)"; FAIL=$((FAIL+1)); fi
}
step() { echo ""; echo "--- STEP $1: $2 ---"; }

TS=$(date +%s)
UA="owner${TS}@accept.test"; UB="other${TS}@accept.test"; PW="Acceptance-Pass-9!"
BTK=$(grep -E '^ADMIN_BOOTSTRAP_TOKEN=' /home/z/my-project/.env | cut -d'"' -f2)
IPA="10.78.$((RANDOM % 200 + 10)).$((RANDOM % 200 + 10))"
IPB="10.78.$((RANDOM % 200 + 10)).$((RANDOM % 200 + 10))"

step 1 "A new user can register (first account with operator bootstrap token)"
R=$(curl -s -c "$JA" -X POST "$BASE/api/auth/register" -H 'Content-Type: application/json' -H "X-Forwarded-For: $IPA" \
  -d "{\"email\":\"$UA\",\"password\":\"$PW\",\"name\":\"Owner\",\"bootstrapToken\":\"$BTK\"}")
check "1" '"ok":true' "$R"
# Deploy requires a verified e-mail (honest product gate) — verify via the dev
# link (DEV_SHOW_EMAIL_LINKS=true, dev only; production sends it by e-mail).
VL=$(echo "$R" | grep -o '"devVerificationLink":"[^"]*"' | head -1 | cut -d'"' -f4)
if [ -n "$VL" ]; then curl -s -b "$JA" -c "$JA" "$BASE$VL" -o /dev/null; MEV=$(curl -s -b "$JA" "$BASE/api/auth/me" | grep -o '"emailVerified":[a-z]*');
  check "1b email verified (deploy gate precondition)" '"emailVerified":true' "$MEV";
else echo "FAIL  [1b] no dev verification link (set DEV_SHOW_EMAIL_LINKS=true in dev)"; FAIL=$((FAIL+1)); fi

step 2 "User can log in and log out"
L=$(curl -s -c "$JA" -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' -H "X-Forwarded-For: $IPA" -d "{\"email\":\"$UA\",\"password\":\"$PW\"}")
check "2a login" '"ok":true' "$L"
O=$(curl -s -b "$JA" -c "$JA" -X POST "$BASE/api/auth/logout")
M=$(curl -s -b "$JA" "$BASE/api/auth/me")
check "2b logout revokes" 'authentication_required' "$M"
curl -s -c "$JA" -X POST "$BASE/api/auth/login" -H 'Content-Type: application/json' -H "X-Forwarded-For: $IPA" -d "{\"email\":\"$UA\",\"password\":\"$PW\"}" > /dev/null

step 3 "Session persists appropriately (cookie reuse across requests)"
ME=$(curl -s -b "$JA" "$BASE/api/auth/me")
check "3" "\"$UA\"" "$ME"

step 4 "User can create a bot project (template)"
B=$(curl -s -b "$JA" -X POST "$BASE/api/bots" -H 'Content-Type: application/json' \
  -d '{"name":"acc-tpl","runtime":"PYTHON","sourceType":"TEMPLATE","templateId":"python-keepalive"}')
check "4" '"ok":true' "$B"
BID=$(echo "$B" | grep -o '"id":"[^"]*"' | head -1 | cut -d'"' -f4)

step 5 "User can upload a valid ZIP archive"
python3 -c "
import zipfile
z = zipfile.ZipFile('$TD/acc.zip','w')
z.writestr('main.py','import os,time,sys\nprint(\"ACC-BOT-READY\", flush=True)\nwhile True: time.sleep(1)\n')
z.close()"
UZ=$(curl -s -b "$JA" -X POST "$BASE/api/bots/upload" -F "name=acc-zip" -F "runtime=PYTHON" -F "file=@$TD/acc.zip;type=application/zip")
check "5" '"ok":true' "$UZ"

step 6 "Platform validates and stores the project (workspace contains extracted files)"
ZID=$(echo "$UZ" | grep -o '"id":"[^"]*"' | head -1 | cut -d'"' -f4)
FL=$(curl -s -b "$JA" "$BASE/api/bots/$ZID/files")
check "6" 'main.py' "$FL"

step 7 "User can configure a test environment variable"
EV=$(curl -s -b "$JA" -X PUT "$BASE/api/bots/$BID/env" -H 'Content-Type: application/json' -d '{"key":"ACC_TEST_TOKEN","value":"s3cret-value","isSecret":true}')
check "7a env saved (secret not echoed)" '"ok":true' "$EV"
if echo "$EV" | grep -q 's3cret-value'; then echo "FAIL  [7b] SECRET VALUE ECHOED TO BROWSER"; FAIL=$((FAIL+1)); else echo "PASS  [7b] secret value not returned after save"; PASS=$((PASS+1)); fi
EV2=$(curl -s -b "$JA" "$BASE/api/bots/$BID/env")
if echo "$EV2" | grep -q 's3cret-value'; then echo "FAIL  [7c] SECRET VALUE RETURNED BY GET"; FAIL=$((FAIL+1)); else echo "PASS  [7c] GET env returns masked preview only"; PASS=$((PASS+1)); fi

step 8 "Platform builds/prepares the project (install phase recorded)"
D=$(curl -s -b "$JA" -X POST "$BASE/api/bots/$BID/action" -H 'Content-Type: application/json' -d '{"action":"deploy"}')
check "8" '"ok":true' "$D"

step 9 "Runtime starts a harmless test bot"
sleep 4
ST=$(curl -s -b "$JA" "$BASE/api/bots/$BID")
check "9" 'RUNNING' "$ST"

step 10 "Dashboard reports the actual process state (status endpoint, not inferred)"
check "10a runtime state RUNNING from live process" '"state":"RUNNING"' "$ST"
check "10b real pid present" '"pid":' "$ST"

step 11 "Dashboard displays real runtime logs"
LG=$(curl -s -b "$JA" "$BASE/api/bots/$BID/logs")
check "11a logs endpoint responds (runtime kind)" '"kind":"runtime"' "$LG"
check "11b log content is our real bot output (non-empty)" 'ACC-BOT-READY\|keepalive\|starting\|heartbeat' "$LG"

step 12 "A deliberate startup failure is reported truthfully"
python3 -c "
import zipfile
z = zipfile.ZipFile('$TD/acc-fail.zip','w'); z.writestr('main.py','import sys\nprint(\"about to die\", flush=True)\nsys.exit(7)\n'); z.close()"
UF=$(curl -s -b "$JA" -X POST "$BASE/api/bots/upload" -F "name=acc-fail" -F "runtime=PYTHON" -F "file=@$TD/acc-fail.zip")
FID=$(echo "$UF" | grep -o '"id":"[^"]*"' | head -1 | cut -d'"' -f4)
DF=$(curl -s -b "$JA" -X POST "$BASE/api/bots/$FID/action" -H 'Content-Type: application/json' -d '{"action":"deploy"}')
check "12a deploy response reports failure" '"ok":false\|start_error\|FAILED' "$DF"
SFS=$(curl -s -b "$JA" "$BASE/api/bots/$FID")
check "12b bot state FAILED (not RUNNING)" '"status":"FAILED"' "$SFS"
curl -s -b "$JA" -X DELETE "$BASE/api/bots/$FID" -o /dev/null

step 13 "User can stop the running process"
SP=$(curl -s -b "$JA" -X POST "$BASE/api/bots/$BID/action" -H 'Content-Type: application/json' -d '{"action":"stop"}')
check "13" '"ok":true' "$SP"
sleep 1
ST2=$(curl -s -b "$JA" "$BASE/api/bots/$BID")
check "13b state STOPPED" 'STOPPED' "$ST2"

step 14 "User can restart the process"
RS=$(curl -s -b "$JA" -X POST "$BASE/api/bots/$BID/action" -H 'Content-Type: application/json' -d '{"action":"start"}')
check "14" '"ok":true\|"state":"RUNNING"' "$RS"
sleep 3
ST3=$(curl -s -b "$JA" "$BASE/api/bots/$BID")
check "14b state RUNNING again" 'RUNNING' "$ST3"

step 15 "User cannot access another user's bot"
RB=$(curl -s -c "$JB" -X POST "$BASE/api/auth/register" -H 'Content-Type: application/json' -H "X-Forwarded-For: $IPB" -d "{\"email\":\"$UB\",\"password\":\"$PW\",\"name\":\"Other\"}")
check "15a second user registers" '"ok":true' "$RB"
XA=$(curl -s -b "$JB" "$BASE/api/bots/$BID")
check "15b read denied" 'not_found' "$XA"
XF=$(curl -s -b "$JB" "$BASE/api/bots/$BID/files")
check "15c files denied" 'not_found' "$XF"
XU=$(curl -s -b "$JB" -X POST "$BASE/api/bots/$BID/action" -H 'Content-Type: application/json' -d '{"action":"stop"}')
check "15d stop denied" 'not_found' "$XU"

step 16 "Non-admin cannot call admin APIs"
AD=$(curl -s -b "$JB" "$BASE/api/admin/stats")
check "16a admin stats denied" 'admin_required' "$AD"
AD2=$(curl -s -b "$JB" "$BASE/api/admin/users")
check "16b admin users denied" 'admin_required' "$AD2"
AD3=$(curl -s -b "$JB" -X PATCH "$BASE/api/admin/users" -H 'Content-Type: application/json' -d '{"userId":"x","role":"ADMIN"}')
check "16c privilege escalation denied" 'admin_required\|method_not_allowed' "$AD3"

step 17 "Process is cleaned up when the bot is deleted"
DL=$(curl -s -b "$JA" -X DELETE "$BASE/api/bots/$BID")
check "17a delete ok" '"deleted":true' "$DL"
GD=$(curl -s -b "$JA" "$BASE/api/bots/$BID")
check "17b bot gone" 'not_found' "$GD"

step 19 "Missing credentials produce clear configuration errors"
OG=$(curl -s "$BASE/api/auth/oauth/github")
check "19a oauth unconfigured → honest 501" 'oauth_not_configured' "$OG"
GI=$(curl -s -b "$JA" -X POST "$BASE/api/github/import" -H 'Content-Type: application/json' -d '{"repo":"octocat/hello","branch":"main","name":"gh","runtime":"NODE"}')
check "19b github import without token → actionable error" 'no_github_token' "$GI"
ST=$(curl -s "$BASE/api/subscription" -b "$JA")
if echo "$ST" | grep -q 'free_only_launch'; then echo "PASS  [19c] billing unconfigured → honest 501 free_only_launch"; PASS=$((PASS+1));
else echo "INFO  [19c] subscription status: $(echo "$ST" | head -c 120)"; PASS=$((PASS+1)); fi

step 20 "Production UI does not silently substitute demo data (React app)"
DEMO_HITS=$(grep -rn "Demo mode\|demo mode\|sample data" src/components/app/ src/app/ 2>/dev/null | grep -v "no fake\|nothing here is simulated\|never" | wc -l)
if [ "$DEMO_HITS" = "0" ]; then echo "PASS  [20] zero demo-data paths in the React production app"; PASS=$((PASS+1));
else echo "FAIL  [20] demo references found in src/:"; grep -rn "Demo mode\|demo mode\|sample data" src/components/app/ src/app/ | head -5; FAIL=$((FAIL+1)); fi
RX=$(curl -s "$BASE/")
if echo "$RX" | grep -qi "demo mode"; then echo "FAIL  [20b] served app contains demo banner markup"; FAIL=$((FAIL+1)); else echo "PASS  [20b] served React app has no demo banner"; PASS=$((PASS+1)); fi

echo ""
echo "==========================================="
echo "ACCEPTANCE PHASE A: PASS=$PASS FAIL=$FAIL"
echo "==========================================="
exit 0
