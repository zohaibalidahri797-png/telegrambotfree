#!/usr/bin/env bash
# BotDock Cloud — acceptance PHASE B (step 18): database + runtime persistence
# across an application restart. Run AFTER restarting the web app following
# tests/acceptance.sh (phase A).
set -u
BASE="http://localhost:3000"
PASS=0; FAIL=0
TD=/home/z/my-project/tests/tmp
JA="$TD/acc-a.jar"

check() {
  if echo "$3" | grep -q "$2"; then echo "PASS  [$1] $2"; PASS=$((PASS+1));
  else echo "FAIL  [$1] expected: $2"; echo "      actual: $(echo "$3" | head -c 300)"; FAIL=$((FAIL+1)); fi
}

echo "--- STEP 18: database retains expected records after application restart ---"
# 18a: session cookie from phase A is still valid (sessions live in the DB,
#       not in memory) — proves session persistence across restarts.
ME=$(curl -s -b "$JA" "$BASE/api/auth/me")
check "18a session survives app restart (DB-backed sessions)" '"email"' "$ME"
# 18b: user + bot records persist (phase A deleted its bots at steps 12/17, so
#       we verify via deployment + audit history and a fresh bot creation).
NEWBOT=$(curl -s -b "$JA" -X POST "$BASE/api/bots" -H 'Content-Type: application/json' \
  -d '{"name":"acc-persist","runtime":"PYTHON","sourceType":"TEMPLATE","templateId":"python-keepalive"}')
check "18b user account still valid, bot creation works" '"ok":true' "$NEWBOT"
NBID=$(echo "$NEWBOT" | grep -o '"id":"[^"]*"' | head -1 | cut -d'"' -f4)
DEPS=$(curl -s -b "$JA" "$BASE/api/deployments")
check "18c deployment records persisted across restart" '"deployments"' "$DEPS"
AU=$(curl -s -b "$JA" "$BASE/api/usage")
check "18d usage records persisted" '"ok":true\|"bots"' "$AU"
# 18e: runtime service reconciliation — deploy and confirm RUNNING after restart.
DP=$(curl -s -b "$JA" -X POST "$BASE/api/bots/$NBID/action" -H 'Content-Type: application/json' -d '{"action":"deploy"}')
check "18e deploy after app restart" '"ok":true' "$DP"
sleep 4
ST=$(curl -s -b "$JA" "$BASE/api/bots/$NBID")
check "18f bot reaches RUNNING after restart (fresh runtime process)" 'RUNNING' "$ST"
LG=$(curl -s -b "$JA" "$BASE/api/bots/$NBID/logs")
check "18g real log lines available after restart" '"lines":\[{"ts"' "$LG"
# cleanup
curl -s -b "$JA" -X POST "$BASE/api/bots/$NBID/action" -H 'Content-Type: application/json' -d '{"action":"stop"}' -o /dev/null
curl -s -b "$JA" -X DELETE "$BASE/api/bots/$NBID" -o /dev/null
echo ""
echo "==========================================="
echo "ACCEPTANCE PHASE B: PASS=$PASS FAIL=$FAIL"
echo "==========================================="
exit 0
