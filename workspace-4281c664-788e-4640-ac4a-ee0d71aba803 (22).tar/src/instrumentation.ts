export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  // Startup configuration validation (fail loudly, never expose values).
  // APP_SECRET signs session JWTs and derives the AES key for encrypted
  // secrets — without it, sign-in and env-var storage cannot work.
  const secret = process.env.APP_SECRET ?? "";
  if (secret.length < 32) {
    console.error(
      "[startup] CONFIGURATION ERROR: APP_SECRET is missing or shorter than 32 characters. " +
        "Sign-in, registration auto-login and encrypted bot environment variables will fail " +
        "until the operator sets APP_SECRET (generate with: openssl rand -hex 32) and restarts. " +
        "Live diagnostics: GET /api/health",
    );
  }
  if (!process.env.DATABASE_URL?.trim()) {
    console.error(
      "[startup] CONFIGURATION ERROR: DATABASE_URL is not set. Every database-backed " +
        "endpoint will answer 503 database_unavailable until it is configured.",
    );
  }
  if (process.env.NODE_ENV === "production" && !process.env.ADMIN_BOOTSTRAP_TOKEN?.trim()) {
    console.warn(
      "[startup] ADMIN_BOOTSTRAP_TOKEN is not set in production: the FIRST account cannot be " +
        "created until the operator configures a one-time setup token (openssl rand -hex 16).",
    );
  }
  if (process.env.NODE_ENV === "production" && process.env.RUNTIME_EMBEDDED !== "false") {
    console.warn(
      "[startup] RUNTIME_EMBEDDED is not \"false\" in production: serverless Workers cannot " +
        "spawn the bot runtime. Set RUNTIME_SERVICE_URL to an external botdock-runtime instance " +
        "and RUNTIME_EMBEDDED=false (see docs/RUNTIME-DEPLOYMENT.md).",
    );
  }

  try {
    const { ensureRuntime } = await import("@/lib/runtime-supervisor");
    await ensureRuntime();
  } catch (err) {
    console.error("[instrumentation] runtime supervisor failed:", err);
  }
}
