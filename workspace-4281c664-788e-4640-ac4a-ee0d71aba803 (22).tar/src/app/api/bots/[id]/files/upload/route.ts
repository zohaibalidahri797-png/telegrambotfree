/**
 * POST /api/bots/:id/files/upload — upload one file or archive into the bot
 * workspace (file manager). Proxies to the botdock-runtime service, which owns
 * the disk and enforces per-file caps, magic-byte detection and zip-slip
 * protection. Owner or ADMIN only, like every other file route.
 *
 * multipart/form-data fields:
 *   file  required — archive (≤20 MB, extracted) or plain file (≤512 KB)
 *   path  optional target directory inside the workspace (default: root)
 */
import { ok, fail, requireUser, originCheck } from "@/lib/api";
import { db } from "@/lib/db";
import { uploadToWorkspace, FileOpError, RuntimeOfflineError, MAX_ARCHIVE_BYTES } from "@/lib/bot-fs";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;

  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");

  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || (bot.userId !== auth.user.id && auth.user.role !== "ADMIN")) {
    return fail(404, "bot_not_found");
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return fail(400, "invalid_form", { detail: "Expected multipart/form-data with a file field." });
  }

  const file = form.get("file");
  const into = String(form.get("path") ?? "");
  if (!(file instanceof File) || file.size === 0) {
    return fail(400, "file_required", { detail: "Choose a file to upload." });
  }
  // The runtime enforces the precise per-kind caps (20 MB archive / 512 KB
  // plain file); this pre-check only avoids buffering oversized bodies.
  if (file.size > MAX_ARCHIVE_BYTES) {
    return fail(413, "file_too_large", {
      detail: `Uploads are limited to ${Math.floor(MAX_ARCHIVE_BYTES / (1024 * 1024))} MB.`,
    });
  }

  const bytes = Buffer.from(await file.arrayBuffer());
  try {
    const result = await uploadToWorkspace(bot.id, file.name || "file", bytes, into);
    return ok({ ok: true, result });
  } catch (err) {
    if (err instanceof RuntimeOfflineError) {
      return fail(503, "runtime_unavailable", {
        detail: "The bot runtime service is not reachable, so uploads cannot be stored right now.",
      });
    }
    const msg = err instanceof FileOpError ? err.message : err instanceof Error ? err.message : "file_error";
    return fail(400, "file_error", { detail: msg });
  }
}
