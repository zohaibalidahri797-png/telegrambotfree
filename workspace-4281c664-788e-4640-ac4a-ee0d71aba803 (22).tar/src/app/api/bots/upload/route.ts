/**
 * POST /api/bots/upload — create a bot from an uploaded project archive.
 *
 * multipart/form-data fields:
 *   name         required, 1-50 chars (letters, digits, spaces, _ -)
 *   runtime      required, PYTHON | NODE | BUN
 *   description  optional, ≤300 chars
 *   startCommand optional, ≤500 chars (validated again at deploy time)
 *   file         required, .zip / .tar / .tar.gz / .tgz archive, ≤20 MB
 *
 * The archive is NOT extracted by the web app: it is streamed to the
 * botdock-runtime service, which performs magic-byte format detection and
 * zip-slip/symlink-safe extraction into the bot workspace. Garbage or
 * malicious archives surface as honest 400s — never a fabricated success.
 *
 * Quota + plan gates mirror the template and GitHub import paths so every
 * creation route enforces the same server-side limits.
 */
import { ok, fail, requireUser, originCheck, reqCtx } from "@/lib/api";
import { db } from "@/lib/db";
import { getEffectivePlan, checkBotSafety } from "@/lib/plans";
import { uploadToWorkspace, FileOpError, RuntimeOfflineError, MAX_ARCHIVE_BYTES } from "@/lib/bot-fs";
import { audit } from "@/lib/audit";
import { BOT_RUNTIMES } from "@/lib/validation";

const NAME_RE = /^[a-zA-Z0-9 _-]+$/;
const ARCHIVE_EXT_RE = /\.(zip|tar|tar\.gz|tgz)$/i;

type BotRuntimeValue = (typeof BOT_RUNTIMES)[number];

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return fail(400, "invalid_form", { detail: "Expected multipart/form-data with name, runtime and file fields." });
  }

  const name = String(form.get("name") ?? "").trim();
  const runtime = String(form.get("runtime") ?? "").trim();
  const description = String(form.get("description") ?? "").trim();
  const startCommand = String(form.get("startCommand") ?? "").trim();
  const file = form.get("file");

  if (name.length < 1 || name.length > 50 || !NAME_RE.test(name)) {
    return fail(400, "invalid_name", {
      detail: "Bot name must be 1-50 characters using letters, digits, spaces, _ or -.",
    });
  }
  if (!(BOT_RUNTIMES as readonly string[]).includes(runtime)) {
    return fail(400, "invalid_runtime", { detail: `runtime must be one of: ${BOT_RUNTIMES.join(", ")}.` });
  }
  if (description.length > 300) {
    return fail(400, "invalid_description", { detail: "Description is limited to 300 characters." });
  }
  if (startCommand.length > 500) {
    return fail(400, "invalid_start_command", { detail: "Start command is limited to 500 characters." });
  }
  if (!(file instanceof File) || file.size === 0) {
    return fail(400, "file_required", { detail: "Choose a .zip or .tar.gz archive to upload." });
  }
  if (file.size > MAX_ARCHIVE_BYTES) {
    return fail(413, "archive_too_large", {
      detail: `Archives are limited to ${Math.floor(MAX_ARCHIVE_BYTES / (1024 * 1024))} MB.`,
    });
  }
  const filename = (file.name || "archive").slice(0, 200);
  if (!ARCHIVE_EXT_RE.test(filename)) {
    return fail(400, "unsupported_archive_type", {
      detail: "Supported archive types: .zip, .tar, .tar.gz, .tgz.",
    });
  }

  // Same server-side gates as every other creation route.
  const plan = await getEffectivePlan(auth.user.id);
  const safety = await checkBotSafety(auth.user.id);
  if (!safety.ok) return fail(403, safety.reason!, { detail: safety.detail });
  if (!plan.limits.runtimes.includes(runtime as BotRuntimeValue)) {
    return fail(403, "runtime_not_enabled", {
      detail: `The ${runtime} runtime is not enabled on this deployment.`,
    });
  }

  const bytes = Buffer.from(await file.arrayBuffer());

  const bot = await db.bot.create({
    data: {
      userId: auth.user.id,
      name,
      description: description || `Uploaded ${filename}`,
      runtime: runtime as BotRuntimeValue,
      startCommand,
      sourceType: "UPLOAD",
      sourceRef: filename,
      status: "CREATED",
    },
  });

  try {
    // The runtime validates magic bytes and extracts safely (zip-slip defence).
    const result = await uploadToWorkspace(bot.id, filename, bytes, "");
    await audit({
      actorId: auth.user.id,
      actorEmail: auth.user.email,
      action: "BOT_CREATE_UPLOAD",
      targetType: "bot",
      targetId: bot.id,
      detail: { name: bot.name, runtime: bot.runtime, archive: filename, bytes: file.size, files: result.kind === "archive" ? result.files : 1 },
      ip,
      userAgent,
    });
    return ok(
      {
        ok: true,
        bot: { id: bot.id, name: bot.name },
        extracted: result.kind === "archive" ? { files: result.files, bytes: result.bytes } : { files: 1, bytes: result.bytes },
      },
      { status: 201 },
    );
  } catch (err) {
    // Roll back the DB row — never leave a bot whose workspace upload failed.
    await db.bot.delete({ where: { id: bot.id } }).catch(() => undefined);
    if (err instanceof RuntimeOfflineError) {
      return fail(503, "runtime_unavailable", {
        detail: "The bot runtime service is not reachable, so uploaded archives cannot be stored right now. It may be starting — try again shortly.",
      });
    }
    if (err instanceof FileOpError) {
      return fail(400, "unsafe_archive", { detail: err.message });
    }
    const msg = err instanceof Error ? err.message : String(err);
    return fail(502, "upload_failed", { detail: msg });
  }
}

export function PUT() {
  return fail(405, "method_not_allowed");
}
