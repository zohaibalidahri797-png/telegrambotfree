import { ok } from "@/lib/api";
import { db } from "@/lib/db";
import { emailProviderStatus, oauthProviderStatus } from "@/lib/platform-health";
import { bootstrapEnforced } from "@/lib/admin-bootstrap";

/**
 * GET /api/auth/config — tells the client which OAuth providers (and email
 * delivery) are configured, so buttons can fail with a clear configuration
 * message instead of silently doing nothing. Also reports whether the
 * first-administrator setup token is currently required (fresh production
 * deployment), so the register form can show the field.
 *
 * Configuration detection is shared with /api/health via
 * src/lib/platform-health.ts (single source of truth — the two endpoints can
 * never disagree about what is configured).
 */
export async function GET() {
  let bootstrapRequired = false;
  try {
    const isFirstUser = (await db.user.count()) === 0;
    // Must mirror the register endpoint's gate exactly (bootstrapEnforced =
    // production OR ADMIN_BOOTSTRAP_TOKEN configured) — otherwise the UI would
    // claim bootstrap is not required while registration refuses without a
    // token. Previously this only reported true in production, which lied in
    // dev deployments that set the token.
    bootstrapRequired = isFirstUser && bootstrapEnforced();
  } catch {
    bootstrapRequired = false;
  }

  const providers = oauthProviderStatus();
  const email = emailProviderStatus();

  return ok({
    google: providers.google,
    githubOAuth: providers.github,
    emailConfigured: email.provider === "resend",
    registrationEnabled: true,
    // Fresh production deployment with no ADMIN_BOOTSTRAP_TOKEN set yet —
    // the operator must complete setup before anyone can register.
    bootstrapRequired,
  });
}
