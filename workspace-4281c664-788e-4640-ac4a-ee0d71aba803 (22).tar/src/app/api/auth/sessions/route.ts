import { ok, requireUser, originCheck, reqCtx } from "@/lib/api";
import { getCurrentSessionId, revokeAllUserSessions, revokeSessionById, pruneSessions } from "@/lib/session";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { fail } from "@/lib/api";

/** GET: list the signed-in user's active sessions. */
export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  await pruneSessions();
  const sessions = await db.session.findMany({
    where: { userId: auth.user.id, revokedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: "desc" },
    select: { id: true, ip: true, userAgent: true, createdAt: true, expiresAt: true },
  });
  const currentSessionId = await getCurrentSessionId();
  return ok({
    sessions: sessions.map((s) => ({
      ...s,
      current: s.id === currentSessionId,
    })),
  });
}

/** DELETE: revoke one session (?id=) or all sessions ({"all":true} body). */
export async function DELETE(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const url = new URL(req.url);
  const sessionId = url.searchParams.get("id");

  if (sessionId) {
    const done = await revokeSessionById(auth.user.id, sessionId);
    if (!done) return fail(404, "session_not_found");
    await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "SESSION_REVOKED", targetType: "session", targetId: sessionId, detail: {}, ip, userAgent });
    return ok({ ok: true });
  }

  const count = await revokeAllUserSessions(auth.user.id);
  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "ALL_SESSIONS_REVOKED", detail: { count }, ip, userAgent });
  return ok({ ok: true, revoked: count });
}
