# BotDock Cloud — Production-Readiness Report

**Date:** 2026-10-29 · **Scope:** audit, repair, and verification of the existing BotDock Cloud codebase as a real Telegram-bot hosting platform.
**Method:** audit first, then repair, then verify. Every claim below is backed by an executed test in this session (see §F). Nothing was marked working without evidence.

---

## A. Audit report — original problems and their causes

The codebase was audited end-to-end before any change (40 API routes, 14 pages, the runtime service, Prisma schema, both frontends, all deploy configs). The architecture turned out to be **genuinely implemented** — custom auth, Prisma persistence, a real process-spawning runtime service — not a mock. The "Demo mode" messages come from a separate, clearly-labeled static-site fallback layer (§A.10). The real defects were:

| # | Problem | Root cause | Evidence | Fix |
|---|---------|-----------|----------|-----|
| 1 | **ZIP/tar.gz bot upload was dead end-to-end** — the UI called `POST /api/bots/upload` but the route did not exist; `POST /api/bots` even redirected users to it. | The Next.js proxy route was never written although the runtime fully supported archive extraction. | `dashboard.tsx` upload tab; E2E tests 13/13b failed pre-fix | New `src/app/api/bots/upload/route.ts` (multipart, size/type validation, plan gates, rollback on failure, audit) |
| 2 | **File-manager Upload button broken** — UI called `POST /api/bots/:id/files/upload`, route did not exist. | Same class of missing proxy route. | `bot-detail.tsx` upload handler; E2E 13h/13i failed pre-fix | New `src/app/api/bots/[id]/files/upload/route.ts` (owner check, caps, proxies to runtime) |
| 3 | **Session manager always showed every row as "not current"** — hardcoded `current:false` with an unfinished "filled below" comment. | Dead code path; helper never written. | `api/auth/sessions/route.ts` | Added `getCurrentSessionId()` in `session.ts`; route now marks the real row |
| 4 | **UI lied about first-admin bootstrap** — `/api/auth/config` reported `bootstrapRequired:false` in dev while the register endpoint refused registration without the token. Two modules disagreed. | config route used `NODE_ENV==="production"` only; register uses `bootstrapEnforced()` (production **or** token configured). | Manual register → `admin_bootstrap_required` while config said `false` | config route now calls the same `bootstrapEnforced()` helper — single source of truth |
| 5 | **Login returned an opaque 500 when `APP_SECRET` was missing** (verified by running the server without it). | `createSession()` throws on short secrets; login had no mapping. | HTTP 500 observed in the missing-secret drill | login now answers `503 server_misconfigured` with operator instructions; register already degraded gracefully |
| 6 | **Runtime PATH hardcoded to `/home/z/.venv/bin`** in `isolation.ts` and `install.ts` — bot processes and installers would fail on any host without that exact venv. | Host-specific constant. | Code inspection | New `computeBasePath(bins)`: `RUNTIME_BASE_PATH` override → interpreter directories → standard dirs; threaded through manager + installers |
| 7 | **Dead code / dead weight**: `GET /api` "Hello, world!" placeholder, 286-line unused `src/lib/bot-files.ts`, 10 unused dependencies (`next-auth`, `uuid`, `@dnd-kit/*`, `adm-zip`, `next-intl`, `@mdxeditor/editor`, `z-ai-web-dev-sdk`). | Accumulated scaffolding. | grep: zero imports | Deleted; `bun install` re-locked (supply-chain surface reduced) |
| 8 | **Stale pricing copy** in the static fallback site ("3 bots · 50 MB · 20 deployments/day") contradicted the seeded Free plan. | Copy drift. | `public/index.html:58` vs `seed.ts` | Corrected to the real plan numbers |
| 9 | **E2E suite did not cover the bootstrap flow or the new routes** and registered users without the operator token. | Suite predated the feature. | 24 failures pre-fix (cascade from registration refusal) | `tests/full-e2e.sh` updated: bootstrap negative test, fresh-DB conditional strict path, per-run client IPs (register limiter is per-IP), tests for both new routes, oversize/invalid-name/missing-file rejection, honest-failure deploy test |
| 10 | **"Demo mode" banner provenance** — traced exactly: `public/assets/js/demo.js` + `app.js` activate **only** when the static fallback site cannot reach `/api/health` (3.5 s probe). It is a labeled, in-memory preview for static-only deployments; it is not reachable through the React app's data flow. The React production app contains **zero** demo data paths (grep-verified, E2E step 20). | Static-site fallback by design (docs/STATIC-FRONTEND.md). | grep of `src/`: no demo data; static JS: labeled demo only | Kept as a clearly-labeled static-only fallback; the production surface (React app + API) is fully wired to real services. No demo text was merely hidden — the real backend behind it was completed and verified |
| 11 | **Workspace integrity**: sandbox resets had wiped `.env` (auth/DB/runtime all unconfigured). | Sandbox instability. | `.env` contained only `DATABASE_URL` | Regenerated dev `.env` (gitignored; `chmod 600`); startup now logs a loud configuration error for missing `APP_SECRET`/`DATABASE_URL` and warns about production-runtime misconfig (`src/instrumentation.ts`) |

Also verified as **already correct** (no change needed): bcrypt cost-12 hashing, JWT+DB double-checked sessions, origin-check CSRF on all mutations, per-IP/per-account rate limits, AES-256-GCM secret storage with masked reads, zip-slip/symlink/magic-byte defenses in the runtime, boot reconciliation of stale RUNNING bots, owner/ADMIN checks on every bot route, `requireAdmin` on all admin routes, audit logging with redaction, honest 501s for unconfigured OAuth/billing/email.

---

## B. Change report

**Created**
| File | Reason |
|------|--------|
| `src/app/api/bots/upload/route.ts` | Restores the core "upload a ZIP → create bot" product flow (was referenced by UI + tests but missing) |
| `src/app/api/bots/[id]/files/upload/route.ts` | Restores file-manager upload |
| `tests/acceptance.sh` | 22-step acceptance workflow (phase A: steps 1–17, 19, 20) with per-step evidence |
| `tests/acceptance-phase2.sh` | Step 18 verification after an application restart |

**Changed**
| File | Change |
|------|--------|
| `src/lib/session.ts` | + `getCurrentSessionId()` (JWT sid for the sessions UI) |
| `src/app/api/auth/sessions/route.ts` | `current` flag now computed, not hardcoded |
| `src/app/api/auth/config/route.ts` | `bootstrapRequired` now mirrors the register gate exactly |
| `src/app/api/auth/login/route.ts` | Missing `APP_SECRET` → honest `503 server_misconfigured` |
| `src/instrumentation.ts` | Startup configuration validation: loud errors for missing `APP_SECRET`/`DATABASE_URL`, production warnings for unset `ADMIN_BOOTSTRAP_TOKEN` and wrong `RUNTIME_EMBEDDED` |
| `mini-services/bot-runtime/src/isolation.ts` | `computeBasePath()` replaces hardcoded PATH; `buildChildEnv` takes `bins` |
| `mini-services/bot-runtime/src/install.ts` | Installers use the computed PATH (no `/home/z` dependency) |
| `mini-services/bot-runtime/src/manager.ts` | Passes `bins` to `buildChildEnv` |
| `tests/full-e2e.sh` | Bootstrap flow, new-route coverage, per-run client IPs, honest-failure deploy test |
| `public/index.html` | Free-plan copy corrected to real seeded limits |
| `package.json` | 10 unused dependencies removed; lockfile re-synced |

**Removed**
`src/app/api/route.ts` (Hello-World placeholder), `src/lib/bot-files.ts` (dead 286-line module), unused deps (see §A.7).

---

## C. Architecture report

| Component | Implementation | Runs on |
|-----------|----------------|---------|
| **A. Web frontend** | React 19 SPA (`src/components/app/*`, hash-routed) + 10 server-rendered marketing/legal pages (Next.js 16 App Router). Static fallback site in `public/` for Pages-only deployments. | Next.js server (dev) / Cloudflare Worker via OpenNext (prod) |
| **B. Web backend/API** | 40 route handlers under `src/app/api/*` — auth (custom, bcrypt+JWT+DB sessions, OAuth2), bots, files proxy, env vars, deployments, GitHub, plans, subscriptions, notifications, admin, broadcasts, health. | Same Next.js process (Node) / Worker isolate |
| **C. Database** | Prisma ORM. 20 models, 2 migrations, FK cascades, unique bootstrap marker, shared rate-limit bucket table. Dev: local SQLite. Prod: remote libSQL (e.g. Turso free tier) via `@prisma/adapter-libsql`. | SQLite file / libSQL service |
| **D. Bot runtime** | `mini-services/bot-runtime` — standalone Bun HTTP service on **loopback only** (`127.0.0.1:3030`), every request authenticated by timing-safe `X-Runtime-Key`. Spawns real OS processes (python3/node/bun) with rlimits, sanitized env, detached process groups, ring-buffer logs, `/proc` metrics, atomic `state.json`, boot reconciliation. | Dev: auto-spawned by the web app (embedded supervisor). Prod: **separate Linux host/VM** (`bun src/index.ts`) |
| **E. Background jobs** | Build/install steps run inside the runtime as detached process groups with timeouts + kill-tree; web side stays stateless. | Runtime host |
| **F. File storage** | Runtime-owned workspaces: `staging/ workspace/ bots/{current,previous} logs/ builds/ state.json` under `RUNTIME_DATA_DIR`. Web app never touches bot files directly (HTTP proxy with `X-Runtime-Key`). | Runtime host disk |
| **G. Logging & monitoring** | 1000-line ring buffer + 5 MB rotating per-bot log files; 1 MB-capped build logs; CPU/memory from `/proc` per process group; `unknown` when unmeasurable — never fabricated. Health endpoint live-probes DB + runtime independently. | Both |
| **H. Network layer** | Dev: Next.js on :3000 (+ Caddy dev proxy). Prod: Cloudflare edge → Worker; runtime must sit behind its own TLS endpoint (see §D), reachable only by the Worker. | Cloudflare / runtime VM |

Key rule enforced throughout: the web app is **Cloudflare-compatible** (no local FS access for bot data; everything proxied to the runtime), while the runtime runs where processes can live.

---

## D. Deployment guide

### D.1 Local development (verified in this session)
```bash
cp .env.example .env         # then fill: DATABASE_URL, APP_SECRET, RUNTIME_API_KEY
bun install
bun run db:push              # or: bun run db:migrate:deploy
bun run dev                  # web on :3000; embedded runtime auto-spawns on 127.0.0.1:3030
```
First account: with `ADMIN_BOOTSTRAP_TOKEN` set, register with that token (the UI shows the field automatically); without it in dev, the first account becomes admin.

### D.2 Web application on Cloudflare Workers (OpenNext — verified build)
```bash
bun run cf:build             # opennextjs-cloudflare build + secret-scrubbing cf-clean
bun run cf:verify            # fails loudly on stale/leaky bundles
bun run cf:deploy            # requires wrangler auth (CLOUDFLARE_API_TOKEN or wrangler login)
```
Wrangler settings (already in `wrangler.jsonc`): main `.open-next/worker.js`, assets `.open-next/assets`, `html_handling:"none"`, `nodejs_compat`.

**Required secrets/vars** (`wrangler secret put …`):
`DATABASE_URL` (**must be remote libSQL**, e.g. `libsql://…turso.io` — local-file SQLite cannot work in workerd; the seed failure visible in the workerd matrix log is exactly this dev-only condition), `LIBSQL_AUTH_TOKEN`, `APP_SECRET` (≥32 chars), `APP_URL`, `ADMIN_BOOTSTRAP_TOKEN`, `RUNTIME_API_KEY`, `RUNTIME_SERVICE_URL` (public HTTPS URL of the runtime), `RUNTIME_EMBEDDED=false`.

Apply migrations to the remote DB first: `DATABASE_URL="libsql://…" bun run db:migrate:deploy`.

### D.3 Bot runtime on a Linux host (documented: docs/RUNTIME-DEPLOYMENT.md)
```bash
# on the runtime VM
git clone <repo> && cd BotDock-Cloud/mini-services/bot-runtime
bun install
RUNTIME_API_KEY=<same-secret-as-web> RUNTIME_DATA_DIR=/var/lib/botdock \
  PYTHON_BIN=python3 NODE_BIN=node BUN_BIN=bun \
  bun run start              # listens on 127.0.0.1:3030 — put TLS termination in front
```
Web app ↔ runtime share `RUNTIME_API_KEY`; runtime is loopback-only and must be exposed via a TLS reverse proxy restricted to the Worker's egress.

### D.4 Database
- Dev: `file:./db/custom.db` (SQLite).
- Prod: remote libSQL/Turso (free tier sufficient to start). Migrations: `bun run db:migrate:deploy`. Never run `db:reset` against production.

Full per-variable reference (name, purpose, required/optional, consuming service, restart requirement): `.env.example` (93 lines, placeholders only).

---

## E. Security report

**Implemented and verified**
| Control | Where | Evidence |
|---|---|---|
| Password hashing bcrypt cost 12 + strength rules | `lib/password.ts` | E2E 4b (wrong password rejected) |
| Opaque token in httpOnly SameSite=Lax cookie, JWT-signed, DB double-check, 7-day expiry, revocation lists | `lib/session.ts` | E2E 5/5b; acceptance 18a (session survives restart) |
| First-admin bootstrap token, race-safe unique marker | `lib/admin-bootstrap.ts` | acceptance 1 (token grants ADMIN), E2E 2b (missing token refused) |
| Registration/login rate limits (5/h/IP, 20/15min/IP + 8/15min/account) | register/login routes | code + acceptance |
| CSRF origin check on every mutation | `lib/api.ts originCheck` | E2E CSRF + 8/8b (OAuth state) |
| OAuth state validation, provider-verified-email linking only, honest 501 when unconfigured | oauth routes | E2E 6/7/8/8b |
| AES-256-GCM encryption at rest for bot env vars + GitHub PATs; values never returned after save | `lib/crypto.ts`, env route | acceptance 7a/7b/7c (masked reads only) |
| Ownership/ADMIN checks on every bot/file/log route | per-route | acceptance 15a–15d; E2E 15c/15d/15e |
| Server-side admin RBAC (`requireAdmin`) | all `/api/admin/*` | acceptance 16a–16c (privilege escalation denied) |
| Audit log with secret redaction | `lib/audit.ts` | admin audit route; health H8 (no raw secret fields) |
| Zip-slip / symlink / magic-byte / size defenses in extraction | runtime `files.ts` | E2E 13c/13d/13j; acceptance 5–6 |
| rlimits (ulimit -v/-t/-u/-f), sanitized env (PATH/HOME/LD_PRELOAD stripped), HOME jailed, detached process groups, group SIGTERM→SIGKILL | runtime isolation/manager | visible in real logs during browser test |
| Runtime loopback-only + timing-safe `X-Runtime-Key` on every route | runtime `index.ts` | code; health live-probe |
| Internal port allocator (no host port collisions) | `isolation.ts` | observed ports 3106/3115 during tests |
| Honest status: exit-during-grace → FAILED, unexpected exit → FAILED, boot reconciliation marks stale RUNNING | runtime manager | acceptance 12a/12b (deliberate crash reported truthfully) |
| Startup config validation with loud errors | `instrumentation.ts` | missing-secret drill (health `appSecretConfigured:false`, `ok:false`) |

**Remaining risks (documented, not hidden)**
1. **Process-level isolation only** — rlimits + env sanitization + cwd jail, but **no containers/namespaces/seccomp** on this host. RLIMIT_NPROC is per-UID; disk/CPU are measured, not hard-enforced. Production hardening = run each bot in a container/VM (runtime README documents this; §D.3 isolates the whole service on a dedicated VM as mitigation).
2. **Rate limiter fails open** on DB-backend errors (deliberate availability tradeoff, documented in `rate-limit.ts`).
3. `/api/download` serves release archives unauthenticated (intentional; archives contain no secrets — cf-verify gates on that).
4. Static fallback site's demo mode is labeled but runs when the backend is unreachable; it holds no real data and resets on reload.

---

## F. Test report

All executed in this session against `localhost:3000` (web :3000 + botdock-runtime :3030 + SQLite). Source of truth: commands in `tests/`.

| Test | Result | Evidence |
|---|---|---|
| TypeScript `bunx tsc --noEmit` (web + runtime) | **PASS** (0 errors) | both exit 0 |
| ESLint `bun run lint` | **PASS** (clean) | no output |
| Unit tests `bun test tests/` | **PASS 33/33** (108 assertions) | health / runtime-config / email-provider suites |
| Full E2E `tests/full-e2e.sh` | **PASS 79 / FAIL 0** (1 check becomes INFO on a pre-initialized DB) | includes: registration+verify+login+logout, sessions-current, bootstrap negative, OAuth honesty, CSRF, zip/tgz upload, zip-slip & garbage rejection, oversize/missing-file/invalid-name rejection, cross-user isolation, deploy→RUNNING→logs→stop, file write/read/upload/.env-denied, static paths, contract aliases |
| **Acceptance phase A** `tests/acceptance.sh` (fresh DB) | **PASS 37 / FAIL 0** | steps 1–17, 19, 20 of §22 — incl. secret non-disclosure (7b/7c), honest crash reporting (12a/12b), admin-API denial (16a–16c), no-demo-data checks (20/20b) |
| **Acceptance phase B** `tests/acceptance-phase2.sh` (after app restart) | **PASS 7 / FAIL 0** | step 18 — DB-backed sessions, users, deployments, usage persist; runtime redeploys and reaches RUNNING after restart |
| Worker route matrix `tests/worker-route-matrix.sh` (real workerd) | **PASS 12/12** + static assets 200s | route resolution in the compiled Worker |
| Production build `bun run build` + `cf:build` + `cf:verify` | **PASS** | worker.js + assets emitted; secret scrub verified |
| Browser golden path (agent-browser) | **PASS** | landing renders (no demo banner) → UI registration → email-verify screen → dashboard with real user → template bot create → deploy → heading "ui-keepalive RUNNING" with real runtime log lines visible (state transitions, actual ulimit wrapper command, real port) → Stop → "STOPPED" → Files tab lists real workspace files → no horizontal overflow at 375 px → no console errors |
| Missing-`APP_SECRET` drill | **PASS** (honest failure) | health: `ok:false`, `appSecretConfigured:false`; login → 503 `server_misconfigured` (after fix); registration proceeds without auto-login |

**BLOCKED (external credentials not available in this environment)**
| Item | Why |
|---|---|
| Real Google/GitHub OAuth account linking | needs real provider credentials + callback URLs; honesty of the unconfigured path is verified (501) |
| Real Resend email delivery | needs `RESEND_API_KEY`; skip/fail honesty verified |
| Live remote libSQL/Turso + real Cloudflare deploy | needs user's Turso instance and CF account; build + workerd matrix verified instead |
| Telegram live connectivity (broadcast/token) | needs a real `TELEGRAM_BOT_TOKEN`; platform must never fabricate "sent" (verified) |
| Container-grade isolation benchmarking | requires container runtime on the host (see §E risk 1) |

---

## G. Known limitations

1. **Isolation is process-level, not container-level** (rlimits/sanitized env/jailed HOME). Acceptable for a controlled test deployment; containers/VMs required before hostile multi-tenancy.
2. **Disk & CPU quotas are measured and reported, not hard-enforced** (memory is bounded via ulimit + NODE_OPTIONS; CPU via nice).
3. **Billing is honestly dormant**: `MONETIZATION_ENABLED=false` → checkout returns 501 `free_only_launch`, paid plans hidden; Stripe code path exists but is inactive. No fake payments.
4. **Email, OAuth, Telegram broadcasts** require their credentials; until then the UI/API state their absence clearly (never fake success).
5. **Static fallback demo** exists only on `public/*.html` pages when no backend answers; the React app never substitutes demo data.
6. **No middleware layer** — auth is enforced per-route (verified by the authz tests); a new route that forgets `requireUser` would be public (code-review responsibility).
7. `wrangler dev` matrix logs `fs.readdir` errors when a **local-file** DB is used inside workerd — expected; production Workers must use remote libSQL.
8. Verification was performed on the local test deployment; the public Cloudflare URL has **not** been redeployed with these changes yet (needs §H).

---

## H. Launch checklist (from current state → verified working test deployment)

1. Create a Turso database (free tier): `turso db create botdock` → copy URL + token.
2. `DATABASE_URL="libsql://…turso.io" LIBSQL_AUTH_TOKEN=… bun run db:migrate:deploy` (from a machine that can reach it).
3. Cloudflare: `wrangler login` (or `CLOUDFLARE_API_TOKEN`), then `wrangler secret put` for: `DATABASE_URL`, `LIBSQL_AUTH_TOKEN`, `APP_SECRET` (`openssl rand -hex 32`), `APP_URL`, `ADMIN_BOOTSTRAP_TOKEN` (`openssl rand -hex 16`), `RUNTIME_API_KEY` (`openssl rand -hex 32`), `RUNTIME_SERVICE_URL`, and set `RUNTIME_EMBEDDED="false"`.
4. Provision the runtime VM (§D.3) with the same `RUNTIME_API_KEY`; expose it over TLS; if a fixed public URL is used, set `RUNTIME_SERVICE_URL` accordingly and restrict ingress to the Worker.
5. `bun run cf:build && bun run cf:verify && bun run cf:deploy`.
6. Post-deploy verification (also printed by cf-verify): `GET /api/health` → per-component statuses; `/register` → 307 → `/#/register`; register the **first** account with `ADMIN_BOOTSTRAP_TOKEN`; create a template bot; deploy; confirm RUNNING + real logs; stop; delete.
7. Optional now/required for email: set `RESEND_API_KEY` + `EMAIL_FROM`; for OAuth: provider IDs/secrets + callback URLs `<APP_URL>/api/auth/oauth/{provider}/callback`.

## I. Rollback instructions

- **Worker**: `wrangler rollback` (reverts to the previous deployed Worker version) or redeploy the previous archive (`download/BotDock-Cloud-*.zip|tar.gz` of the prior commit) — Cloudflare keeps version history.
- **Code**: `git revert <commit>` on the release commit; this session's work is a single commit; DB migrations were **not** changed (no schema migration shipped in this pass), so no DB rollback is needed.
- **Runtime**: stop with SIGTERM (`kill <pid>`); it persists state (`state.json`) and reconciles on next boot; redeploy the previous runtime build if needed.
- **Database**: Turso point-in-time restore / branch restore if ever required; the app never runs destructive migrations automatically.

## J. Final status

**TEST DEPLOYMENT VERIFIED.**

Meaning, precisely: the full stack — web app, database, and the persistent bot runtime spawning **real OS processes** — has been deployed locally and verified end-to-end against the 22-step acceptance workflow (44/44 checks), the 79-check E2E suite (0 failures), 33/33 unit tests, a 12/12 workerd route matrix, and an interactive browser run of the golden path. The production Cloudflare deployment itself has not been re-executed here because it requires the owner's Turso/Cloudflare/runtime-VM credentials; the exact commands to complete it are §H, and the build for it is verified. This is **not** claimed as PRODUCTION READY: container-grade isolation, configured email/OAuth/billing credentials, and the public re-deployment remain outstanding (§G, §H).
