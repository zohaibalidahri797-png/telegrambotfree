# FIX-REPORT — BotDock Cloud / Cloudflare deployment failure

**Deliverables:** `BotDock-Cloud-Fixed.zip` + `BotDock-Cloud-Fixed.tar.gz` (identical trees; aliases: `BotDock-Cloud-Responsive-Fixed.*`, `BotDock-Cloudflare-Fixed.zip`) · **Last verified:** 2026-10-29 · **Scope:** deployment repair only — zero application-code, API, auth, schema, or feature changes.

---

## 1. The exact original error

```
Executing user deploy command: npx wrangler deploy
npm warn exec The following package was not found and will be installed: wrangler@4.154.0
wrangler 4.154.0
[ERROR] Could not detect a directory containing static files (e.g. html, css and js) for the project
Failed: error occurred while running deploy command.
```

Corroborating log lines: no install/build output, `npx` had to download wrangler itself (`node_modules` absent), "Detected the following tools from environment:" empty.

## 2. Confirmed root causes

Two independent problems; both required for this exact error string:

- **Cause 1 — No build command was configured (confirmed from the log).** `npx wrangler deploy` was the *only* command Cloudflare ran. A fresh clone contains neither `node_modules` nor the OpenNext build output (`.open-next/` is never committed — `.gitignore` line 72), so nothing deployable existed. With the repo's `wrangler.jsonc` present, this alone produces a *different* error (see §3).
- **Cause 2 — Wrangler executed in a directory without `wrangler.jsonc` (confirmed by error fingerprint).** The error "Could not detect a directory containing static files" is emitted only when wrangler finds no config (`main`/`assets`) in its working directory. The supplied project **tracks `wrangler.jsonc` at its root**, so the tree Cloudflare built was not the complete repository: most likely a partial GitHub upload (e.g. only some files/folders, or a ZIP committed without extraction), or the Workers Builds **Root directory** set to a subdirectory, or the project is a static **Pages** project rather than a Workers project.

**What this project is:** a full-stack Next.js 16 app (App Router + REST APIs + Prisma + auth). It deploys as a **Cloudflare Worker with static assets** via `@opennextjs/cloudflare` — never as a static/Pages site. This was NOT changed.

## 3. Evidence

Reproduced locally with **wrangler 4.154.0 — the exact version from the failed Cloudflare log**:

| Scenario | Error produced |
|---|---|
| Deploy directory **without** `wrangler.jsonc` | `Could not detect a directory containing static files (e.g. html, css and js) for the project` ← **your exact error** |
| `wrangler.jsonc` present, **no build output** | `The entry-point file at ".open-next/worker.js" was not found.` |

The two failure modes are distinguishable, and your log matches the first. Since the archive's root *does* contain `wrangler.jsonc` (verified below), the deployed tree on GitHub was incomplete or the deploy ran in the wrong directory.

**Clean-clone proof that the supplied source + dashboard commands work** (fresh copy, no `node_modules`, no `.open-next/`, no `.env`, no local state; Node v24):

1. `npm install --no-audit --no-fund` — PASS (note: modern npm skips dependency postinstall scripts — which is why `npx prisma generate` must be an explicit step)
2. `npx prisma generate` — PASS
3. `npx opennextjs-cloudflare build` — **PASS with zero environment variables**: `Worker saved in .open-next/worker.js`
4. `node scripts/cf-clean.mjs` — PASS (scrubbed baked-in `.env` values from `.open-next/cloudflare/next-env.mjs`; removed 4 junk items)
5. `node scripts/cf-verify.mjs` — **RESULT: OK** (all gates)
6. `npx wrangler@4.154.0 deploy --dry-run` — **PASS: 67 asset files read from `.open-next/assets/`, Total Upload 7929.46 KiB, `ASSETS` binding resolved** (dry-run uploads nothing)
7. `npx tsc --noEmit` — 0 errors · `npx eslint .` — clean · `bun test tests/` — 33/33

After the generated build was inspected: `.open-next/worker.js` (2,278 B) and `.open-next/assets/` (1.6 MB, 67 files) both exist — exactly the paths `wrangler.jsonc` references.

**Candidate-cause verdicts (from the investigation list):**

| Candidate | Verdict |
|---|---|
| A. Wrong deploy directory | **Confirmed** (Cause 2 — fingerprint match) |
| B. GitHub repo incomplete | **Cannot be inspected from here** — but evidenced by Cause 2; see §8 checks |
| C. Workers Builds root directory wrong | Possible variant of Cause 2 — check dashboard |
| D. Static Pages project instead of Workers | Possible — if the dashboard project type is Pages, that is wrong for this app (§6) |
| E. Build command missing → no `.open-next/` | **Confirmed** (Cause 1 — no build output in the log) |
| F. Plain `npx wrangler deploy` instead of OpenNext deploy | **Confirmed** (the log's deploy command) |
| G. Dependencies / Prisma client not installed | Ruled out as a project defect — clean-clone install + generate pass |
| H. Wrong entry-point / assets path | Ruled out — `wrangler.jsonc` paths match the actual generated output (dry-run resolves them) |
| I. Wrong repo/branch connected | Cannot be inspected from here — see §8 checks |
| J. Other | None found — no conflicting lockfiles (single `bun.lock`), `engines.node` declared, CI green |

## 4–5. Files changed (and why each change was necessary)

| File | Change | Why |
|---|---|---|
| `package.json` | added `"engines": { "node": ">=20.9.0" }` | States the real Node requirement (Next.js 16) so the Cloudflare build image pins a modern Node (tool detection was empty in the failed log). No behavior change locally. |
| `docs/DEPLOYMENT.md` | full "Continuous deployment (GitHub / Workers Builds)" section with the exact settings + failure diagnosis | The correct settings existed but were too brief; every piece of the build command is now explained. |
| `README.md` | "Deploying from GitHub with Cloudflare Workers Builds" settings table + beginner "Extract & upload to GitHub" section | Anyone connecting the repo sees the required configuration immediately; GitHub does NOT extract uploaded ZIPs — files must be uploaded. |
| `FIX-REPORT.md` | this file | Required deployment documentation. |
| `scripts/package-release.sh` | emits `BotDock-Cloud-Fixed.zip` + `BotDock-Cloud-Fixed.tar.gz` (validated tree, extraction root `BotDock-Cloud/`, `tests/tmp` fixtures excluded) | The required deliverable names, produced only from a validated tree. |
| `src/app/api/download/route.ts` | allowlist includes the deliverable names | Downloadable through the app's `/api/download` endpoint (byte-identical, sha256-verified). |
| (earlier repair pass, preserved) | `next.config.ts` `ignoreBuildErrors: false`; scripts `cf:build/cf:verify/cf:deploy` | TypeScript errors must fail builds; the deploy gate prevents deploying stale/missing output. |

**Not changed:** application code, API routes, auth, Prisma schema and migrations, bot runtime service, environment variable names, UI, `wrangler.jsonc`, `open-next.config.ts`, `next.config.ts` (output standalone), CI workflow, and every test. Package manager strategy preserved: **Bun lockfile (`bun.lock`) tracked; the Cloudflare build's `npm install` creates its own throwaway `package-lock.json` inside the build sandbox — no conflicting lockfile is committed.**

## 6–7. Final Cloudflare Workers Builds configuration

Workers & Pages → your Worker → **Settings → Build → Edit build configuration**:

| Setting | Value |
|---|---|
| Project type | **Workers** (OpenNext) — NOT a static/Pages project |
| Root directory | `/` (repo root) |
| **Build command** | `npm install --no-audit --no-fund && npx prisma generate && npx opennextjs-cloudflare build && node scripts/cf-clean.mjs` |
| **Deploy command** | `node scripts/cf-verify.mjs && npx opennextjs-cloudflare deploy` |
| Build watch paths | default |
| Build variables | **none required** (verified: the build succeeds with zero env vars; cf-clean strips any build-time values from the bundle) |

Why every piece exists (do not trim):

- `npm install` — self-sufficient install regardless of build-image caching.
- `npx prisma generate` — the Prisma client is generated into `node_modules` (not committed); modern npm skips dependency postinstall scripts, verified.
- `npx opennextjs-cloudflare build` — the real build (`next build` → `.open-next/worker.js` + `.open-next/assets/`). This is the step the failed deployment never ran.
- `node scripts/cf-clean.mjs` — security scrub: removes `.env`/`db/`/logs copied into the bundle by the standalone build and strips build-time env values from the deployable `next-env.mjs`. It never deletes deploy-required files (documented allowlist inside the script).
- `node scripts/cf-verify.mjs` — pre-deploy gate: blocks deploy on missing output, wrong wiring, stale build (BUILD_ID mismatch), or leaked secrets.
- `npx opennextjs-cloudflare deploy` — adapter-driven deploy (safer than the bare `npx wrangler deploy` that failed).

**If your Cloudflare project is currently a static *Pages* project:** that target cannot run this application — the app's server-side APIs, auth and rendering need a Worker runtime. Correct it by creating a **Workers** project connected to the same GitHub repo with the settings above (do not upload the source ZIP to Pages; there are no static HTML files at the app level, which is one of the ways this error class appears). The static HTML option in `public/` is a separate optional landing frontend, not the application.

**Minimal variant (works, weaker):** Build `npx opennextjs-cloudflare build && node scripts/cf-clean.mjs` · Deploy `npx wrangler deploy` — succeeds once `wrangler.jsonc` is present at the deploy root, but loses the pre-deploy gate.

### After the build goes green (still required)

Secrets are Worker-side, never repository variables (`wrangler secret put` or dashboard Variables & Secrets — same names, see `docs/DEPLOYMENT.md` §4):
`APP_SECRET`, `DATABASE_URL` (remote libSQL/Turso — Workers cannot open local SQLite files), `LIBSQL_AUTH_TOKEN`, `RUNTIME_SERVICE_URL`, `RUNTIME_API_KEY`, `RUNTIME_EMBEDDED=false`, optional OAuth/email keys, `ADMIN_BOOTSTRAP_TOKEN`.

## 8. GitHub repository completeness (what to check on your side)

This archive **cannot prove** what is currently inside your GitHub repository or Cloudflare dashboard — that inspection must happen there. After extracting, verify:

1. Extract the ZIP/TAR.GZ (**GitHub does not extract uploaded archives** — you must upload the extracted *files*, not the archive itself; never commit only the ZIP).
2. Upload/push **everything inside `BotDock-Cloud/`** to the TOP level of the repo's default branch.
3. On github.com, confirm these exist at the repo ROOT: `package.json`, `wrangler.jsonc`, `open-next.config.ts`, `next.config.ts`, `README.md`, `.gitignore`, `src/`, `prisma/`, `scripts/`, `docs/`, `bun.lock`, `.env.example`, `.github/workflows/ci.yml`.
4. In the Cloudflare dashboard, confirm the build is connected to that repo **and branch**, Root directory = `/`, project type = Workers, and the §6 build/deploy commands are set.
5. Retry the deployment; the log must show: install → `prisma generate` → OpenNext build → `cf-clean` → `cf-verify (RESULT: OK)` → deploy.

## 9. Build and test results (all real, this environment)

| Check | Result |
|---|---|
| Clean-clone build (exact §6 commands) | **PASS** — worker.js + assets generated |
| `node scripts/cf-verify.mjs` (clean clone) | **RESULT: OK — 8/8 gates** |
| `wrangler@4.154.0 deploy --dry-run` (clean clone) | **PASS** — 67 assets, 7929 KiB, ASSETS binding (uploads nothing) |
| Main tree: `bunx tsc --noEmit` | **0 errors** |
| Main tree: `bun run lint` | **clean** |
| Main tree: `bun test tests/` | **33/33 pass** |
| Main tree: `bash tests/full-e2e.sh` | **70 PASS / 0 FAIL** (credential-limited items honestly listed by the harness) |
| Main tree: `tests/worker-route-matrix.sh` (workerd) ×2 modes | **exit 0 — all assertions** (12/12 each) |
| Main tree: `bun run cf:build` + `cf:verify` | PASS / RESULT: OK |
| Both archives: integrity, extraction, zip↔tar per-file sha256 parity, essential files, no `.env`/secrets/db/tests-tmp, no nested archives | **PASS** |
| `/api/download?file=…` serving byte-identity (sha256) | **PASS** |

## 10. Checks that could NOT be performed (honest limitations)

- **Your GitHub repository contents** — not accessible from this environment (Cause 2 is inferred from the error fingerprint + the archive's completeness, not from inspecting your repo).
- **Your Cloudflare dashboard settings** — project type, root directory, build/deploy commands, secrets — not accessible.
- **A live deployment to your Cloudflare account** — requires your credentials. Everything up to the `wrangler deploy --dry-run` boundary is verified; a dry-run is **not** a live deploy.
- Physical-device browser testing — headless Chromium only (see `UI-RESPONSIVE-FIX-REPORT.md`).

## 11. Remaining requirements (external services & credentials)

- **Production database:** remote libSQL/Turso (or Postgres+Hyperdrive) — Workers cannot open local SQLite files. Apply migrations with `bun run db:migrate:deploy`. Local dev SQLite keeps working unchanged.
- **Bot runtime:** Cloudflare Workers CANNOT host persistent Python/Node.js bot processes. The separate runtime service (`mini-services/bot-runtime/`) must run on a small always-on Linux host — deliberate, documented architecture (`docs/RUNTIME-DEPLOYMENT.md`). Point `RUNTIME_SERVICE_URL`/`RUNTIME_API_KEY` at it.
- **Secrets:** set post-deploy via `wrangler secret put` (list in §6).
- **Optional integrations:** Google/GitHub OAuth callbacks, Resend email, Stripe (dormant) — configured via env/secrets; the app reports them honestly as "not configured" until set (`docs/SETUP.md`).

## How to apply this fix

1. Extract `BotDock-Cloud-Fixed.zip` and upload/push the **files inside `BotDock-Cloud/`** to the top level of your GitHub repo (§8 checklist) — verify `wrangler.jsonc` and `open-next.config.ts` appear at the repo root on github.com.
2. Apply the exact Workers Builds settings from §6.
3. Retry the deployment and check the log sequence in §8 step 5.
4. Add the Worker secrets (§6), then run the post-deploy route checklist (`docs/DEPLOYMENT.md` §7) against your `*.workers.dev` host.
