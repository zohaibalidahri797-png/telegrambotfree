import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Required by the `build`/`start` scripts (standalone Node server) and
  // compatible with OpenNext Cloudflare — the adapter forces the same mode
  // internally (NEXT_PRIVATE_STANDALONE=true) during `opennextjs-cloudflare build`.
  output: "standalone",
  // TypeScript errors MUST fail the build. (Previously `ignoreBuildErrors:
  // true` — removed per security/quality audit; `bunx tsc --noEmit` passes.)
  typescript: {
    ignoreBuildErrors: false,
  },
  reactStrictMode: false,
};

export default nextConfig;
