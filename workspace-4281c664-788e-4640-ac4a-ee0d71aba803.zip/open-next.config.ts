// OpenNext → Cloudflare Workers configuration.
//
// This project is a FULL-STACK Next.js app (API routes + server rendering).
// It must be deployed as a Cloudflare *Worker with static assets*, NOT as a
// static Pages site — deploying as Pages is what previously produced:
//   "Could not detect a directory containing static files"
//
// Build:  bun run cf:build   → opennextjs-cloudflare build
// Deploy: bun run cf:deploy  → opennextjs-cloudflare deploy
// (build first, then deploy; never `wrangler deploy` on an unbuilt repo)

import { defineCloudflareConfig } from "@opennextjs/cloudflare";

export default defineCloudflareConfig({
  /**
   * Optional production caches (enable when you provision the bindings in
   * wrangler.jsonc):
   *   incrementalCache: r2IncrementalCache,   // needs R2 bucket + binding
   *   queue: doQueue,                          // needs DO binding
   *   tagCache: kvIncrementalCache,            // needs KV namespace + binding
   */
});
