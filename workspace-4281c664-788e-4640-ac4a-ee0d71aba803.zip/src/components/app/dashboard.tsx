"use client";

/**
 * Dashboard views: overview, bots list (+ create flows: template / upload /
 * github), billing & plan, account settings (profile, password, sessions,
 * GitHub token, resend verification), support page.
 */

import { useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  Bot as BotIcon,
  CheckCircle2,
  CreditCard,
  Download,
  FileArchive,
  Github,
  KeyRound,
  LifeBuoy,
  Loader2,
  Plus,
  RefreshCw,
  Rocket,
  Server,
  Trash2,
  Upload,
  XCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api, errorMessage, formatBytes, timeAgo, formatUptime, type BotsResponse, type BotSummary, type PublicPlan, type UsageResponse } from "./api";
import { navigate, useApp } from "./store";
import { EmptyState, ErrorNote, InfoNote, LoadingBlock, PageHeader, StatCard, StatusBadge } from "./ui-bits";

// ── Overview ────────────────────────────────────────────────────────────────

export function DashboardOverview() {
  const { me } = useApp();
  const [data, setData] = useState<UsageResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = () => {
    api<UsageResponse>("/api/usage").then(setData).catch((e) => setError(errorMessage(e)));
  };
  useEffect(load, []);

  if (error) return <ErrorNote message={error} />;
  if (!data) return <LoadingBlock rows={4} />;

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Welcome back, ${(me?.user.name ?? "operator").split(" ")[0]}`}
        description="Live numbers from your account — measured, not estimated."
        actions={
          <Button onClick={() => navigate("/bots")} className="shadow-[0_0_16px_rgba(139,92,246,0.25)]">
            <Plus className="mr-2 h-4 w-4" /> New bot
          </Button>
        }
      />

      <div className="grid grid-cols-2 gap-4 xl:grid-cols-4">
        <StatCard label="Total bots" value={data.botsTotal} sub={`${data.botsRunning} running`} icon={<BotIcon className="h-4 w-4" />} />
        <StatCard label="Running" value={data.botsRunning} tone="success" icon={<CheckCircle2 className="h-4 w-4" />} />
        <StatCard label="Failed" value={data.botsFailed} tone={data.botsFailed > 0 ? "danger" : "default"} icon={<XCircle className="h-4 w-4" />} />
        <StatCard label="Hosting" value="Free" sub="free during launch" tone="warning" icon={<CreditCard className="h-4 w-4" />} />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Resource usage</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Bots hosted</span>
              <span className="font-medium tabular-nums">{data.botsTotal}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Workspace storage used</span>
              <span className="font-medium tabular-nums">{formatBytes(data.storageBytes)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Deployments today</span>
              <span className="font-medium tabular-nums">{data.deploymentsToday}</span>
            </div>
            <p className="border-t pt-3 text-xs text-muted-foreground">
              Per-bot protection: {data.resourcePolicy.memoryMbPerBot} MB memory · {data.resourcePolicy.cpuPercent}% CPU share · {data.resourcePolicy.diskMbPerBot} MB disk. This is system-wide infrastructure policy that keeps every bot safe — not a plan allowance.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Recent deployments</CardTitle>
          </CardHeader>
          <CardContent>
            {data.recentDeployments.length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">No deployments yet — create a bot and press Deploy.</p>
            ) : (
              <ul className="space-y-3">
                {data.recentDeployments.map((d) => (
                  <li key={d.id} className="flex items-center justify-between gap-2 text-sm">
                    <div className="min-w-0">
                      <p className="truncate font-medium">{d.botName} <span className="text-muted-foreground">#{d.number}</span></p>
                      <p className="text-xs text-muted-foreground">{timeAgo(d.createdAt)}</p>
                    </div>
                    <StatusBadge status={d.status} />
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Your bots</CardTitle>
        </CardHeader>
        <CardContent>
          {data.bots.length === 0 ? (
            <EmptyState
              icon={<BotIcon className="h-6 w-6" />}
              title="No bots yet"
              description="Create your first bot from a template, an archive, or a GitHub repository."
              action={<Button onClick={() => navigate("/bots")} className="shadow-[0_0_16px_rgba(139,92,246,0.25)]"><Plus className="mr-2 h-4 w-4" />Create a bot</Button>}
            />
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {data.bots.map((b) => (
                <button key={b.id} onClick={() => navigate(`/bots/${b.id}`)} className="flex items-center justify-between rounded-lg border p-3 text-left transition-colors hover:border-violet-500/40">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{b.name}</p>
                    <p className="text-xs text-muted-foreground">{b.runtime}</p>
                  </div>
                  <StatusBadge status={b.status} pulse />
                </button>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ── Bots list + create ──────────────────────────────────────────────────────

interface TemplateInfo {
  id: string;
  name: string;
  runtime: string;
  description: string;
}

const RUNTIMES = ["PYTHON", "NODE", "BUN"] as const;

function CreateBotDialog({ onCreated }: { onCreated: (id: string) => void }) {
  const { me } = useApp();
  const [open, setOpen] = useState(false);
  const [tab, setTab] = useState<"template" | "upload" | "github">("template");
  const [templates, setTemplates] = useState<TemplateInfo[]>([]);
  const [name, setName] = useState("");
  const [runtime, setRuntime] = useState<string>("PYTHON");
  const [templateId, setTemplateId] = useState("");
  const [description, setDescription] = useState("");
  const [startCommand, setStartCommand] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [repo, setRepo] = useState("");
  const [branch, setBranch] = useState("main");
  const [repos, setRepos] = useState<Array<{ fullName: string; defaultBranch: string }>>([]);
  const [githubConfigured, setGithubConfigured] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const allowedRuntimes = me?.plan.limits.runtimes ?? RUNTIMES;

  useEffect(() => {
    if (!open) return;
    // templates are public data served by the plans/bots endpoints; fetch once
    api<{ templates?: TemplateInfo[] }>("/api/templates").then((d) => setTemplates(d.templates ?? [])).catch(() => setTemplates([]));
    api<{ configured: boolean }>("/api/github/token").then((d) => setGithubConfigured(d.configured)).catch(() => undefined);
  }, [open]);

  useEffect(() => {
    if (runtime === "PYTHON") setTemplateId("python-keepalive");
    else if (runtime === "NODE") setTemplateId("node-keepalive");
    else setTemplateId("bun-keepalive");
  }, [runtime]);

  const loadRepos = async () => {
    setError(null);
    try {
      const d = await api<{ repos: Array<{ fullName: string; defaultBranch: string }> }>("/api/github/repos");
      setRepos(d.repos);
      if (d.repos.length === 0) setError("No repositories visible for this token.");
    } catch (e) {
      setError(errorMessage(e));
    }
  };

  const create = async () => {
    setBusy(true);
    setError(null);
    try {
      if (tab === "template") {
        const d = await api<{ bot: { id: string } }>("/api/bots", {
          method: "POST",
          json: { name, runtime, sourceType: "TEMPLATE", templateId, description, startCommand },
        });
        onCreated(d.bot.id);
      } else if (tab === "upload") {
        if (!file) {
          setError("Choose a .zip or .tar.gz archive first.");
          setBusy(false);
          return;
        }
        const form = new FormData();
        form.set("name", name);
        form.set("runtime", runtime);
        form.set("description", description);
        form.set("startCommand", startCommand);
        form.set("file", file);
        const d = await api<{ bot: { id: string } }>("/api/bots/upload", { method: "POST", body: form });
        onCreated(d.bot.id);
      } else {
        if (!repo.includes("/")) {
          setError("Repository must look like owner/name.");
          setBusy(false);
          return;
        }
        const d = await api<{ bot: { id: string } }>("/api/github/import", {
          method: "POST",
          json: { name, repo, branch, runtime, description, startCommand },
        });
        onCreated(d.bot.id);
      }
      setOpen(false);
      reset();
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const reset = () => {
    setName("");
    setDescription("");
    setStartCommand("");
    setFile(null);
    setRepo("");
    setBranch("main");
  };

  const canSubmit = name.trim().length > 0 && (tab !== "upload" || file !== null) && (tab !== "github" || repo.includes("/"));

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="shadow-[0_0_16px_rgba(139,92,246,0.25)]"><Plus className="mr-2 h-4 w-4" /> New bot</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[85vh] max-w-lg overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create a new bot</DialogTitle>
          <DialogDescription>Pick a source, choose a runtime, and BotDock will prepare the workspace. Deploy when ready.</DialogDescription>
        </DialogHeader>
        <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="template"><Rocket className="mr-1.5 h-3.5 w-3.5" />Template</TabsTrigger>
            <TabsTrigger value="upload"><Upload className="mr-1.5 h-3.5 w-3.5" />Archive</TabsTrigger>
            <TabsTrigger value="github"><Github className="mr-1.5 h-3.5 w-3.5" />GitHub</TabsTrigger>
          </TabsList>

          <div className="mt-4 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="bot-name">Bot name</Label>
              <Input id="bot-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="my-echo-bot" maxLength={50} />
            </div>
            <div className="space-y-1.5">
              <Label>Runtime</Label>
              <Select value={runtime} onValueChange={setRuntime}>
                <SelectTrigger aria-label="Runtime"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {RUNTIMES.map((r) => (
                    <SelectItem key={r} value={r} disabled={!allowedRuntimes.includes(r)}>
                      {r === "PYTHON" ? "Python" : r === "NODE" ? "Node.js" : "Bun"} {!allowedRuntimes.includes(r) ? "(not in plan)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <TabsContent value="template" className="mt-0 space-y-4">
              <div className="space-y-1.5">
                <Label>Template</Label>
                {templates.length === 0 ? (
                  <Select value={templateId} onValueChange={setTemplateId}>
                    <SelectTrigger aria-label="Template"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="python-keepalive">Python keep-alive bot (stdlib)</SelectItem>
                      <SelectItem value="python-telegram-echo">Python Telegram echo bot</SelectItem>
                      <SelectItem value="node-keepalive">Node.js keep-alive bot (stdlib)</SelectItem>
                      <SelectItem value="node-telegram-echo">Node.js Telegram echo bot</SelectItem>
                      <SelectItem value="bun-keepalive">Bun keep-alive bot</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <Select value={templateId} onValueChange={setTemplateId}>
                    <SelectTrigger aria-label="Template"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {templates.filter((t) => t.runtime === runtime).map((t) => (
                        <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              </div>
            </TabsContent>

            <TabsContent value="upload" className="mt-0 space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="bot-archive">Project archive (.zip / .tar / .tar.gz, max 20 MB)</Label>
                <Input id="bot-archive" ref={fileRef} type="file" accept=".zip,.tar,.tar.gz,.tgz" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
                <p className="text-xs text-muted-foreground">Extracted safely into the bot workspace. Include requirements.txt or package.json for dependencies.</p>
              </div>
            </TabsContent>

            <TabsContent value="github" className="mt-0 space-y-4">
              {githubConfigured ? (
                <>
                  <div className="space-y-1.5">
                    <Label>Repository</Label>
                    <div className="flex gap-2">
                      <Input value={repo} onChange={(e) => setRepo(e.target.value)} placeholder="owner/repo" />
                      <Button type="button" variant="outline" onClick={loadRepos}>List</Button>
                    </div>
                    {repos.length > 0 ? (
                      <Select value={repo} onValueChange={(v) => { setRepo(v); const r = repos.find((x) => x.fullName === v); if (r) setBranch(r.defaultBranch); }}>
                        <SelectTrigger aria-label="Pick repository"><SelectValue placeholder="Pick from your repos" /></SelectTrigger>
                        <SelectContent className="max-h-60">
                          {repos.map((r) => <SelectItem key={r.fullName} value={r.fullName}>{r.fullName}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    ) : null}
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="bot-branch">Branch</Label>
                    <Input id="bot-branch" value={branch} onChange={(e) => setBranch(e.target.value)} />
                  </div>
                </>
              ) : (
                <InfoNote>
                  GitHub is not connected yet. Add a Personal Access Token in <button className="underline" onClick={() => { setOpen(false); navigate("/settings"); }}>Account settings → GitHub</button>.
                </InfoNote>
              )}
            </TabsContent>

            <div className="space-y-1.5">
              <Label htmlFor="bot-desc">Description (optional)</Label>
              <Input id="bot-desc" value={description} onChange={(e) => setDescription(e.target.value)} maxLength={300} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="bot-cmd">Start command (optional)</Label>
              <Input id="bot-cmd" value={startCommand} onChange={(e) => setStartCommand(e.target.value)} placeholder="Auto-detected when empty (main.py, index.js, …)" className="font-mono text-xs" />
            </div>

            {error ? <ErrorNote message={error} /> : null}
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={create} disabled={busy || !canSubmit} className="shadow-[0_0_16px_rgba(139,92,246,0.25)]">
                {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
                Create bot
              </Button>
            </div>
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

export function BotsList() {
  const [data, setData] = useState<BotsResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { refreshMe } = useApp();

  const load = () => {
    api<BotsResponse>("/api/bots").then(setData).catch((e) => setError(errorMessage(e)));
  };
  useEffect(load, []);

  if (error) return <ErrorNote message={error} />;
  if (!data) return <LoadingBlock rows={3} />;

  return (
    <div className="space-y-6">
      <PageHeader
        title="My bots"
        description={`${data.usage.botsUsed} bot${data.usage.botsUsed === 1 ? "" : "s"} hosted — create and manage as many as your work needs. Hosting is free during launch.`}
        actions={<CreateBotDialog onCreated={(id) => { void refreshMe(); navigate(`/bots/${id}`); }} />}
      />

      {data.runtimeNote ? <InfoNote>{data.runtimeNote}</InfoNote> : null}

      {data.bots.length === 0 ? (
        <EmptyState
          icon={<BotIcon className="h-6 w-6" />}
          title="No bots yet"
          description="Create your first bot from a template, a project archive, or a GitHub repository — hosting is free during launch, no payment required."
          action={<CreateBotDialog onCreated={(id) => { void refreshMe(); navigate(`/bots/${id}`); }} />}
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {data.bots.map((bot) => (
            <BotCard key={bot.id} bot={bot} />
          ))}
        </div>
      )}
    </div>
  );
}

function BotCard({ bot }: { bot: BotSummary }) {
  return (
    <Card className="transition-colors hover:border-violet-500/40">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <button onClick={() => navigate(`/bots/${bot.id}`)} className="min-w-0 text-left">
            <CardTitle className="break-words text-base hover:text-violet-300">{bot.name}</CardTitle>
          </button>
          <StatusBadge status={bot.status} pulse />
        </div>
        <CardDescription className="line-clamp-2 min-h-8">{bot.description || "No description"}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
          <Badge variant="outline">{bot.runtime}</Badge>
          <Badge variant="outline">{bot.sourceType.toLowerCase()}</Badge>
          {bot.memoryMb !== null ? <Badge variant="outline" className="tabular-nums">mem: {typeof bot.memoryMb === "number" ? `${bot.memoryMb} MB` : "unknown"}</Badge> : null}
          {bot.uptimeSec !== null ? <Badge variant="outline" className="tabular-nums">up: {formatUptime(bot.uptimeSec)}</Badge> : null}
        </div>
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {bot.lastDeployedAt ? `Deployed ${timeAgo(bot.lastDeployedAt)}` : "Never deployed"}
          </span>
          <Button size="sm" variant="outline" onClick={() => navigate(`/bots/${bot.id}`)}>
            Manage
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Plan & usage (free-first launch) ────────────────────────────────────────

export function BillingView() {
  const { me } = useApp();
  const [usage, setUsage] = useState<UsageResponse | null>(null);
  const [payments, setPayments] = useState<Array<{ id: string; amountLabel: string; status: string; provider: string; description: string; createdAt: string }>>([]);
  const [freeOnly, setFreeOnly] = useState(true);
  const [launchNote, setLaunchNote] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = () => {
    api<UsageResponse>("/api/usage").then(setUsage).catch((e) => setError(errorMessage(e)));
    api<{ payments: typeof payments }>("/api/subscription").then((d) => setPayments(d.payments)).catch(() => undefined);
    api<{ plans: PublicPlan[]; freeOnly?: boolean; note?: string | null }>("/api/plans")
      .then((d) => {
        setFreeOnly(d.freeOnly !== false);
        setLaunchNote(d.note ?? null);
      })
      .catch(() => undefined);
  };
  useEffect(load, []);

  const plan = me?.plan;

  return (
    <div className="space-y-6">
      <PageHeader title="Plan & usage" description={`Current plan: ${plan?.name ?? "—"}. Hosting is free during launch — every number below is measured from real usage, not rationed.`} />

      {error ? <ErrorNote message={error} /> : null}
      {freeOnly ? (
        <InfoNote>
          <span className="font-semibold">Free during launch.</span>{" "}
          {launchNote ?? "Every account gets the free hosting plan automatically — no payment method, no subscription, and no checkout is required."}
        </InfoNote>
      ) : null}

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Hosted bots</CardDescription>
            <CardTitle className="text-2xl tabular-nums">{usage ? usage.botsTotal : "—"}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground">{usage ? `${usage.botsRunning} running · ${usage.botsStopped} stopped · ${usage.botsFailed} failed` : ""}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Storage used</CardDescription>
            <CardTitle className="text-2xl tabular-nums">{usage ? formatBytes(usage.storageBytes) : "—"}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground">Bot project files, uploads and runtime data.</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Deployments today</CardDescription>
            <CardTitle className="text-2xl tabular-nums">{usage ? usage.deploymentsToday : "—"}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground">The daily window resets at 00:00 UTC.</p>
          </CardContent>
        </Card>
      </div>

      {usage ? (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">About your hosting</CardTitle>
            <CardDescription>Free during launch — real capabilities, not a plan tier.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <ul className="grid gap-1.5 text-sm text-muted-foreground sm:grid-cols-2">
              {usage.plan.features.map((f) => (
                <li key={f} className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-cyan-400" />
                  <span>{f}</span>
                </li>
              ))}
            </ul>
            <p className="border-t pt-3 text-xs text-muted-foreground">
              Per-bot protection: {usage.resourcePolicy.memoryMbPerBot} MB memory · {usage.resourcePolicy.cpuPercent}% CPU share · {usage.resourcePolicy.diskMbPerBot} MB disk — system-wide infrastructure policy (not a plan allowance) so one bot can never starve the others. {usage.capacityNote}
            </p>
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">Billing history</CardTitle>
          <CardDescription>Only verified payments appear here. BotDock Cloud is free during launch, so this list is expected to stay empty.</CardDescription>
        </CardHeader>
        <CardContent>
          {payments.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">No billing records — nothing has ever been charged.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Provider</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payments.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell className="whitespace-nowrap text-xs">{new Date(p.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-xs">{p.description}</TableCell>
                    <TableCell className="text-xs">{p.provider}</TableCell>
                    <TableCell className="text-xs tabular-nums">{p.amountLabel}</TableCell>
                    <TableCell><Badge variant="outline">{p.status}</Badge></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// ── Account settings ────────────────────────────────────────────────────────

export function AccountSettings() {
  const { me, refreshMe } = useApp();
  const [name, setName] = useState(me?.user.name ?? "");
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);
  const [verifyMsg, setVerifyMsg] = useState<string | null>(null);
  const [verifyLink, setVerifyLink] = useState<string | null>(null);

  // password change
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [pwMsg, setPwMsg] = useState<string | null>(null);
  const [pwError, setPwError] = useState<string | null>(null);
  const [busyPw, setBusyPw] = useState(false);

  // sessions
  const [sessions, setSessions] = useState<Array<{ id: string; ip: string | null; userAgent: string | null; createdAt: string }>>([]);

  // github
  const [ghConfigured, setGhConfigured] = useState(false);
  const [ghToken, setGhToken] = useState("");
  const [ghMsg, setGhMsg] = useState<string | null>(null);
  const [ghError, setGhError] = useState<string | null>(null);

  const loadSessions = () => api<{ sessions: typeof sessions }>("/api/auth/sessions").then((d) => setSessions(d.sessions)).catch(() => undefined);

  useEffect(() => {
    loadSessions();
    api<{ configured: boolean }>("/api/github/token").then((d) => setGhConfigured(d.configured)).catch(() => undefined);
  }, []);

  const saveProfile = async () => {
    setSavingProfile(true);
    setProfileMsg(null);
    try {
      await api("/api/settings/profile", { method: "PATCH", json: { name } });
      await refreshMe();
      setProfileMsg("Profile updated.");
    } catch (e) {
      setProfileMsg(errorMessage(e));
    } finally {
      setSavingProfile(false);
    }
  };

  const resendVerification = async () => {
    setVerifyMsg(null);
    setVerifyLink(null);
    try {
      const res = await api<{ emailDelivery: { note: string }; devVerificationLink?: string }>("/api/auth/resend-verification", { method: "POST" });
      setVerifyMsg(res.emailDelivery.note);
      if (res.devVerificationLink) setVerifyLink(res.devVerificationLink);
    } catch (e) {
      setVerifyMsg(errorMessage(e));
    }
  };

  const changePassword = async () => {
    setBusyPw(true);
    setPwError(null);
    setPwMsg(null);
    try {
      await api("/api/settings/password", { method: "POST", json: { currentPassword: currentPw, newPassword: newPw } });
      setPwMsg("Password changed. Other sessions were signed out.");
      setCurrentPw("");
      setNewPw("");
      loadSessions();
    } catch (e) {
      setPwError(errorMessage(e));
    } finally {
      setBusyPw(false);
    }
  };

  const revokeAll = async () => {
    await api("/api/auth/sessions", { method: "DELETE", json: { all: true } }).catch(() => undefined);
    window.location.hash = "/login";
    window.location.reload();
  };

  const saveGithub = async () => {
    setGhError(null);
    setGhMsg(null);
    try {
      const res = await api<{ note: string }>("/api/github/token", { method: "PUT", json: { token: ghToken } });
      setGhMsg(res.note);
      setGhToken("");
      setGhConfigured(true);
    } catch (e) {
      setGhError(errorMessage(e));
    }
  };

  const removeGithub = async () => {
    await api("/api/github/token", { method: "DELETE" }).catch(() => undefined);
    setGhConfigured(false);
    setGhMsg("GitHub token removed.");
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Account settings" description={me?.user.email} />

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Profile</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="acc-name">Display name</Label>
            <div className="flex max-w-md gap-2">
              <Input id="acc-name" value={name} onChange={(e) => setName(e.target.value)} maxLength={80} />
              <Button onClick={saveProfile} disabled={savingProfile}>{savingProfile ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}</Button>
            </div>
          </div>
          {profileMsg ? <p className="text-xs text-muted-foreground">{profileMsg}</p> : null}
          {!me?.user.emailVerified ? (
            <div className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-sm">
              <p className="font-medium text-amber-500">Email not verified</p>
              <p className="mt-1 text-xs text-amber-500/90">Deployment is locked until your email is verified.</p>
              <Button size="sm" variant="outline" className="mt-2" onClick={resendVerification}>Resend verification email</Button>
              {verifyMsg ? <p className="mt-2 text-xs">{verifyMsg}</p> : null}
              {verifyLink ? (
                <a href={verifyLink} className="mt-2 block text-xs font-medium text-sky-400 underline">Development mode: open verification link</a>
              ) : null}
            </div>
          ) : (
            <p className="flex items-center gap-1.5 text-sm text-emerald-500"><CheckCircle2 className="h-4 w-4" /> Email verified</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Change password</CardTitle></CardHeader>
        <CardContent className="max-w-md space-y-4">
          {pwError ? <ErrorNote message={pwError} /> : null}
          {pwMsg ? <InfoNote>{pwMsg}</InfoNote> : null}
          <div className="space-y-1.5">
            <Label htmlFor="cur-pw">Current password</Label>
            <Input id="cur-pw" type="password" value={currentPw} onChange={(e) => setCurrentPw(e.target.value)} autoComplete="current-password" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="new-pw">New password</Label>
            <Input id="new-pw" type="password" value={newPw} onChange={(e) => setNewPw(e.target.value)} autoComplete="new-password" />
            <p className="text-xs text-muted-foreground">At least 8 characters with a letter and a digit. All other sessions will be signed out.</p>
          </div>
          <Button onClick={changePassword} disabled={busyPw || !currentPw || !newPw}>
            {busyPw ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <KeyRound className="mr-2 h-4 w-4" />} Update password
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm">GitHub integration</CardTitle>
          <CardDescription>Needed to import repositories. Use a fine-grained token with read-only &quot;Contents&quot; access, or a classic token with `public_repo`/`repo`.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {ghMsg ? <InfoNote>{ghMsg}</InfoNote> : null}
          {ghError ? <ErrorNote message={ghError} /> : null}
          <div className="flex max-w-md gap-2">
            <Input type="password" placeholder={ghConfigured ? "Token stored — paste a new one to replace" : "ghp_… / github_pat_…"} value={ghToken} onChange={(e) => setGhToken(e.target.value)} />
            <Button onClick={saveGithub} disabled={ghToken.length < 20}><Github className="mr-2 h-4 w-4" /> Save</Button>
            {ghConfigured ? <Button variant="outline" onClick={removeGithub}>Remove</Button> : null}
          </div>
          <p className="text-xs text-muted-foreground">The token is encrypted at rest and never displayed again. It is used server-side only.</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3"><CardTitle className="text-sm">Active sessions</CardTitle></CardHeader>
        <CardContent className="space-y-3">
          {sessions.length === 0 ? (
            <p className="text-sm text-muted-foreground">No active sessions found.</p>
          ) : (
            <ul className="space-y-2">
              {sessions.map((s) => (
                <li key={s.id} className="rounded-lg border p-3 text-xs">
                  <p className="font-medium">{s.ip ?? "unknown IP"}</p>
                  <p className="truncate text-muted-foreground">{s.userAgent ?? "unknown client"}</p>
                  <p className="mt-1 text-muted-foreground">Started {timeAgo(s.createdAt)}</p>
                </li>
              ))}
            </ul>
          )}
          <Button variant="destructive" onClick={revokeAll}><Trash2 className="mr-2 h-4 w-4" /> Sign out everywhere</Button>
        </CardContent>
      </Card>
    </div>
  );
}

// ── Support ─────────────────────────────────────────────────────────────────

export function SupportView() {
  const { me } = useApp();
  return (
    <div className="space-y-6">
      <PageHeader title="Support & help" description="Answers to common questions about BotDock Cloud." />
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm"><LifeBuoy className="h-4 w-4 text-violet-400" /> Contact</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            <p>Support email: <span className="font-mono text-foreground">support@botdock.cloud</span></p>
            <p className="mt-1">{me?.plan.limits.allowedFeatures.prioritySupport ? "Your plan includes priority support — expect a response within 24h." : "Standard support: responses within a few days. Priority support is available on Pro and Scale plans."}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm"><Download className="h-4 w-4 text-violet-400" /> Release archives</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2 text-sm">
            <Button asChild variant="outline" size="sm"><a href="/api/download?file=botdock-cloud.zip"><FileArchive className="mr-2 h-4 w-4" /> botdock-cloud.zip</a></Button>
            <Button asChild variant="outline" size="sm"><a href="/api/download?file=botdock-cloud.tar.gz"><FileArchive className="mr-2 h-4 w-4" /> botdock-cloud.tar.gz</a></Button>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm">Frequently asked</CardTitle></CardHeader>
        <CardContent className="space-y-4 text-sm">
          <div>
            <p className="font-medium">Why can&apos;t I deploy?</p>
            <p className="text-muted-foreground">Deployment requires a verified email, free deployment quota, and an online runtime service. Check the banner at the top of the dashboard and the usage counters on this page.</p>
          </div>
          <div>
            <p className="font-medium">My bot shows FAILED — what now?</p>
            <p className="text-muted-foreground">Open the bot → Logs tab. Build logs show dependency installation output; runtime logs show why the process exited. Fix the issue and deploy again.</p>
          </div>
          <div>
            <p className="font-medium">Are environment variables safe?</p>
            <p className="text-muted-foreground">They are encrypted at rest with AES-256-GCM, injected only into your bot&apos;s isolated process, and never displayed in the UI after saving.</p>
          </div>
          <div>
            <p className="font-medium">Can bots sleep on the free plan?</p>
            <p className="text-muted-foreground">Free bots share limited infrastructure and may be restarted by the platform under load. This is disclosed up front rather than promised away.</p>
          </div>
          <div>
            <p className="font-medium"><AlertTriangle className="mr-1 inline h-3.5 w-3.5 text-amber-500" /> What happens when I hit a limit?</p>
            <p className="text-muted-foreground">APIs reject the operation with a clear message — for example, creating a bot beyond your plan quota fails with an explanation of the limit. Limits cannot be bypassed client-side because every check runs on the server.</p>
          </div>
          <div>
            <p className="font-medium flex items-center gap-1.5"><Server className="h-3.5 w-3.5" /> Runtime vs. dashboard</p>
            <p className="text-muted-foreground">The dashboard (this website) is the control plane. Bots execute in a separate runtime service. If &quot;Runtime offline&quot; appears, the dashboard still works but bots can&apos;t start/stop until the runtime is back.</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-2"><CardTitle className="text-sm">Quick actions</CardTitle></CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => navigate("/bots")}><RefreshCw className="mr-2 h-4 w-4" /> Go to my bots</Button>
          <Button variant="outline" size="sm" onClick={() => navigate("/billing")}><CreditCard className="mr-2 h-4 w-4" /> Plan & usage</Button>
        </CardContent>
      </Card>
      <Textarea className="hidden" aria-hidden />
    </div>
  );
}
