"use client";

/**
 * Auth views: login, register, forgot-password, reset-password.
 * Reads OAuth/verification outcomes from hash query params and shows clear,
 * honest messages (e.g. when email delivery or OAuth isn't configured).
 */

import { useEffect, useState } from "react";

import { Bot, Github, Loader2, Mail, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { api, errorMessage } from "./api";
import { navigate, useApp } from "./store";
import { ErrorNote, HashLink, InfoNote } from "./ui-bits";

interface AuthConfig {
  google: boolean;
  githubOAuth: boolean;
  emailConfigured: boolean;
  /** Fresh production deployment: first registration needs ADMIN_BOOTSTRAP_TOKEN. */
  bootstrapRequired?: boolean;
}

function useAuthConfig(): AuthConfig | null {
  const [config, setConfig] = useState<AuthConfig | null>(null);
  useEffect(() => {
    api<AuthConfig>("/api/auth/config").then(setConfig).catch(() => setConfig({ google: false, githubOAuth: false, emailConfigured: false }));
  }, []);
  return config;
}

function OAuthButtons({ config, onError }: { config: AuthConfig | null; onError: (m: string) => void }) {
  const start = (provider: "google" | "github") => {
    if (!config) return;
    if (provider === "google" && !config.google) {
      onError("Google sign-in is not configured on this deployment. An administrator must set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET — see docs/SETUP.md.");
      return;
    }
    if (provider === "github" && !config.githubOAuth) {
      onError("GitHub sign-in is not configured on this deployment. An administrator must set GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET — see docs/SETUP.md.");
      return;
    }
    window.location.href = `/api/auth/oauth/${provider}`;
  };

  const unconfigured = config
    ? [!config.google ? "Google" : null, !config.githubOAuth ? "GitHub" : null].filter(
        (p): p is string => Boolean(p),
      )
    : [];

  return (
    <div className="space-y-2">
      <div className="grid gap-2 sm:grid-cols-2">
        <Button type="button" variant="outline" onClick={() => start("google")} disabled={!config}>
          <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" aria-hidden><path fill="currentColor" d="M21.35 11.1h-9.17v2.73h6.51c-.33 3.81-3.5 5.44-6.5 5.44C8.36 19.27 5 16.25 5 12c0-4.1 3.2-7.27 7.2-7.27 3.09 0 4.9 1.97 4.9 1.97L19 4.72S16.56 2 12.1 2C6.42 2 2.03 6.8 2.03 12c0 5.05 4.13 10 10.22 10 5.35 0 9.25-3.67 9.25-9.09 0-1.15-.15-1.81-.15-1.81Z"/></svg>
          Google
        </Button>
        <Button type="button" variant="outline" onClick={() => start("github")} disabled={!config}>
          <Github className="mr-2 h-4 w-4" />
          GitHub
        </Button>
      </div>
      {unconfigured.length > 0 ? (
        <p className="text-center text-xs text-muted-foreground" role="note">
          {unconfigured.join(" and ")} sign-in {unconfigured.length === 1 ? "is" : "are"} not
          configured on this deployment — an administrator must set the provider credentials
          first (docs/SETUP.md).
        </p>
      ) : null}
    </div>
  );
}

function useHashQuery() {
  const [query, setQuery] = useState<Record<string, string>>({});
  useEffect(() => {
    const parse = () => {
      const raw = window.location.hash.split("?")[1] ?? "";
      setQuery(Object.fromEntries(new URLSearchParams(raw).entries()));
    };
    parse();
    window.addEventListener("hashchange", parse);
    return () => window.removeEventListener("hashchange", parse);
  }, []);
  return query;
}

export function LoginView() {
  const { refreshMe } = useApp();
  const config = useAuthConfig();
  const query = useHashQuery();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(
    query.error ? `${query.error.replaceAll("_", " ")}${query.detail ? ` — ${query.detail}` : ""}` : null,
  );

  useEffect(() => {
    if (query.error) setError(`${query.error.replaceAll("_", " ")}${query.detail ? ` — ${decodeURIComponent(query.detail)}` : ""}`);
  }, [query.error, query.detail]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth/login", { method: "POST", json: { email, password } });
      await refreshMe();
      navigate("/dashboard");
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout title="Welcome back" subtitle="Sign in to manage your bots.">
      {error ? <ErrorNote message={error} /> : null}
      <OAuthButtons config={config} onError={setError} />
      <div className="my-4 flex items-center gap-3">
        <Separator className="flex-1" />
        <span className="text-xs text-muted-foreground">or with email</span>
        <Separator className="flex-1" />
      </div>
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="login-email">Email</Label>
          <Input id="login-email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="login-password">Password</Label>
            <HashLink href="#/forgot-password" className="text-xs text-violet-400 hover:underline">Forgot password?</HashLink>
          </div>
          <Input id="login-password" type="password" required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
        </div>
        <Button type="submit" disabled={busy} className="w-full">
          {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Sign in
        </Button>
      </form>
      <p className="mt-4 text-center text-sm text-muted-foreground">
        No account yet?{" "}
        <HashLink href="#/register" className="font-medium text-violet-400 hover:underline">Create one free</HashLink>
      </p>
    </AuthLayout>
  );
}

export function RegisterView() {
  const { refreshMe } = useApp();
  const config = useAuthConfig();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [bootstrapToken, setBootstrapToken] = useState("");
  const [showBootstrapField, setShowBootstrapField] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<{ note: string; devLink?: string; devNote?: string; signedIn: boolean } | null>(null);

  // Fresh production deployments require the one-time setup token for the
  // first (administrator) registration.
  const needsBootstrapField = showBootstrapField || Boolean(config?.bootstrapRequired);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ emailDelivery: { note: string }; devVerificationLink?: string; devNote?: string; sessionCreated?: boolean }>("/api/auth/register", {
        method: "POST",
        json: { name, email, password, ...(needsBootstrapField && bootstrapToken ? { bootstrapToken } : {}) },
      });
      // NOTE: refreshMe() is intentionally deferred to the continue button so
      // the router does not immediately redirect away from this success panel.
      setSuccess({
        note: res.emailDelivery.note,
        devLink: res.devVerificationLink,
        devNote: res.devNote,
        signedIn: res.sessionCreated === true,
      });
    } catch (err) {
      const msg = errorMessage(err);
      if (msg.includes("setup token") || msg.includes("ADMIN_BOOTSTRAP_TOKEN")) {
        setShowBootstrapField(true);
      }
      setError(msg);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout title="Create your account" subtitle={config?.bootstrapRequired ? "Setup required: the first account needs the operator's one-time setup token." : "Sign up to host your Telegram bots in the cloud — free during launch."}>
      {error ? <ErrorNote message={error} /> : null}
      {success ? (
        <div className="space-y-3">
          <InfoNote>
            <span className="font-semibold">Account created.</span> {success.note}
          </InfoNote>
          {success.devLink ? (
            <div className="rounded-lg border border-sky-500/30 bg-sky-500/10 px-4 py-3 text-sm text-sky-400">
              <p className="font-semibold">Development mode</p>
              <p className="mt-1">{success.devNote}</p>
              <a href={success.devLink} className="mt-2 inline-block font-medium underline">Open verification link</a>
            </div>
          ) : null}
          {success.signedIn ? (
            <Button
              onClick={async () => {
                await refreshMe();
                navigate("/dashboard");
              }}
              className="w-full"
            >
              Continue to dashboard
            </Button>
          ) : (
            <p className="text-center text-sm text-muted-foreground">
              Sign in with your new account once your email is verified.
            </p>
          )}
          {success.signedIn ? (
            <p className="text-center text-xs text-muted-foreground">
              Deploying stays locked until your email address is verified.
            </p>
          ) : null}
        </div>
      ) : (
        <>
          <OAuthButtons config={config} onError={setError} />
          <div className="my-4 flex items-center gap-3">
            <Separator className="flex-1" />
            <span className="text-xs text-muted-foreground">or with email</span>
            <Separator className="flex-1" />
          </div>
          <form onSubmit={submit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="reg-name">Name</Label>
              <Input id="reg-name" required maxLength={80} value={name} onChange={(e) => setName(e.target.value)} placeholder="Ada Lovelace" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="reg-email">Email</Label>
              <Input id="reg-email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="reg-password">Password</Label>
              <Input id="reg-password" type="password" required minLength={8} autoComplete="new-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="At least 8 characters, 1 letter + 1 digit" />
              <p className="text-xs text-muted-foreground">Minimum 8 characters with at least one letter and one digit.</p>
            </div>
            {needsBootstrapField ? (
              <div className="space-y-1.5">
                <Label htmlFor="reg-bootstrap">Setup token (first administrator only)</Label>
                <Input id="reg-bootstrap" type="password" value={bootstrapToken} onChange={(e) => setBootstrapToken(e.target.value)} placeholder="ADMIN_BOOTSTRAP_TOKEN value" autoComplete="off" />
                <p className="text-xs text-muted-foreground">
                  One-time token configured by the platform operator. It grants administrator role to the FIRST account only and is not needed afterwards.
                </p>
              </div>
            ) : null}
            <Button type="submit" disabled={busy} className="w-full">
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Create account
            </Button>
          </form>
          <p className="mt-4 text-center text-sm text-muted-foreground">
            Already registered?{" "}
            <HashLink href="#/login" className="font-medium text-violet-400 hover:underline">Sign in</HashLink>
          </p>
        </>
      )}
    </AuthLayout>
  );
}

export function ForgotPasswordView() {
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ detail: string; devLink?: string; devNote?: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await api<{ detail: string; devResetLink?: string; devNote?: string }>("/api/auth/forgot-password", {
        method: "POST",
        json: { email },
      });
      setDone({ detail: res.detail, devLink: res.devResetLink, devNote: res.devNote });
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout title="Reset your password" subtitle="We generate a reset link valid for one hour.">
      {error ? <ErrorNote message={error} /> : null}
      {done ? (
        <div className="space-y-3">
          <InfoNote>{done.detail}</InfoNote>
          {done.devLink ? (
            <div className="rounded-lg border border-sky-500/30 bg-sky-500/10 px-4 py-3 text-sm text-sky-400">
              <p className="font-semibold">Development mode</p>
              <p className="mt-1">{done.devNote}</p>
              <a href={done.devLink} className="mt-2 inline-block font-medium underline">Open reset link</a>
            </div>
          ) : null}
          <p className="text-center">
            <HashLink href="#/login" className="text-sm text-violet-400 hover:underline">Back to sign in</HashLink>
          </p>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="forgot-email">Email</Label>
            <Input id="forgot-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
          </div>
          <Button type="submit" disabled={busy} className="w-full">
            {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Mail className="mr-2 h-4 w-4" />}
            Send reset link
          </Button>
          <p className="text-center">
            <HashLink href="#/login" className="text-sm text-muted-foreground hover:text-foreground">Back to sign in</HashLink>
          </p>
        </form>
      )}
    </AuthLayout>
  );
}

export function ResetPasswordView() {
  const query = useHashQuery();
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  const token = query.token ?? "";

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm) {
      setError("Passwords do not match.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await api("/api/auth/reset-password", { method: "POST", json: { token, password } });
      setDone(true);
      setTimeout(() => navigate("/login"), 2000);
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  if (!token) {
    return (
      <AuthLayout title="Reset your password" subtitle="This page needs a reset token.">
        <ErrorNote message="Missing reset token. Use the link from your password reset email." />
        <p className="mt-4 text-center">
          <HashLink href="#/forgot-password" className="text-sm text-violet-400 hover:underline">Request a new link</HashLink>
        </p>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout title="Choose a new password" subtitle="All existing sessions will be signed out after the change.">
      {error ? <ErrorNote message={error} /> : null}
      {done ? (
        <InfoNote>Password updated. Redirecting to sign in…</InfoNote>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="reset-pw">New password</Label>
            <Input id="reset-pw" type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="reset-pw2">Confirm password</Label>
            <Input id="reset-pw2" type="password" required minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)} />
          </div>
          <Button type="submit" disabled={busy} className="w-full">
            {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <ShieldCheck className="mr-2 h-4 w-4" />}
            Update password
          </Button>
        </form>
      )}
    </AuthLayout>
  );
}

/**
 * Email verification view — handles the legacy `#/verify?token=…` link style.
 * The verification itself is performed by GET /api/auth/verify-email (which
 * renders its own confirmation page); this view simply forwards the token
 * there with a visible loading state instead of dead-ending.
 */
export function VerifyEmailView() {
  const query = useHashQuery();
  const token = query.token ?? "";
  useEffect(() => {
    if (token) window.location.replace(`/api/auth/verify-email?token=${encodeURIComponent(token)}`);
  }, [token]);

  return (
    <AuthLayout title="Verify your email" subtitle="Checking your verification link…">
      {token ? (
        <InfoNote>
          <span className="inline-flex items-center gap-2">
            <Loader2 className="h-4 w-4 animate-spin" /> Redirecting to complete verification…
          </span>
        </InfoNote>
      ) : (
        <>
          <ErrorNote message="Missing verification token. Use the link from your verification email, or request a new email from your dashboard." />
          <p className="mt-4 text-center">
            <HashLink href="#/login" className="text-sm text-violet-400 hover:underline">Back to sign in</HashLink>
          </p>
        </>
      )}
    </AuthLayout>
  );
}

function AuthLayout({ title, subtitle, children }: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-muted/20">
      <div className="flex items-center justify-center px-4 py-10">
        <HashLink href="/" className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-violet-500/25 to-cyan-500/20 ring-1 ring-violet-500/40">
            <Bot className="h-5 w-5 text-violet-400" />
          </span>
          <span className="text-lg font-bold">BotDock <span className="text-gradient">Cloud</span></span>
        </HashLink>
      </div>
      <main className="flex flex-1 items-start justify-center px-4 pb-16">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-xl">{title}</CardTitle>
            <CardDescription>{subtitle}</CardDescription>
          </CardHeader>
          <CardContent>{children}</CardContent>
        </Card>
      </main>
    </div>
  );
}
