/**
 * Bot lifecycle orchestration (server-only): the control plane between the
 * web app and the runtime service. All state changes flow through here so
 * DB records, notifications, usage and audit logging stay consistent.
 *
 * The runtime service is the source of truth for RUNNING/STOPPED/FAILED
 * process state; this module records what the runtime reports and never
 * invents status.
 */

import { db } from "@/lib/db";
import { decryptSecret } from "@/lib/crypto";
import { runtimeClient, isRuntimeUnavailable, type RuntimeStatus } from "@/lib/runtime-client";
import { getEffectivePlan, type EffectivePlan } from "@/lib/plans";
import { resourceLimitsForRuntime, ABUSE_GUARDS } from "@/lib/capacity";
import { rateLimit } from "@/lib/rate-limit";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/notify";
import { workspaceUsageBytes } from "@/lib/bot-fs";
import path from "node:path";

export interface ActionContext {
  actorId: string;
  actorEmail: string;
  ip: string;
  userAgent: string | null;
}

export interface ActionResult {
  ok: boolean;
  status: number;
  data?: Record<string, unknown>;
  error?: string;
  detail?: string;
}

async function botEnvVars(botId: string): Promise<Record<string, string>> {
  const rows = await db.envVar.findMany({ where: { botId } });
  const out: Record<string, string> = {};
  for (const r of rows) {
    try {
      out[r.key] = decryptSecret(r.valueEnc);
    } catch {
      // skip corrupted values rather than crashing deployments
    }
  }
  return out;
}

/**
 * Per-bot OS resource limits come from the system-wide capacity policy
 * (finite, host-aware) — NOT from the user's plan. See src/lib/capacity.ts.
 */
function runtimeLimits() {
  return resourceLimitsForRuntime();
}

// NOTE: staging is performed by the botdock-runtime service itself (it copies
// workspace/{botId} → staging/{botId}/{deploymentId} inside its deploy
// handler). The web app must not touch the local filesystem — it may run on
// Cloudflare Workers.

async function nextDeploymentNumber(botId: string): Promise<number> {
  const last = await db.deployment.findFirst({ where: { botId }, orderBy: { number: "desc" }, select: { number: true } });
  return (last?.number ?? 0) + 1;
}

export async function deployBot(botId: string, ctx: ActionContext): Promise<ActionResult> {
  const bot = await db.bot.findUnique({ where: { id: botId } });
  if (!bot || bot.userId !== ctx.actorId) return { ok: false, status: 404, error: "bot_not_found" };
  if (["BUILDING", "DEPLOYING", "DELETING"].includes(bot.status)) {
    return { ok: false, status: 409, error: "operation_in_progress", detail: `Bot is ${bot.status}; wait for it to finish.` };
  }

  const plan = await getEffectivePlan(ctx.actorId);
  if (!plan.limits.runtimes.includes(bot.runtime as "PYTHON" | "NODE" | "BUN")) {
    return { ok: false, status: 403, error: "runtime_not_enabled", detail: `The ${bot.runtime} runtime is not enabled on this deployment.` };
  }
  const user = await db.user.findUnique({ where: { id: ctx.actorId }, select: { emailVerified: true } });
  if (!user?.emailVerified) {
    return { ok: false, status: 403, error: "email_verification_required", detail: "Verify your email address before deploying bots." };
  }

  // Abuse-prevention burst guard (NOT a plan quota): protects the runtime
  // from deploy floods. Generous default (60/hour) never blocks normal use.
  const rl = await rateLimit(`deploy:${ctx.actorId}`, ABUSE_GUARDS.deployActionsPerHour, 3600);
  if (!rl.ok) {
    return {
      ok: false,
      status: 429,
      error: "too_many_deploys",
      detail: `A lot of deployments were triggered from this account in a short time. This burst limit protects the service for everyone — try again in about ${Math.ceil(rl.retryAfterSec / 60)} minute(s).`,
    };
  }

  // Deployment record
  const number = await nextDeploymentNumber(botId);
  const deployment = await db.deployment.create({
    data: {
      botId,
      number,
      status: "BUILDING",
      sourceType: bot.sourceType,
      sourceRef: bot.sourceRef,
      triggeredBy: ctx.actorEmail,
    },
  });

  await db.bot.update({ where: { id: botId }, data: { status: "BUILDING" } });

  const env = await botEnvVars(botId);
  await db.usageRecord.create({
    data: { userId: ctx.actorId, botId, kind: "DEPLOYMENT", amount: 1, unit: "count", meta: JSON.stringify({ deploymentId: deployment.id }) },
  });

  try {
    const res = await runtimeClient.deploy({
      botId,
      deploymentId: deployment.id,
      runtime: bot.runtime,
      startCommand: bot.startCommand,
      env,
      limits: runtimeLimits(),
      installTimeoutSec: 600,
    });

    const state = res.state ?? "FAILED";
    const okRun = res.ok === true && state === "RUNNING";
    await db.deployment.update({
      where: { id: deployment.id },
      data: {
        status: okRun ? "RUNNING" : "FAILED",
        error: okRun ? null : (res.error ?? `runtime reported ${state}`),
        startedAt: new Date(),
        finishedAt: okRun ? null : new Date(),
      },
    });
    await db.bot.update({
      where: { id: botId },
      data: {
        status: state,
        currentDeploymentId: deployment.id,
        lastDeployedAt: new Date(),
        ...(okRun ? { lastStartedAt: new Date() } : {}),
      },
    });

    await audit({
      actorId: ctx.actorId,
      actorEmail: ctx.actorEmail,
      action: "BOT_DEPLOY",
      targetType: "bot",
      targetId: botId,
      detail: { deploymentId: deployment.id, number, result: state, runtimeError: res.error ?? null },
      ip: ctx.ip,
      userAgent: ctx.userAgent,
    });

    if (!okRun) {
      await notify(ctx.actorId, {
        title: `Deployment failed for "${bot.name}"`,
        body: `Deployment #${number} failed${res.error ? `: ${res.error}` : ""}. Check the build logs for details.`,
        level: "ERROR",
        category: "DEPLOYMENT",
        link: `#/bots/${botId}?tab=deployments`,
      });
      return {
        ok: false,
        status: 200, // the request worked; the DEPLOYMENT failed — that's data, not an API error
        error: res.error ?? `runtime reported ${state}`,
        data: { deploymentId: deployment.id, number, state, buildLogTail: res.buildLogTail ?? [] },
      };
    }

    return { ok: true, status: 200, data: { deploymentId: deployment.id, number, state: "RUNNING", buildLogTail: res.buildLogTail ?? [] } };
  } catch (err) {
    if (isRuntimeUnavailable(err)) {
      await db.deployment.update({
        where: { id: deployment.id },
        data: { status: "FAILED", error: "runtime_unavailable", finishedAt: new Date() },
      });
      await db.bot.update({ where: { id: botId }, data: { status: "FAILED" } });
      return {
        ok: false,
        status: 503,
        error: "runtime_unavailable",
        detail: "The bot runtime service is not reachable. It may be starting — try again shortly. (Administrators can check the service health page.)",
      };
    }
    const detail = err instanceof Error ? err.message : String(err);
    await db.deployment.update({
      where: { id: deployment.id },
      data: { status: "FAILED", error: detail.slice(0, 500), finishedAt: new Date() },
    });
    await db.bot.update({ where: { id: botId }, data: { status: "FAILED" } });
    return { ok: false, status: 500, error: "deploy_failed", detail };
  }
}

export async function startBot(botId: string, ctx: ActionContext): Promise<ActionResult> {
  const bot = await db.bot.findUnique({ where: { id: botId } });
  if (!bot || bot.userId !== ctx.actorId) return { ok: false, status: 404, error: "bot_not_found" };
  if (!bot.currentDeploymentId) {
    return { ok: false, status: 409, error: "not_deployed", detail: "Deploy the bot before starting it." };
  }
  if (["BUILDING", "DEPLOYING", "DELETING"].includes(bot.status)) {
    return { ok: false, status: 409, error: "operation_in_progress" };
  }
  const env = await botEnvVars(botId);
  try {
    const res = await runtimeClient.start(botId, {
      env,
      limits: runtimeLimits(),
      startCommand: bot.startCommand || undefined,
    });
    const state = res.state ?? "FAILED";
    const okRun = res.ok === true && state === "RUNNING";
    await db.bot.update({
      where: { id: botId },
      data: { status: state, ...(okRun ? { lastStartedAt: new Date() } : {}) },
    });
    await audit({
      actorId: ctx.actorId,
      actorEmail: ctx.actorEmail,
      action: "BOT_START",
      targetType: "bot",
      targetId: botId,
      detail: { result: state, runtimeError: res.error ?? null },
      ip: ctx.ip,
      userAgent: ctx.userAgent,
    });
    if (!okRun) {
      return {
        ok: false,
        status: 200,
        error: res.error ?? `runtime reported ${state}`,
        data: { state, logTail: res.logTail ?? [] },
      };
    }
    return { ok: true, status: 200, data: { state: "RUNNING", pid: res.pid ?? null } };
  } catch (err) {
    if (isRuntimeUnavailable(err)) {
      return { ok: false, status: 503, error: "runtime_unavailable", detail: "The bot runtime service is not reachable." };
    }
    return { ok: false, status: 500, error: "start_failed", detail: err instanceof Error ? err.message : String(err) };
  }
}

export async function stopBot(botId: string, ctx: ActionContext): Promise<ActionResult> {
  const bot = await db.bot.findUnique({ where: { id: botId } });
  if (!bot || bot.userId !== ctx.actorId) return { ok: false, status: 404, error: "bot_not_found" };
  try {
    const res = await runtimeClient.stop(botId);
    await db.bot.update({ where: { id: botId }, data: { status: "STOPPED" } });
    await audit({
      actorId: ctx.actorId,
      actorEmail: ctx.actorEmail,
      action: "BOT_STOP",
      targetType: "bot",
      targetId: botId,
      detail: { killed: res.killed ?? null },
      ip: ctx.ip,
      userAgent: ctx.userAgent,
    });
    return { ok: true, status: 200, data: { state: "STOPPED" } };
  } catch (err) {
    if (isRuntimeUnavailable(err)) {
      return { ok: false, status: 503, error: "runtime_unavailable", detail: "The bot runtime service is not reachable; bot state could not be changed." };
    }
    return { ok: false, status: 500, error: "stop_failed", detail: err instanceof Error ? err.message : String(err) };
  }
}

export async function restartBot(botId: string, ctx: ActionContext): Promise<ActionResult> {
  const bot = await db.bot.findUnique({ where: { id: botId } });
  if (!bot || bot.userId !== ctx.actorId) return { ok: false, status: 404, error: "bot_not_found" };
  if (!bot.currentDeploymentId) {
    return { ok: false, status: 409, error: "not_deployed", detail: "Deploy the bot before restarting it." };
  }
  try {
    const res = await runtimeClient.restart(botId);
    const state = res.state ?? "FAILED";
    const okRun = res.ok === true && state === "RUNNING";
    await db.bot.update({
      where: { id: botId },
      data: { status: state, ...(okRun ? { lastStartedAt: new Date() } : {}) },
    });
    await audit({
      actorId: ctx.actorId,
      actorEmail: ctx.actorEmail,
      action: "BOT_RESTART",
      targetType: "bot",
      targetId: botId,
      detail: { result: state, runtimeError: res.error ?? null },
      ip: ctx.ip,
      userAgent: ctx.userAgent,
    });
    if (!okRun) {
      return { ok: false, status: 200, error: res.error ?? `runtime reported ${state}`, data: { state } };
    }
    return { ok: true, status: 200, data: { state: "RUNNING" } };
  } catch (err) {
    if (isRuntimeUnavailable(err)) {
      return { ok: false, status: 503, error: "runtime_unavailable", detail: "The bot runtime service is not reachable." };
    }
    return { ok: false, status: 500, error: "restart_failed", detail: err instanceof Error ? err.message : String(err) };
  }
}

/** Full delete: stop process, remove runtime artifacts + workspace, delete rows. */
export async function deleteBot(botId: string, ctx: ActionContext): Promise<ActionResult> {
  const bot = await db.bot.findUnique({ where: { id: botId } });
  if (!bot || bot.userId !== ctx.actorId) return { ok: false, status: 404, error: "bot_not_found" };

  await db.bot.update({ where: { id: botId }, data: { status: "DELETING" } });

  const runtimeNotes: string[] = [];
  try {
    await runtimeClient.undeploy(botId);
  } catch (err) {
    runtimeNotes.push(isRuntimeUnavailable(err) ? "runtime_unavailable" : String(err));
  }

  // Remove workspace + staging leftovers when the runtime itself could not
  // (best effort — normally the runtime's undeploy handler removes them).
  // Dynamic import: the web app may run on Cloudflare Workers where there is
  // no persistent local filesystem — the runtime undeploy is the authoritative
  // cleanup in that topology.
  try {
    const fs = await import("node:fs");
    const dataDir = path.resolve(process.cwd(), process.env.RUNTIME_DATA_DIR ?? "./bot-data");
    fs.rmSync(path.join(dataDir, "workspace", botId), { recursive: true, force: true });
    fs.rmSync(path.join(dataDir, "staging", botId), { recursive: true, force: true });
  } catch {
    // best effort
  }

  await db.bot.delete({ where: { id: botId } });
  await audit({
    actorId: ctx.actorId,
    actorEmail: ctx.actorEmail,
    action: "BOT_DELETE",
    targetType: "bot",
    targetId: botId,
    detail: { name: bot.name, runtimeNotes },
    ip: ctx.ip,
    userAgent: ctx.userAgent,
  });
  return { ok: true, status: 200, data: { deleted: true, runtimeNotes } };
}

/** Live status for detail views: DB row + runtime snapshot when reachable. */
export async function botWithRuntimeStatus(botId: string, userId: string, isAdminView = false) {
  const bot = await db.bot.findUnique({
    where: { id: botId },
    include: {
      deployments: { orderBy: { number: "desc" }, take: 20 },
    },
  });
  if (!bot) return null;
  if (!isAdminView && bot.userId !== userId) return null;

  let runtime: (RuntimeStatus & Record<string, unknown>) | null = null;
  let runtimeReachable = false;
  let runtimeError: string | null = null;
  try {
    const res = await runtimeClient.status(botId);
    runtimeReachable = true;
    const { status: _s, ...rest } = res;
    runtime = rest as RuntimeStatus & Record<string, unknown>;
  } catch (err) {
    runtimeError = isRuntimeUnavailable(err) ? "runtime_unavailable" : String(err);
  }

  // Display-only value; returns 0 when the runtime is unreachable.
  const workspaceBytes = await workspaceUsageBytes(botId);

  const plan = await getEffectivePlan(bot.userId);
  return {
    bot: {
      id: bot.id,
      name: bot.name,
      description: bot.description,
      runtime: bot.runtime,
      status: bot.status,
      startCommand: bot.startCommand,
      sourceType: bot.sourceType,
      sourceRef: bot.sourceRef,
      currentDeploymentId: bot.currentDeploymentId,
      lastDeployedAt: bot.lastDeployedAt,
      lastStartedAt: bot.lastStartedAt,
      createdAt: bot.createdAt,
      updatedAt: bot.updatedAt,
    },
    deployments: bot.deployments,
    runtime,
    runtimeReachable,
    runtimeError,
    workspaceBytes,
    limits: plan.limits,
  };
}
