/**
 * System-wide bot resource policy and abuse guards (FREE LAUNCH).
 *
 * During the free launch the product imposes NO plan-based account quotas
 * (no fixed bot count, no fixed daily deployments, no plan storage caps).
 * What REMAINS — and must never be removed — are genuine infrastructure
 * protections:
 *
 *   1. Per-bot OS resource limits (memory / CPU / disk / processes) so one
 *      bot cannot exhaust the host. These are SYSTEM-WIDE infrastructure
 *      policy, NOT product-plan allowances, and are always finite numbers
 *      (the runtime additionally rejects non-finite values and clamps).
 *   2. Abuse-prevention rate limits (registration, sign-in, deploy bursts)
 *      that protect the service from abusive traffic.
 *   3. A very high per-user bot safety ceiling to prevent pathological
 *      resource exhaustion (e.g. a script creating thousands of bots). It
 *      is orders of magnitude above ordinary use and is reported honestly
 *      as a safety/capacity control — never as a paid upgrade.
 *
 * All values are configuration-driven and validated (never Infinity/NaN).
 * If the host runs out of real capacity, operations fail with an honest
 * capacity message — never an upsell.
 */

import os from "node:os";

/** Parse an integer env var and clamp it into [min, max]. Always finite. */
function envInt(name: string, fallback: number, min: number, max: number): number {
  const raw = (process.env[name] ?? "").trim();
  if (raw.length === 0) return fallback;
  const n = Number(raw);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.floor(n)));
}

/**
 * Per-bot process limits derived from actual host capacity.
 *
 * memoryMbPerBot is additionally capped at 25% of total host RAM so the
 * sum of concurrent bots cannot trivially exhaust physical memory. The
 * runtime worker further clamps every value into its own safe ranges.
 */
function computeMemoryMbPerBot(): number {
  const configured = envInt("BOT_MEMORY_MB", 512, 64, 2048);
  const totalRamMb = Math.floor(os.totalmem() / (1024 * 1024));
  const hostCap = Math.max(64, Math.floor(totalRamMb * 0.25));
  return Math.min(configured, hostCap);
}

const memoryMbPerBot = computeMemoryMbPerBot();

/** Per-bot OS-level resource limits passed to the runtime (all finite). */
export const RESOURCE_POLICY = {
  memoryMbPerBot,
  cpuPercent: envInt("BOT_CPU_PERCENT", 50, 1, 100),
  diskMbPerBot: envInt("BOT_DISK_MB", 1024, 64, 10240),
  maxProcesses: 64,
} as const;

/** The exact object sent to the runtime for deploy/start (finite numbers). */
export function resourceLimitsForRuntime(): {
  memoryMb: number;
  cpuPercent: number;
  diskMb: number;
  maxProcesses: number;
} {
  return {
    memoryMb: RESOURCE_POLICY.memoryMbPerBot,
    cpuPercent: RESOURCE_POLICY.cpuPercent,
    diskMb: RESOURCE_POLICY.diskMbPerBot,
    maxProcesses: RESOURCE_POLICY.maxProcesses,
  };
}

/**
 * Abuse/safety guards. These protect real infrastructure — they are NOT
 * product plans and produce no upgrade messaging.
 */
export const ABUSE_GUARDS = {
  /** Max bots per user (safety ceiling far above ordinary usage). */
  maxBotsPerUser: envInt("SAFETY_MAX_BOTS_PER_USER", 100, 1, 10_000),
  /** Deploy/start burst protection per user per hour. */
  deployActionsPerHour: envInt("SAFETY_DEPLOY_PER_HOUR", 60, 5, 1000),
  /** Generic authenticated API burst protection per user per minute. */
  apiActionsPerMinute: envInt("SAFETY_API_PER_MINUTE", 120, 10, 5000),
} as const;

/** Honest capacity explanation surfaced when host resources run out. */
export const CAPACITY_NOTE =
  "Bots share the real capacity of this deployment (CPU, memory, disk). If the host runs out of room, operations may fail with a capacity message until space is freed — resource limits protect every bot from noisy neighbours.";
