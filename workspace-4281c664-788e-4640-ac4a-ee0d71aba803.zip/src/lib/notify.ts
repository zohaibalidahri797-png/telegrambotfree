/**
 * Notification creation helper (server-only).
 */

import { db } from "@/lib/db";

export interface NotifyInput {
  title: string;
  body: string;
  level?: "INFO" | "SUCCESS" | "WARNING" | "ERROR";
  category?: "SYSTEM" | "DEPLOYMENT" | "BILLING" | "BROADCAST" | "SECURITY";
  link?: string | null;
  broadcastId?: string | null;
}

export async function notify(userId: string, input: NotifyInput): Promise<void> {
  await db.notification
    .create({
      data: {
        userId,
        title: input.title.slice(0, 150),
        body: input.body.slice(0, 2000),
        level: input.level ?? "INFO",
        category: input.category ?? "SYSTEM",
        link: input.link ?? null,
        broadcastId: input.broadcastId ?? null,
      },
    })
    .catch((err) => console.error("[notify] failed:", err));
}
