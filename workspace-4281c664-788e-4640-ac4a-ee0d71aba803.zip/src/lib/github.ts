/**
 * GitHub integration (server-only). Uses a user-supplied Personal Access Token
 * (PAT), encrypted at rest. Scope expectation: `repo` for private repos or
 * `public_repo` for public-only import. The token is used server-side only and
 * is never returned to the client after saving.
 */

import { db } from "@/lib/db";
import { decryptSecret, encryptSecret } from "@/lib/crypto";

const GITHUB_API = "https://api.github.com";

export interface GithubRepoSummary {
  fullName: string;
  private: boolean;
  defaultBranch: string;
  updatedAt: string;
  description: string | null;
}

export async function saveGithubToken(userId: string, token: string, label = "GitHub PAT"): Promise<void> {
  const tokenEnc = encryptSecret(token);
  const scopes = await probeScopes(token);
  await db.githubToken.deleteMany({ where: { userId } });
  await db.githubToken.create({ data: { userId, tokenEnc, label, scopes } });
}

export async function deleteGithubToken(userId: string): Promise<void> {
  await db.githubToken.deleteMany({ where: { userId } });
}

export async function hasGithubToken(userId: string): Promise<boolean> {
  const t = await db.githubToken.findFirst({ where: { userId } });
  return t !== null;
}

/** Verifies the token against /user and returns granted scopes (or error). */
export async function probeScopes(
  token: string,
): Promise<string> {
  try {
    const res = await ghFetch("/user", token);
    return res.headers.get("x-oauth-scopes") ?? "";
  } catch {
    return "";
  }
}

export async function getToken(userId: string): Promise<string | null> {
  const row = await db.githubToken.findFirst({ where: { userId } });
  if (!row) return null;
  try {
    return decryptSecret(row.tokenEnc);
  } catch {
    return null;
  }
}

async function ghFetch(pathname: string, token: string, init?: RequestInit): Promise<Response> {
  const res = await fetch(`${GITHUB_API}${pathname}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
      "User-Agent": "botdock-cloud",
      ...(init?.headers ?? {}),
    },
    cache: "no-store",
  });
  return res;
}

function ghError(status: number, body: unknown): Error & { status?: number; githubMessage?: string } {
  const msg =
    typeof body === "object" && body !== null && "message" in body
      ? String((body as Record<string, unknown>).message)
      : "";
  const err = new Error(`github_error_${status}${msg ? `: ${msg}` : ""}`) as Error & { status?: number; githubMessage?: string };
  err.status = status;
  err.githubMessage = msg;
  return err;
}

export async function listRepos(userId: string): Promise<GithubRepoSummary[]> {
  const token = await getToken(userId);
  if (!token) throw new Error("no_github_token");
  const out: GithubRepoSummary[] = [];
  for (let page = 1; page <= 3; page++) {
    const res = await ghFetch(`/user/repos?per_page=100&sort=updated&page=${page}`, token);
    const body = await res.json().catch(() => null);
    if (!res.ok) throw ghError(res.status, body);
    if (!Array.isArray(body)) break;
    for (const r of body as Record<string, unknown>[]) {
      out.push({
        fullName: String(r.full_name ?? ""),
        private: Boolean(r.private),
        defaultBranch: String(r.default_branch ?? "main"),
        updatedAt: String(r.updated_at ?? ""),
        description: r.description === null ? null : String(r.description),
      });
    }
    if (body.length < 100) break;
  }
  return out.filter((r) => r.fullName);
}

export async function listBranches(userId: string, repo: string): Promise<string[]> {
  const token = await getToken(userId);
  if (!token) throw new Error("no_github_token");
  if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo)) throw new Error("invalid_repo");
  const res = await ghFetch(`/repos/${repo}/branches?per_page=100`, token);
  const body = await res.json().catch(() => null);
  if (!res.ok) throw ghError(res.status, body);
  if (!Array.isArray(body)) return [];
  return body.map((b) => String((b as Record<string, unknown>).name)).filter(Boolean);
}

export async function latestCommit(userId: string, repo: string, branch: string): Promise<{ sha: string; message: string } | null> {
  const token = await getToken(userId);
  if (!token) throw new Error("no_github_token");
  const res = await ghFetch(`/repos/${repo}/commits/${encodeURIComponent(branch)}?per_page=1`, token);
  const body = await res.json().catch(() => null);
  if (!res.ok) return null;
  const b = body as Record<string, unknown>;
  if (!b || typeof b.sha !== "string") return null;
  const commit = b.commit as Record<string, unknown> | undefined;
  return { sha: b.sha, message: String(commit?.message ?? "").slice(0, 200) };
}

/**
 * Downloads the repo tarball for a branch into a Buffer (max 20MB).
 * codeload.github.com streams a gzip tar — extracted by extractTarGzIntoWorkspace.
 */
export async function downloadRepoTarball(userId: string, repo: string, branch: string): Promise<Buffer> {
  const token = await getToken(userId);
  if (!token) throw new Error("no_github_token");
  if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo)) throw new Error("invalid_repo");
  const res = await ghFetch(`/repos/${repo}/tarball/${encodeURIComponent(branch)}`, token, { redirect: "follow" });
  if (!res.ok) {
    const body = await res.json().catch(() => null);
    throw ghError(res.status, body);
  }
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > 20 * 1024 * 1024) throw new Error("repo_tarball_too_large");
  return buf;
}
