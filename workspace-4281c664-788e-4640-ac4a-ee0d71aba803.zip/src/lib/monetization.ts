/**
 * Free-first launch switch.
 *
 * BotDock Cloud LAUNCHES AS A FREE PLATFORM: every eligible user gets the free
 * hosting plan automatically. No checkout, no payment provider, no paid-only
 * plans, no upgrade funnel.
 *
 * The billing code (Stripe checkout + signed webhook + admin manual plan
 * application) is kept in the codebase for future monetization but is
 * INACTIVE unless MONETIZATION_ENABLED is explicitly turned on by the operator.
 *
 * Default (unset or anything but true/1/yes) = monetization DISABLED.
 */
export function monetizationEnabled(): boolean {
  const v = (process.env.MONETIZATION_ENABLED ?? "").trim().toLowerCase();
  return v === "true" || v === "1" || v === "yes";
}

/** Canonical user-facing copy for the free-only launch. */
export const FREE_LAUNCH_NOTE =
  "BotDock Cloud is free during launch. Every account gets the free hosting plan automatically — no payment method, no subscription, and no checkout is required.";
