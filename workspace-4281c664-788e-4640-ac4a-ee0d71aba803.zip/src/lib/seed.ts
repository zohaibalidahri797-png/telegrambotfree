/**
 * Idempotent seed: default plans + platform settings.
 * Called from /api/health on first boot (safe to call repeatedly).
 *
 * FREE-FIRST LAUNCH: only the Free plan exists for users. Paid plan rows are
 * seeded ONLY when MONETIZATION_ENABLED=true (dormant billing tooling for the
 * future); the public plans API hides non-free plans regardless.
 *
 * The free plan is a LAUNCH PLAN, not a quota product: no fixed bot count,
 * no fixed daily deployments, no visible storage caps. The numeric limits
 * recorded on the row are informational/system data aligned with the
 * capacity policy (src/lib/capacity.ts); they are NOT product quotas and no
 * code enforces them as such.
 *
 * NOTE: limits are DATA, editable by admins at runtime — not code constants.
 */

import { db } from "@/lib/db";
import { monetizationEnabled } from "@/lib/monetization";

const PLANS = [
  {
    id: "free",
    name: "Free",
    description: "Everything you need to host your bots — free during launch, no payment required.",
    priceMonthly: 0,
    priceYearly: 0,
    isDefault: true,
    sortOrder: 1,
    limits: {
      // Informational/system values aligned with the capacity policy —
      // creation and deployments are NOT enforced against these numbers.
      maxBots: 100,
      memoryMbPerBot: 512,
      cpuPercent: 50,
      diskMbPerBot: 1024,
      storageTotalMb: 10240,
      deploymentsPerDay: 100,
      logRetentionDays: 7,
      runtimes: ["PYTHON", "NODE", "BUN"],
      allowedFeatures: { githubImport: true, fileEditor: true, envVars: true, prioritySupport: false },
    },
    features: [
      "Free during launch — no payment, no card, no checkout",
      "Python · Node.js · Bun runtimes",
      "Isolated processes with per-bot resource protection",
      "Create and manage bots without fixed plan caps",
      "GitHub import, file manager, encrypted env vars",
      "Live build & runtime logs with real metrics",
      "Community support",
    ],
  },
  {
    id: "starter",
    name: "Starter",
    description: "For hobbyists running a handful of bots.",
    priceMonthly: 500,
    priceYearly: 4900,
    isDefault: false,
    sortOrder: 2,
    limits: {
      maxBots: 5,
      memoryMbPerBot: 512,
      cpuPercent: 70,
      diskMbPerBot: 250,
      storageTotalMb: 512,
      deploymentsPerDay: 40,
      logRetentionDays: 7,
      runtimes: ["PYTHON", "NODE", "BUN"],
      allowedFeatures: { githubImport: true, fileEditor: true, envVars: true, prioritySupport: false },
    },
    features: ["5 hosted bots", "512 MB memory per bot", "512 MB storage", "40 deployments/day", "7-day log retention", "GitHub import"],
  },
  {
    id: "pro",
    name: "Pro",
    description: "For serious bot operators and small teams.",
    priceMonthly: 1500,
    priceYearly: 14900,
    isDefault: false,
    sortOrder: 3,
    limits: {
      maxBots: 20,
      memoryMbPerBot: 1024,
      cpuPercent: 85,
      diskMbPerBot: 512,
      storageTotalMb: 2048,
      deploymentsPerDay: 120,
      logRetentionDays: 14,
      runtimes: ["PYTHON", "NODE", "BUN"],
      allowedFeatures: { githubImport: true, fileEditor: true, envVars: true, prioritySupport: true },
    },
    features: ["20 hosted bots", "1 GB memory per bot", "2 GB storage", "120 deployments/day", "14-day log retention", "Priority support"],
  },
  {
    id: "scale",
    name: "Scale",
    description: "High capacity for fleets of bots.",
    priceMonthly: 4900,
    priceYearly: 49000,
    isDefault: false,
    sortOrder: 4,
    limits: {
      maxBots: 100,
      memoryMbPerBot: 2048,
      cpuPercent: 95,
      diskMbPerBot: 1024,
      storageTotalMb: 8192,
      deploymentsPerDay: 400,
      logRetentionDays: 30,
      runtimes: ["PYTHON", "NODE", "BUN"],
      allowedFeatures: { githubImport: true, fileEditor: true, envVars: true, prioritySupport: true },
    },
    features: ["100 hosted bots", "2 GB memory per bot", "8 GB storage", "400 deployments/day", "30-day log retention", "Priority support"],
  },
];

const DEFAULT_SETTINGS: Record<string, unknown> = {
  registrationEnabled: true,
  maintenanceMode: false,
  maintenanceMessage: "",
  adsEnabled: false,
  adsProviderNote: "",
  rewardedAdsEnabled: false,
  referralCreditsEnabled: false,
  supportEmail: "support@botdock.cloud",
  telegramAnnounceChat: "",
};

/** PlatformSetting key guarding the one-time launch-plan refresh on existing DBs. */
const FREE_PLAN_SEED_KEY = "seed.freeLaunchV3";

let seeded = false;

export async function ensureSeed(): Promise<void> {
  if (seeded) return;
  const paid = monetizationEnabled();
  // One-time free-plan refresh marker: the launch limits are applied to the
  // free plan row exactly once (so existing deployments pick them up); after
  // that, limits are admin-editable data and are never overwritten again.
  let refreshFreePlan = false;
  if (!paid) {
    const marker = await db.platformSetting
      .findUnique({ where: { key: FREE_PLAN_SEED_KEY } })
      .catch(() => null);
    refreshFreePlan = !marker;
  }
  for (const plan of PLANS) {
    // Free-first launch: skip paid plan rows entirely unless monetization is on.
    if (!paid && plan.priceMonthly > 0) continue;
    const refresh = plan.id === "free" && refreshFreePlan;
    await db.plan
      .upsert({
        where: { id: plan.id },
        update: refresh
          ? {
              name: plan.name,
              description: plan.description,
              priceMonthly: plan.priceMonthly,
              priceYearly: plan.priceYearly,
              limits: JSON.stringify(plan.limits),
              features: JSON.stringify(plan.features),
            }
          : {},
        create: {
          id: plan.id,
          name: plan.name,
          description: plan.description,
          priceMonthly: plan.priceMonthly,
          priceYearly: plan.priceYearly,
          isDefault: plan.isDefault,
          sortOrder: plan.sortOrder,
          limits: JSON.stringify(plan.limits),
          features: JSON.stringify(plan.features),
        },
      })
      .catch((err) => console.error("[seed] plan upsert failed:", err));
  }
  if (refreshFreePlan) {
    await db.platformSetting
      .upsert({
        where: { key: FREE_PLAN_SEED_KEY },
        update: {},
        create: {
          key: FREE_PLAN_SEED_KEY,
          value: JSON.stringify({
            appliedAt: new Date().toISOString(),
            policy: "capacity-based launch (no product quotas)",
          }),
        },
      })
      .catch(() => undefined);
  }
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    await db.platformSetting
      .upsert({ where: { key }, update: {}, create: { key, value: JSON.stringify(value) } })
      .catch((err) => console.error("[seed] setting upsert failed:", err));
  }
  // Assign the default (free) plan to any user missing a subscription.
  const freePlan = PLANS.find((p) => p.isDefault)!;
  const usersWithoutSub = await db.user.findMany({
    where: { subscription: null },
    select: { id: true },
    take: 100,
  });
  for (const u of usersWithoutSub) {
    await db.subscription
      .create({ data: { userId: u.id, planId: freePlan.id, provider: "NONE" } })
      .catch(() => undefined);
  }
  seeded = true;
}
