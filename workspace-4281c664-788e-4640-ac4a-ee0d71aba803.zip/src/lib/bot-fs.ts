/**
 * Bot workspace file operations (SERVER-ONLY) — Cloudflare-compatible.
 *
 * All bot filesystem access lives in the botdock-runtime service (the process
 * that actually owns the disk). This module proxies every operation over
 * HTTP with the shared X-Runtime-Key, so the web app never touches a local
 * filesystem for bot files — required on Cloudflare Workers and correct in
 * development (same data dir on both sides).
 *
 * Error mapping: runtime PathErrors arrive as 400 { error:"file_error",
 * message } → surfaced as FileOpError with the original message.
 */

import { runtimeApiKey, runtimeBaseUrl } from "./runtime-config";

export const MAX_FILE_WRITE = 512 * 1024;
export const MAX_ARCHIVE_BYTES = 20 * 1024 * 1024;

export class FileOpError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "FileOpError";
  }
}

export class RuntimeOfflineError extends Error {
  constructor() {
    super("runtime_unavailable");
    this.name = "RuntimeOfflineError";
  }
}

export function isFileOpError(err: unknown): err is FileOpError {
  return err instanceof FileOpError;
}

async function runtimeJson<T>(
  pathname: string,
  init: { method: "GET" | "PUT" | "POST" | "DELETE"; body?: unknown; timeoutMs?: number; formData?: FormData },
): Promise<T> {
  const key = runtimeApiKey();
  if (!key) throw new RuntimeOfflineError();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), init.timeoutMs ?? 30_000);
  try {
    const res = await fetch(`${runtimeBaseUrl()}${pathname}`, {
      method: init.method,
      headers: {
        "X-Runtime-Key": key,
        ...(init.body !== undefined ? { "Content-Type": "application/json" } : {}),
      },
      body: init.formData ?? (init.body !== undefined ? JSON.stringify(init.body) : undefined),
      signal: controller.signal,
      cache: "no-store",
    });
    const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    if (!res.ok) {
      if (res.status === 503 || res.status >= 500) {
        throw new FileOpError(String(json.message ?? json.error ?? `runtime error ${res.status}`));
      }
      throw new FileOpError(String(json.message ?? json.error ?? `runtime error ${res.status}`));
    }
    return json as T;
  } catch (err) {
    if (err instanceof FileOpError) throw err;
    throw new RuntimeOfflineError();
  } finally {
    clearTimeout(timer);
  }
}

export interface FileEntry {
  path: string;
  type: "file" | "dir";
  size: number;
  modifiedAt: string;
}

export async function listFiles(botId: string, relDir = ""): Promise<FileEntry[]> {
  const res = await runtimeJson<{ entries?: FileEntry[] }>(
    `/bots/${botId}/files?path=${encodeURIComponent(relDir)}`,
    { method: "GET" },
  );
  return res.entries ?? [];
}

export async function readFileContent(
  botId: string,
  relPath: string,
): Promise<{ path: string; content: string; size: number; binary: boolean }> {
  const res = await runtimeJson<{ file?: { path: string; content: string; size: number; binary: boolean } }>(
    `/bots/${botId}/files/read?path=${encodeURIComponent(relPath)}`,
    { method: "GET" },
  );
  if (!res.file) throw new FileOpError("file not found");
  return res.file;
}

export async function writeFileContent(botId: string, relPath: string, content: string): Promise<void> {
  await runtimeJson(`/bots/${botId}/files`, { method: "PUT", body: { path: relPath, content } });
}

export async function makeDir(botId: string, relPath: string): Promise<void> {
  await runtimeJson(`/bots/${botId}/files/mkdir`, { method: "POST", body: { path: relPath } });
}

export async function deletePath(botId: string, relPath: string): Promise<void> {
  await runtimeJson(`/bots/${botId}/files?path=${encodeURIComponent(relPath)}`, { method: "DELETE" });
}

export async function downloadFile(
  botId: string,
  relPath: string,
): Promise<{ data: Uint8Array<ArrayBuffer>; filename: string }> {
  const key = runtimeApiKey();
  if (!key) throw new RuntimeOfflineError();
  let res: Response;
  try {
    res = await fetch(`${runtimeBaseUrl()}/bots/${botId}/files/download?path=${encodeURIComponent(relPath)}`, {
      headers: { "X-Runtime-Key": key },
      cache: "no-store",
    });
  } catch {
    throw new RuntimeOfflineError();
  }
  if (!res.ok) {
    const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
    throw new FileOpError(String(json.message ?? json.error ?? `download failed (${res.status})`));
  }
  const disposition = res.headers.get("content-disposition") ?? "";
  const match = /filename="([^"]+)"/.exec(disposition);
  const data = new Uint8Array(await res.arrayBuffer());
  return { data, filename: match?.[1] ?? relPath.split("/").pop() ?? "file" };
}

export type UploadResult =
  | { kind: "archive"; format: string; files: number; bytes: number }
  | { kind: "file"; path: string; bytes: number };

/**
 * Uploads a single file or archive into the bot workspace via the runtime.
 * Archives (zip/tar/tar.gz/tgz, ≤20MB) are extracted safely into `into`;
 * plain files (≤512KB) are written as-is.
 */
export async function uploadToWorkspace(
  botId: string,
  filename: string,
  data: Buffer,
  into = "",
): Promise<UploadResult> {
  const form = new FormData();
  const bytes = new Uint8Array(
    data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) as ArrayBuffer,
  );
  form.set("file", new File([bytes], filename, { type: "application/octet-stream" }));
  form.set("path", into);
  const res = await runtimeJson<UploadResult>(`/bots/${botId}/files/upload`, {
    method: "POST",
    formData: form,
    timeoutMs: 120_000, // large archives need extraction time
  });
  if (res.kind !== "archive" && res.kind !== "file") {
    throw new FileOpError("unexpected upload response from runtime");
  }
  return res;
}

export async function workspaceUsageBytes(botId: string): Promise<number> {
  try {
    const res = await runtimeJson<{ bytes?: number }>(`/bots/${botId}/usage`, { method: "GET", timeoutMs: 8000 });
    return typeof res.bytes === "number" ? res.bytes : 0;
  } catch {
    return 0; // display-only value; never block the detail view on it
  }
}

/** Writes template files into a fresh workspace via the runtime. */
export async function writeTemplateFiles(botId: string, files: Record<string, string>): Promise<void> {
  await runtimeJson(`/bots/${botId}/templates`, { method: "POST", body: { files } });
}
