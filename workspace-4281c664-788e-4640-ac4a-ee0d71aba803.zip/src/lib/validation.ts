/**
 * Zod validation schemas for all API inputs. Lifecycle states are string
 * literals here (SQLite has no enums) — single source of truth.
 */

import { z } from "zod";

export const BOT_RUNTIMES = ["PYTHON", "NODE", "BUN"] as const;
export const BOT_STATES = [
  "CREATED",
  "BUILDING",
  "DEPLOYING",
  "RUNNING",
  "STOPPED",
  "FAILED",
  "DELETING",
] as const;
export const DEPLOYMENT_STATES = [
  "QUEUED",
  "BUILDING",
  "DEPLOYING",
  "RUNNING",
  "FAILED",
  "CANCELED",
] as const;

export const emailSchema = z.string().trim().toLowerCase().email("Enter a valid email address").max(254);

export const registerSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(80),
  email: emailSchema,
  password: z.string().min(8, "Password must be at least 8 characters").max(128),
  // One-time setup token required ONLY when registering the first
  // administrator on an empty production database (see src/lib/admin-bootstrap.ts).
  bootstrapToken: z.string().trim().max(128).optional(),
});

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Password is required").max(128),
});

export const botCreateSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1, "Bot name is required")
    .max(50)
    .regex(/^[a-zA-Z0-9 _-]+$/, "Letters, numbers, spaces, - and _ only"),
  description: z.string().trim().max(300).default(""),
  runtime: z.enum(BOT_RUNTIMES),
  sourceType: z.enum(["TEMPLATE", "UPLOAD", "GITHUB"]).default("TEMPLATE"),
  templateId: z.string().trim().max(60).optional(),
  startCommand: z.string().trim().max(500).default(""),
});

export const botUpdateSchema = z.object({
  name: z
    .string()
    .trim()
    .min(1)
    .max(50)
    .regex(/^[a-zA-Z0-9 _-]+$/)
    .optional(),
  description: z.string().trim().max(300).optional(),
  runtime: z.enum(BOT_RUNTIMES).optional(),
  startCommand: z.string().trim().max(500).optional(),
});

export const botActionSchema = z.object({
  // NOTE: only actions implemented by /api/bots/[id]/action are listed;
  // workspace removal happens via bot deletion (bot-lifecycle → runtime undeploy).
  action: z.enum(["start", "stop", "restart", "deploy"]),
});

export const envVarSchema = z.object({
  key: z
    .string()
    .trim()
    .regex(/^[A-Za-z_][A-Za-z0-9_]*$/, "Invalid variable name")
    .max(120),
  value: z.string().max(8000).default(""),
  isSecret: z.boolean().default(true),
});

export const fileWriteSchema = z.object({
  path: z.string().min(1).max(400),
  content: z.string().max(512 * 1024, "File exceeds 512KB"),
});

export const fileMkdirSchema = z.object({
  path: z.string().min(1).max(400),
});

export const fileDeleteSchema = z.object({
  path: z.string().min(1).max(400),
});

export const broadcastSchema = z.object({
  title: z.string().trim().min(1).max(150),
  body: z.string().trim().min(1).max(10_000),
  level: z.enum(["INFO", "SUCCESS", "WARNING", "ERROR"]).default("INFO"),
  category: z.enum(["SYSTEM", "DEPLOYMENT", "BILLING", "BROADCAST", "SECURITY"]).default("SYSTEM"),
  audience: z.string().trim().max(60).default("ALL"),
  channels: z.array(z.enum(["INAPP", "EMAIL", "TELEGRAM"])).min(1).default(["INAPP"]),
  send: z.boolean().default(false),
  scheduledFor: z.string().datetime().nullable().optional(),
});

export const adminUserUpdateSchema = z.object({
  role: z.enum(["USER", "ADMIN"]).optional(),
  status: z.enum(["ACTIVE", "SUSPENDED", "BANNED"]).optional(),
  suspensionReason: z.string().trim().max(300).optional(),
  emailVerified: z.boolean().optional(),
});

export const planLimitsSchema = z.object({
  maxBots: z.number().int().min(0).max(1000),
  memoryMbPerBot: z.number().int().min(32).max(8192),
  cpuPercent: z.number().int().min(1).max(100),
  diskMbPerBot: z.number().int().min(1).max(10_240),
  storageTotalMb: z.number().int().min(10).max(102_400),
  deploymentsPerDay: z.number().int().min(0).max(1000),
  logRetentionDays: z.number().int().min(1).max(90),
  runtimes: z.array(z.enum(BOT_RUNTIMES)).min(1),
  allowedFeatures: z.object({
    githubImport: z.boolean(),
    fileEditor: z.boolean(),
    envVars: z.boolean(),
    prioritySupport: z.boolean(),
  }),
});

export type PlanLimits = z.infer<typeof planLimitsSchema>;

export const planUpdateSchema = z.object({
  id: z.string().trim().min(1).max(40),
  name: z.string().trim().min(1).max(60).optional(),
  description: z.string().trim().max(300).optional(),
  priceMonthly: z.number().int().min(0).max(1_000_000).optional(),
  priceYearly: z.number().int().min(0).max(10_000_000).optional(),
  isActive: z.boolean().optional(),
  isPublic: z.boolean().optional(),
  sortOrder: z.number().int().min(0).max(1000).optional(),
  features: z.array(z.string().max(120)).optional(),
  limits: planLimitsSchema.optional(),
});

export const settingsSchema = z.object({
  registrationEnabled: z.boolean().optional(),
  maintenanceMode: z.boolean().optional(),
  maintenanceMessage: z.string().max(500).optional(),
  adsEnabled: z.boolean().optional(),
  adsProviderNote: z.string().max(300).optional(),
  rewardedAdsEnabled: z.boolean().optional(),
  referralCreditsEnabled: z.boolean().optional(),
  supportEmail: z.string().max(120).optional(),
  telegramAnnounceChat: z.string().max(60).optional(),
});

export function zodErrorMessage(err: z.ZodError): string {
  const first = err.issues[0];
  if (!first) return "Invalid input";
  const path = first.path.join(".");
  return path ? `${path}: ${first.message}` : first.message;
}
