/**
 * Bot project templates. Every template is a real, runnable project:
 *  - "Keep-alive" templates use ONLY the standard library so they always deploy
 *    and run, proving the runtime end-to-end even without outbound networks.
 *  - "Telegram" templates are real long-polling bots; their dependencies
 *    (python-telegram-bot / telegraf) install during the BUILDING phase.
 */

export interface BotTemplate {
  id: string;
  name: string;
  runtime: "PYTHON" | "NODE" | "BUN";
  description: string;
  startCommand: string; // empty = auto-detect
  files: Record<string, string>;
}

const PY_KEEPALIVE = `"""BotDock keep-alive bot (Python stdlib only).

A tiny HTTP health server on $PORT plus a heartbeat log line every 30s.
Replace main() with your bot logic (e.g. python-telegram-bot polling).
"""
import http.server
import os
import socketserver
import threading
import time

STARTED = time.time()


def heartbeat():
    while True:
        print(f"bot alive uptime={int(time.time() - STARTED)}s", flush=True)
        time.sleep(30)


class Handler(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        body = f'{{"status":"ok","uptime":{int(time.time() - STARTED)},"runtime":"python"}}'
        self.wfile.write(body.encode())
        self.wfile.write(b"\\n")

    def log_message(self, *args):
        pass


def main():
    threading.Thread(target=heartbeat, daemon=True).start()
    port = int(os.environ.get("PORT", "8080"))
    with socketserver.TCPServer(("0.0.0.0", port), Handler) as httpd:
        print(f"keep-alive bot listening on port {port}", flush=True)
        httpd.serve_forever()


if __name__ == "__main__":
    main()
`;

const PY_TELEGRAM = `"""Telegram echo bot (python-telegram-bot v21+, long polling).

Set the BOT_TOKEN environment variable in your bot's Env settings,
then deploy. The bot echoes any private text message back to the sender.
"""
import logging
import os

from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, ContextTypes, MessageHandler, filters

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("echo-bot")


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Hello from BotDock Cloud! Send me any text and I'll echo it.")


async def echo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(update.message.text, parse_mode=ParseMode.HTML)


def main():
    token = os.environ.get("BOT_TOKEN")
    if not token:
        raise SystemExit("BOT_TOKEN env var is not set — add it in your bot's Env settings, then redeploy.")
    app = Application.builder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, echo))
    log.info("echo bot starting (long polling)")
    app.run_polling(allowed_updates=["message"])


if __name__ == "__main__":
    main()
`;

const NODE_KEEPALIVE = `// BotDock keep-alive bot (Node.js stdlib only).
const http = require("http");
const startedAt = Date.now();

setInterval(() => {
  console.log(\`bot alive uptime=\${Math.floor((Date.now() - startedAt) / 1000)}s\`);
}, 30000).unref();

const server = http.createServer((req, res) => {
  res.writeHead(200, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ status: "ok", uptimeSec: Math.floor((Date.now() - startedAt) / 1000), runtime: "node" }) + "\\n");
});

const port = Number(process.env.PORT || 8080);
server.listen(port, "0.0.0.0", () => console.log(\`keep-alive bot listening on port \${port}\`));
`;

const NODE_TELEGRAM = `// Telegram echo bot (telegraf, long polling).
// Set the BOT_TOKEN environment variable in your bot's Env settings, then deploy.
const { Telegraf } = require("telegraf");

const token = process.env.BOT_TOKEN;
if (!token) {
  console.error("BOT_TOKEN env var is not set — add it in your bot's Env settings, then redeploy.");
  process.exit(1);
}

const bot = new Telegraf(token);
bot.start((ctx) => ctx.reply("Hello from BotDock Cloud! Send me any text and I'll echo it."));
bot.on("text", (ctx) => ctx.reply(ctx.message.text));
bot.launch().then(() => console.log("echo bot started (long polling)"));

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
`;

const BUN_KEEPALIVE = `// BotDock keep-alive bot (Bun).
const startedAt = Date.now();

setInterval(() => {
  console.log(\`bot alive uptime=\${Math.floor((Date.now() - startedAt) / 1000)}s\`);
}, 30000);

const port = Number(process.env.PORT || 8080);
Bun.serve({
  port,
  fetch() {
    return Response.json({ status: "ok", uptimeSec: Math.floor((Date.now() - startedAt) / 1000), runtime: "bun" });
  },
});
console.log(\`keep-alive bot listening on port \${port}\`);
`;

export const TEMPLATES: BotTemplate[] = [
  {
    id: "python-keepalive",
    name: "Python keep-alive bot (stdlib)",
    runtime: "PYTHON",
    description: "Zero dependencies. Tiny HTTP health server + heartbeat logging. Proves the runtime works; replace main() with your logic.",
    startCommand: "",
    files: { "main.py": PY_KEEPALIVE, "requirements.txt": "", "README.md": "# Python keep-alive bot\n\nRuns with Python stdlib only. Port comes from $PORT.\n" },
  },
  {
    id: "python-telegram-echo",
    name: "Python Telegram echo bot",
    runtime: "PYTHON",
    description: "Real long-polling Telegram bot using python-telegram-bot. Set BOT_TOKEN in Env settings before deploying.",
    startCommand: "",
    files: { "main.py": PY_TELEGRAM, "requirements.txt": "python-telegram-bot~=21.10\n", "README.md": "# Telegram echo bot\n\n1. Get a token from @BotFather.\n2. Add BOT_TOKEN in the bot's Env settings.\n3. Deploy.\n" },
  },
  {
    id: "node-keepalive",
    name: "Node.js keep-alive bot (stdlib)",
    runtime: "NODE",
    description: "Zero dependencies. Tiny HTTP health server + heartbeat logging on Node.js.",
    startCommand: "",
    files: { "index.js": NODE_KEEPALIVE, "package.json": JSON.stringify({ name: "node-keepalive-bot", version: "1.0.0", private: true, scripts: { start: "node index.js" } }, null, 2) + "\n", "README.md": "# Node keep-alive bot\n" },
  },
  {
    id: "node-telegram-echo",
    name: "Node.js Telegram echo bot",
    runtime: "NODE",
    description: "Real long-polling Telegram bot using telegraf. Set BOT_TOKEN in Env settings before deploying.",
    startCommand: "",
    files: {
      "index.js": NODE_TELEGRAM,
      "package.json": JSON.stringify({ name: "node-telegram-echo", version: "1.0.0", private: true, scripts: { start: "node index.js" }, dependencies: { telegraf: "^4.16.3" } }, null, 2) + "\n",
      "README.md": "# Telegram echo bot (telegraf)\n\n1. Get a token from @BotFather.\n2. Add BOT_TOKEN in Env settings.\n3. Deploy.\n",
    },
  },
  {
    id: "bun-keepalive",
    name: "Bun keep-alive bot",
    runtime: "BUN",
    description: "Zero dependencies. Bun.serve HTTP health endpoint + heartbeat logging.",
    startCommand: "",
    files: { "main.ts": BUN_KEEPALIVE, "package.json": JSON.stringify({ name: "bun-keepalive-bot", version: "1.0.0", private: true }, null, 2) + "\n", "README.md": "# Bun keep-alive bot\n" },
  },
];

export function getTemplate(id: string): BotTemplate | undefined {
  return TEMPLATES.find((t) => t.id === id);
}
