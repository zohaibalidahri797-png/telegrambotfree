/**
 * Prisma client factory with production driver-adapter support.
 *
 * ── Local development ────────────────────────────────────────────────────────
 *   DATABASE_URL="file:./db/custom.db" → standard Prisma SQLite engine
 *   (same behavior and data as before this change).
 *
 * ── Production (Cloudflare Workers / any remote libSQL) ─────────────────────
 *   DATABASE_URL="libsql://<db>.turso.io" (+ LIBSQL_AUTH_TOKEN) →
 *   @prisma/adapter-libsql over @libsql/client's HTTP transport — the
 *   officially supported way to run Prisma on Cloudflare Workers (no native
 *   engine, no local file). A plain https:// URL to a libSQL server is also
 *   accepted.
 *
 *   Why not the classic engine on Workers? The engine is a native binary that
 *   expects a local file — Workers have no shared filesystem and a SQLite
 *   file cannot serve multiple isolates. Remote libSQL keeps the web app
 *   stateless. (Postgres alternative: docs/DEPLOYMENT.md § Production
 *   database — swap the schema provider to postgresql and use
 *   @prisma/adapter-pg; the application code does not change.)
 *
 * Logging: query logging is OFF by default (too noisy for production and it
 * can leak sensitive bind values into logs). Enable explicitly in dev with
 * PRISMA_QUERY_LOG=1. Errors/warnings are always logged.
 */

import { PrismaClient } from "@prisma/client";
import { PrismaLibSQL } from "@prisma/adapter-libsql";

function isRemoteDatabaseUrl(url: string | undefined): boolean {
  if (!url) return false;
  const u = url.trim();
  return u.startsWith("libsql://") || /^https:\/\//i.test(u);
}

function logConfig(): ("error" | "warn" | "query")[] {
  return process.env.PRISMA_QUERY_LOG === "1" && process.env.NODE_ENV !== "production"
    ? ["error", "warn", "query"]
    : ["error", "warn"];
}

function createPrismaClient(): PrismaClient {
  const url = process.env.DATABASE_URL?.trim();

  if (isRemoteDatabaseUrl(url)) {
    // Adapter owns the libSQL client (HTTP transport — Workers-compatible).
    const adapter = new PrismaLibSQL({
      url: url as string,
      authToken: process.env.LIBSQL_AUTH_TOKEN || undefined,
    });
    return new PrismaClient({ adapter, log: logConfig() });
  }

  return new PrismaClient({ log: logConfig() });
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const db: PrismaClient =
  globalForPrisma.prisma ??
  (() => {
    const client = createPrismaClient();
    if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = client;
    return client;
  })();

/** Health probe support: report which transport the client uses. */
export function databaseTransport(): "sqlite-local" | "libsql-remote" {
  return isRemoteDatabaseUrl(process.env.DATABASE_URL) ? "libsql-remote" : "sqlite-local";
}
