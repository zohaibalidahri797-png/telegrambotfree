/**
 * Email delivery (server-only).
 *
 * Real delivery via Resend's REST API when RESEND_API_KEY is configured.
 * Without it, emails are NEVER silently "sent": they are recorded in the
 * EmailLog table (status SKIPPED, provider "none") and printed to the server
 * console. When DEV_SHOW_EMAIL_LINKS is true AND no provider is configured,
 * action links are additionally returned to the caller so flows are testable
 * in development — this must be disabled in production.
 */

import { db } from "@/lib/db";

export interface SendEmailInput {
  to: string;
  subject: string;
  text: string;
  html: string;
  template: string;
  userId?: string | null;
}

export interface SendEmailResult {
  delivered: boolean;
  provider: "resend" | "none";
  error?: string;
}

function appUrl(): string {
  return (process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, "");
}

export function emailProviderConfigured(): boolean {
  return Boolean(process.env.RESEND_API_KEY);
}

/** Returns true when dev-link disclosure is allowed (dev mode, no provider). */
export function devLinksEnabled(): boolean {
  return process.env.DEV_SHOW_EMAIL_LINKS === "true" && !emailProviderConfigured();
}

export async function sendEmail(input: SendEmailInput): Promise<SendEmailResult> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM || "BotDock Cloud <no-reply@example.com>";

  if (!apiKey) {
    // Honest fallback: log to console + DB, do NOT pretend delivery happened.
    console.log(
      `[email:SKIPPED provider=none] to=${input.to} subject="${input.subject}" template=${input.template}\n${input.text}`,
    );
    await db.emailLog
      .create({
        data: {
          toEmail: input.to,
          subject: input.subject,
          template: input.template,
          status: "SKIPPED",
          provider: "none",
          userId: input.userId ?? null,
        },
      })
      .catch(() => undefined);
    return { delivered: false, provider: "none" };
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: [input.to],
        subject: input.subject,
        text: input.text,
        html: input.html,
      }),
    });
    if (!res.ok) {
      const bodyText = await res.text().catch(() => "");
      const error = `resend_http_${res.status}: ${bodyText.slice(0, 300)}`;
      console.error(`[email:FAILED] to=${input.to} ${error}`);
      await db.emailLog
        .create({
          data: {
            toEmail: input.to,
            subject: input.subject,
            template: input.template,
            status: "FAILED",
            provider: "resend",
            error: error.slice(0, 500),
            userId: input.userId ?? null,
          },
        })
        .catch(() => undefined);
      return { delivered: false, provider: "resend", error };
    }
    await db.emailLog
      .create({
        data: {
          toEmail: input.to,
          subject: input.subject,
          template: input.template,
          status: "SENT",
          provider: "resend",
          userId: input.userId ?? null,
        },
      })
      .catch(() => undefined);
    return { delivered: true, provider: "resend" };
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err);
    console.error(`[email:FAILED] to=${input.to} ${error}`);
    await db.emailLog
      .create({
        data: {
          toEmail: input.to,
          subject: input.subject,
          template: input.template,
          status: "FAILED",
          provider: "resend",
          error: error.slice(0, 500),
          userId: input.userId ?? null,
        },
      })
      .catch(() => undefined);
    return { delivered: false, provider: "resend", error };
  }
}

// ── Templates ────────────────────────────────────────────────────────────────

export function verificationEmail(name: string, token: string): { subject: string; text: string; html: string } {
  // Link points at the API route, which renders its own "verified" page and
  // redirects to the dashboard. (An earlier draft linked to a hash view that
  // was never implemented — real emailed links would have dead-ended.)
  const link = `${appUrl()}/api/auth/verify-email?token=${token}`;
  return {
    subject: "Verify your BotDock Cloud email",
    text: `Hi ${name},\n\nVerify your BotDock Cloud account by opening this link (valid for 24 hours):\n${link}\n\nIf you didn't create an account, you can ignore this email.`,
    html: `<p>Hi ${escapeHtml(name)},</p><p>Verify your BotDock Cloud account by opening this link (valid for 24 hours):</p><p><a href="${link}">Verify my email</a></p><p>If you didn't create an account, you can ignore this email.</p>`,
  };
}

export function passwordResetEmail(name: string, token: string): { subject: string; text: string; html: string } {
  const link = `${appUrl()}/#/reset-password?token=${token}`;
  return {
    subject: "Reset your BotDock Cloud password",
    text: `Hi ${name},\n\nReset your password with this link (valid for 1 hour):\n${link}\n\nIf you didn't request this, you can safely ignore this email.`,
    html: `<p>Hi ${escapeHtml(name)},</p><p>Reset your password with this link (valid for 1 hour):</p><p><a href="${link}">Reset my password</a></p><p>If you didn't request this, you can safely ignore this email.</p>`,
  };
}

export function genericEmail(subject: string, bodyMarkdown: string): { subject: string; text: string; html: string } {
  return {
    subject,
    text: bodyMarkdown,
    html: `<div style="font-family:system-ui,sans-serif;line-height:1.6"><h2 style="margin:0 0 12px">${escapeHtml(subject)}</h2><div>${bodyMarkdown
      .split("\n")
      .map((l) => `<p style="margin:0 0 8px">${escapeHtml(l)}</p>`)
      .join("")}</div></div>`,
  };
}

export function escapeHtml(s: string): string {
  return s
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}
