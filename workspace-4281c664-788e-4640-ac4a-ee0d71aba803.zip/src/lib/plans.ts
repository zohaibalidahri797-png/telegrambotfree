/**
 * Plan management: parse the JSON limits column and resolve a user's
 * effective plan + subscription.
 *
 * FREE LAUNCH: plans are no longer a product quota system. Bot creation,
 * deployments and storage are NOT capped by plan records — genuine capacity
 * policy and abuse guards live in src/lib/capacity.ts. Plan rows remain as
 * display/admin data (and dormant billing compatibility), so their numeric
 * limits below are informational defaults, never enforcement inputs.
 */

import { db } from "@/lib/db";
import { ABUSE_GUARDS } from "@/lib/capacity";
import type { PlanLimits } from "@/lib/validation";

export const DEFAULT_FREE_LIMITS: PlanLimits = {
  maxBots: 100,
  memoryMbPerBot: 512,
  cpuPercent: 50,
  diskMbPerBot: 1024,
  storageTotalMb: 10240,
  deploymentsPerDay: 100,
  logRetentionDays: 7,
  runtimes: ["PYTHON", "NODE", "BUN"],
  allowedFeatures: { githubImport: true, fileEditor: true, envVars: true, prioritySupport: false },
};

export function parseLimits(json: string | null | undefined): PlanLimits {
  if (!json) return DEFAULT_FREE_LIMITS;
  try {
    const parsed = JSON.parse(json) as Partial<PlanLimits>;
    return {
      maxBots: parsed.maxBots ?? DEFAULT_FREE_LIMITS.maxBots,
      memoryMbPerBot: parsed.memoryMbPerBot ?? DEFAULT_FREE_LIMITS.memoryMbPerBot,
      cpuPercent: parsed.cpuPercent ?? DEFAULT_FREE_LIMITS.cpuPercent,
      diskMbPerBot: parsed.diskMbPerBot ?? DEFAULT_FREE_LIMITS.diskMbPerBot,
      storageTotalMb: parsed.storageTotalMb ?? DEFAULT_FREE_LIMITS.storageTotalMb,
      deploymentsPerDay: parsed.deploymentsPerDay ?? DEFAULT_FREE_LIMITS.deploymentsPerDay,
      logRetentionDays: parsed.logRetentionDays ?? DEFAULT_FREE_LIMITS.logRetentionDays,
      runtimes: Array.isArray(parsed.runtimes) && parsed.runtimes.length > 0 ? parsed.runtimes : DEFAULT_FREE_LIMITS.runtimes,
      allowedFeatures: {
        githubImport: parsed.allowedFeatures?.githubImport ?? false,
        fileEditor: parsed.allowedFeatures?.fileEditor ?? true,
        envVars: parsed.allowedFeatures?.envVars ?? true,
        prioritySupport: parsed.allowedFeatures?.prioritySupport ?? false,
      },
    };
  } catch {
    return DEFAULT_FREE_LIMITS;
  }
}

export interface EffectivePlan {
  planId: string;
  planName: string;
  status: string;
  billingCycle: string;
  cancelAtPeriodEnd: boolean;
  provider: string;
  limits: PlanLimits;
  features: string[];
  priceMonthly: number;
}

const FREE_PLAN: EffectivePlan = {
  planId: "free",
  planName: "Free",
  status: "ACTIVE",
  billingCycle: "NONE",
  cancelAtPeriodEnd: false,
  provider: "NONE",
  limits: DEFAULT_FREE_LIMITS,
  features: ["Free during launch", "Python · Node.js · Bun", "Isolated processes", "Live logs & metrics"],
  priceMonthly: 0,
};

export async function getEffectivePlan(userId: string): Promise<EffectivePlan> {
  const sub = await db.subscription.findUnique({
    where: { userId },
    include: { plan: true },
  });
  if (!sub) return FREE_PLAN;
  return {
    planId: sub.plan.id,
    planName: sub.plan.name,
    status: sub.status,
    billingCycle: sub.billingCycle,
    cancelAtPeriodEnd: sub.cancelAtPeriodEnd,
    provider: sub.provider,
    limits: parseLimits(sub.plan.limits),
    features: safeArray(sub.plan.features),
    priceMonthly: sub.plan.priceMonthly,
  };
}

function safeArray(json: string | null): string[] {
  if (!json) return [];
  try {
    const v = JSON.parse(json);
    return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
  } catch {
    return [];
  }
}

/** Number of deployments the user has triggered today (UTC day window) — genuine usage display only. */
export async function deploymentsToday(userId: string): Promise<number> {
  const start = new Date();
  start.setUTCHours(0, 0, 0, 0);
  const count = await db.deployment.count({
    where: {
      createdAt: { gte: start },
      bot: { userId },
    },
  });
  return count;
}

export interface QuotaCheck {
  ok: boolean;
  reason?: string;
  detail?: string;
}

/**
 * Bot-creation safety guard (NOT a plan quota): blocks pathological resource
 * exhaustion (scripts creating thousands of bots). The ceiling is a system
 * safety setting (SAFETY_MAX_BOTS_PER_USER, default 100) far above ordinary
 * use, and the message explains the real reason — never an upsell.
 */
export async function checkBotSafety(userId: string): Promise<QuotaCheck> {
  const max = ABUSE_GUARDS.maxBotsPerUser;
  const count = await db.bot.count({ where: { userId } });
  if (count >= max) {
    return {
      ok: false,
      reason: "bot_safety_limit_reached",
      detail: `You reached the platform safety ceiling of ${max} bots per account. This protects the shared infrastructure from runaway automation — if you genuinely need more, contact support.`,
    };
  }
  return { ok: true };
}

export function formatUsd(cents: number): string {
  return cents === 0 ? "Free" : `$${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;
}
