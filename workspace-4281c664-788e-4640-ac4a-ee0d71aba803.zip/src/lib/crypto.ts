/**
 * Cryptography helpers (server-only).
 * - AES-256-GCM encryption for secrets at rest (bot env vars, GitHub tokens)
 * - SHA-256 token hashing (verification tokens, session token hashes)
 * - Constant-time string compare
 */

import {
  createCipheriv,
  createDecipheriv,
  createHash,
  randomBytes,
  timingSafeEqual,
} from "node:crypto";

function appSecretBytes(): Buffer {
  const secret = process.env.APP_SECRET ?? "";
  if (secret.length < 32) {
    throw new Error("APP_SECRET must be set to at least 32 characters");
  }
  // Derive a stable 32-byte key from the configured secret.
  return createHash("sha256").update(secret, "utf8").digest();
}

/** Encrypt a UTF-8 string. Returns "v1:<iv_b64>:<tag_b64>:<cipher_b64>". */
export function encryptSecret(plaintext: string): string {
  const key = appSecretBytes();
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `v1:${iv.toString("base64")}:${tag.toString("base64")}:${enc.toString("base64")}`;
}

/** Decrypt a value produced by encryptSecret. Throws on tamper. */
export function decryptSecret(payload: string): string {
  const parts = payload.split(":");
  if (parts.length !== 4 || parts[0] !== "v1") {
    throw new Error("invalid encrypted payload format");
  }
  const key = appSecretBytes();
  const iv = Buffer.from(parts[1]!, "base64");
  const tag = Buffer.from(parts[2]!, "base64");
  const data = Buffer.from(parts[3]!, "base64");
  const decipher = createDecipheriv("aes-256-gcm", key, iv);
  decipher.setAuthTag(tag);
  return Buffer.concat([decipher.update(data), decipher.final()]).toString("utf8");
}

export function sha256Hex(input: string): string {
  return createHash("sha256").update(input, "utf8").digest("hex");
}

export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString("hex");
}

export function safeEqual(a: string, b: string): boolean {
  const ha = createHash("sha256").update(a, "utf8").digest();
  const hb = createHash("sha256").update(b, "utf8").digest();
  return timingSafeEqual(ha, hb);
}
