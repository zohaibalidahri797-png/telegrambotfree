/**
 * Audit logging for sensitive operations. Secrets must be redacted by the
 * caller — this module also strips obviously sensitive keys defensively.
 */

import { db } from "@/lib/db";

const REDACT_KEYS = /^(password|token|secret|apikey|api_key|authorization|cookie|value)$/i;

function redact(detail: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(detail)) {
    if (REDACT_KEYS.test(k)) {
      out[k] = "[redacted]";
    } else if (v !== null && typeof v === "object" && !Array.isArray(v)) {
      out[k] = redact(v as Record<string, unknown>);
    } else {
      out[k] = v;
    }
  }
  return out;
}

export async function audit(opts: {
  actorId?: string | null;
  actorEmail?: string | null;
  action: string;
  targetType?: string | null;
  targetId?: string | null;
  detail?: Record<string, unknown>;
  ip?: string | null;
  userAgent?: string | null;
}): Promise<void> {
  await db.auditLog
    .create({
      data: {
        actorId: opts.actorId ?? null,
        actorEmail: opts.actorEmail ?? null,
        action: opts.action,
        targetType: opts.targetType ?? null,
        targetId: opts.targetId ?? null,
        detail: JSON.stringify(redact(opts.detail ?? {})),
        ip: opts.ip ?? null,
        userAgent: opts.userAgent?.slice(0, 300) ?? null,
      },
    })
    .catch((err) => console.error("[audit] write failed:", err));
}
