/**
 * Platform health primitives (SERVER-ONLY) — shared by /api/health and
 * /api/auth/config so both endpoints report configuration from ONE source
 * of truth.
 *
 * Design rules (per ops/security requirements):
 *  - Every component reports an independent `status`, clearly distinguishing:
 *      healthy      — probe/config verified working
 *      unconfigured — a required/optional setting is absent (operator action)
 *      unreachable  — configured, but the live probe failed (connection error)
 *      error        — configuration exists but is invalid (e.g. bad URL)
 *  - Secret VALUES are never included. Only booleans like
 *    "appSecretConfigured" ever leave the server.
 *  - A component being down never marks an independent component down.
 */

export type ComponentStatus = "healthy" | "unconfigured" | "unreachable" | "error";

export interface AppSecretStatus {
  /** True when APP_SECRET is present at all. */
  configured: boolean;
  /** True when APP_SECRET meets the minimum length enforced by session.ts. */
  valid: boolean;
}

export function appSecretStatus(env: Record<string, string | undefined> = process.env): AppSecretStatus {
  const secret = env.APP_SECRET ?? "";
  return { configured: secret.length > 0, valid: secret.length >= 32 };
}

export interface OAuthProviderStatus {
  google: boolean;
  github: boolean;
}

/** A provider is "configured" only when BOTH the id and the secret are set. */
export function oauthProviderStatus(env: Record<string, string | undefined> = process.env): OAuthProviderStatus {
  return {
    google: Boolean(env.GOOGLE_CLIENT_ID && env.GOOGLE_CLIENT_SECRET),
    github: Boolean(env.GITHUB_CLIENT_ID && env.GITHUB_CLIENT_SECRET),
  };
}

export interface EmailProviderStatus {
  /** "resend" when RESEND_API_KEY is set; "none" otherwise. */
  provider: "resend" | "none";
  fromConfigured: boolean;
}

export function emailProviderStatus(env: Record<string, string | undefined> = process.env): EmailProviderStatus {
  return {
    provider: env.RESEND_API_KEY ? "resend" : "none",
    fromConfigured: Boolean(env.EMAIL_FROM),
  };
}

export interface AppUrlStatus {
  configured: boolean;
  /** APP_URL is public by design (it appears in emails/OAuth callbacks), so
   *  echoing it here is safe and helps operators diagnose wrong-domain setup. */
  url?: string;
  https: boolean;
}

export function appUrlStatus(env: Record<string, string | undefined> = process.env): AppUrlStatus {
  const url = env.APP_URL?.trim() ?? "";
  return {
    configured: url.length > 0,
    ...(url ? { url } : {}),
    https: url.startsWith("https://"),
  };
}

// ── Health report assembly ───────────────────────────────────────────────────

export interface HealthProbeInput {
  /** Result of a live `SELECT 1` against the database. */
  dbOk: boolean;
  /** Result of a live ping to the bot runtime service. */
  runtimePing: { ok: boolean; version?: string; uptimeSec?: number; activeBots?: number };
  /** Live invalid-config reason from resolveRuntimeUrl(), when any. */
  runtimeConfigError?: string;
  /** Result of the first-user count for bootstrap reporting (best-effort). */
  bootstrapRequired?: boolean;
  /** From isRuntimeEmbedded() — injected so this module never re-implements
   *  the (tested) logic in runtime-config.ts. */
  runtimeEmbedded: boolean;
  /** From resolveRuntimeUrl().source. */
  runtimeUrlSource: string;
}

export interface HealthReport {
  ok: boolean;
  degraded: boolean;
  service: "botdock-cloud-web";
  time: string;
  app: {
    status: ComponentStatus;
    appUrlConfigured: boolean;
    appUrl?: string;
    appUrlHttps: boolean;
    appSecretConfigured: boolean;
    nodeEnv: string;
  };
  database: {
    status: ComponentStatus;
    transport: "sqlite-local" | "libsql-remote";
  };
  auth: {
    status: ComponentStatus;
    googleConfigured: boolean;
    githubConfigured: boolean;
    registrationEnabled: boolean;
    bootstrapRequired: boolean;
  };
  email: {
    status: ComponentStatus;
    provider: "resend" | "none";
    fromConfigured: boolean;
  };
  runtime: {
    status: ComponentStatus;
    ok: boolean;
    embedded: boolean;
    urlSource: string;
    version?: string;
    uptimeSec?: number;
    activeBots?: number;
  };
}

/**
 * Pure report builder — no I/O — so tests can drive every branch with
 * injected probe results.
 */
export function buildHealthReport(
  input: HealthProbeInput,
  env: Record<string, string | undefined> = process.env,
): HealthReport {
  const secret = appSecretStatus(env);
  const providers = oauthProviderStatus(env);
  const email = emailProviderStatus(env);
  const appUrl = appUrlStatus(env);

  const app: HealthReport["app"] = {
    status: secret.valid ? "healthy" : "unconfigured",
    appUrlConfigured: appUrl.configured,
    appUrlHttps: appUrl.https,
    appSecretConfigured: secret.configured,
    nodeEnv: env.NODE_ENV ?? "development",
    ...(appUrl.url ? { appUrl: appUrl.url } : {}),
  };

  const database: HealthReport["database"] = {
    status: input.dbOk ? "healthy" : "unreachable",
    transport: env.DATABASE_URL?.trim().startsWith("libsql://")
      ? "libsql-remote"
      : env.DATABASE_URL?.trim().startsWith("https://")
        ? "libsql-remote"
        : "sqlite-local",
  };

  const auth: HealthReport["auth"] = {
    // Auth works (sessions can be signed) as soon as the secret is valid and
    // the DB is reachable; provider buttons are OPTIONAL extras reported as
    // booleans, NOT as health failures.
    status: secret.valid && input.dbOk ? "healthy" : secret.valid ? "unreachable" : "unconfigured",
    googleConfigured: providers.google,
    githubConfigured: providers.github,
    registrationEnabled: true,
    bootstrapRequired: input.bootstrapRequired ?? false,
  };

  const emailReport: HealthReport["email"] = {
    // Email is OPTIONAL: without a provider the platform still works and
    // verification links are logged honestly — that is "unconfigured",
    // not "unhealthy".
    status: email.provider === "resend" ? "healthy" : "unconfigured",
    provider: email.provider,
    fromConfigured: email.fromConfigured,
  };

  let runtimeStatus: ComponentStatus;
  if (input.runtimeConfigError) runtimeStatus = "error";
  else if (input.runtimePing.ok) runtimeStatus = "healthy";
  else runtimeStatus = "unreachable";

  const runtime: HealthReport["runtime"] = {
    status: runtimeStatus,
    ok: input.runtimePing.ok,
    embedded: input.runtimeEmbedded,
    urlSource: input.runtimeUrlSource,
    ...(input.runtimePing.version ? { version: input.runtimePing.version } : {}),
    ...(input.runtimePing.uptimeSec !== undefined ? { uptimeSec: input.runtimePing.uptimeSec } : {}),
    ...(input.runtimePing.activeBots !== undefined ? { activeBots: input.runtimePing.activeBots } : {}),
  };

  // The platform is operational when its CORE (config + database) works.
  // Optional/auxiliary components (runtime, email, OAuth providers) degrade
  // the report but never break `ok`.
  const core = app.status === "healthy" && database.status === "healthy";
  const components: ComponentStatus[] = [app.status, database.status, auth.status, emailReport.status, runtime.status];
  const degraded = components.some((s) => s !== "healthy");

  return {
    ok: core,
    degraded,
    service: "botdock-cloud-web",
    time: new Date().toISOString(),
    app,
    database,
    auth,
    email: emailReport,
    runtime,
  };
}
