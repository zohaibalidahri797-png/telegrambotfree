/**
 * Runtime configuration (SERVER-ONLY).
 *
 * Single source of truth for how the web app reaches the bot runtime service
 * (mini-services/bot-runtime) and where runtime data lives on disk.
 *
 * Resolution order for the runtime base URL:
 *   1. RUNTIME_SERVICE_URL (documented production setting) — must be an
 *      absolute http(s) URL. HTTPS is REQUIRED for public production hosts.
 *   2. Fallback (development default): http://127.0.0.1:<RUNTIME_SERVICE_PORT>.
 *
 * SECURITY:
 *  - This module must never be imported from client components. It reads
 *    RUNTIME_API_KEY indirectly (runtimeApiKey()) which is a shared secret.
 *  - Runtime calls are server-to-server only (see runtime-client.ts).
 *  - RUNTIME_EMBEDDED=false prevents the supervisor from spawning a runtime
 *    inside the web app process (mandatory on Cloudflare Workers).
 */

import path from "node:path";

export type RuntimeUrlSource = "configured" | "default-local";

/** Minimal env shape — lets tests pass plain objects instead of process.env. */
export interface RuntimeEnvLike {
  NODE_ENV?: string;
  RUNTIME_SERVICE_URL?: string;
  RUNTIME_SERVICE_PORT?: string;
  RUNTIME_EMBEDDED?: string;
}

export interface RuntimeUrlResolution {
  /** Normalized base URL, no trailing slash. Empty string when invalid. */
  url: string;
  /** Where the value came from. */
  source: RuntimeUrlSource;
  /** True when RUNTIME_SERVICE_URL was set but failed validation. */
  invalid: boolean;
  /** Human-readable reason when invalid (for health checks / logs). */
  reason?: string;
}

function isLoopbackHost(hostname: string): boolean {
  const h = hostname.toLowerCase();
  return (
    h === "localhost" ||
    h === "127.0.0.1" ||
    h === "[::1]" ||
    h === "::1" ||
    h.endsWith(".localhost")
  );
}

function isPrivateHost(hostname: string): boolean {
  const h = hostname.toLowerCase();
  if (isLoopbackHost(h)) return true;
  // Private/loopback ranges and .internal — plain HTTP is acceptable only in
  // private networks; public production endpoints must use HTTPS.
  if (h.endsWith(".internal")) return true;
  if (/^10\./.test(h)) return true;
  if (/^192\.168\./.test(h)) return true;
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(h)) return true;
  return false;
}

function normalize(url: URL): string {
  return url.origin === "null" ? url.toString().replace(/\/$/, "") : url.origin;
}

/**
 * Resolve and validate the runtime base URL. Never throws — invalid
 * configuration is reported via `invalid`/`reason` so health checks can
 * surface it instead of silently pointing at localhost.
 */
export function resolveRuntimeUrl(env: RuntimeEnvLike = process.env): RuntimeUrlResolution {
  const raw = env.RUNTIME_SERVICE_URL?.trim();

  if (raw) {
    let parsed: URL;
    try {
      parsed = new URL(raw);
    } catch {
      return {
        url: "",
        source: "configured",
        invalid: true,
        reason: `RUNTIME_SERVICE_URL is not a valid URL: "${raw}"`,
      };
    }
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      return {
        url: "",
        source: "configured",
        invalid: true,
        reason: `RUNTIME_SERVICE_URL must use http or https (got "${parsed.protocol}")`,
      };
    }
    const production = env.NODE_ENV === "production";
    if (parsed.protocol === "http:" && !isPrivateHost(parsed.hostname)) {
      if (production) {
        return {
          url: "",
          source: "configured",
          invalid: true,
          reason: `RUNTIME_SERVICE_URL must use HTTPS in production for public endpoints (got http://${parsed.hostname})`,
        };
      }
      // Non-production: allow but flag via reason-less resolution; still accept.
    }
    // Strip any path/query — the runtime is addressed at its origin root.
    return { url: normalize(parsed), source: "configured", invalid: false };
  }

  const port = (() => {
    const n = Number(env.RUNTIME_SERVICE_PORT ?? "3030");
    return Number.isInteger(n) && n > 0 && n <= 65535 ? n : 3030;
  })();
  return { url: `http://127.0.0.1:${port}`, source: "default-local", invalid: false };
}

/**
 * Base URL of the bot runtime service. Development default: the embedded
 * localhost service. Production: whatever RUNTIME_SERVICE_URL points at.
 */
export function runtimeBaseUrl(): string {
  return resolveRuntimeUrl().url;
}

/** Legacy helper kept for the embedded supervisor (local spawn port). */
export function runtimePort(): number {
  const raw = process.env.RUNTIME_SERVICE_PORT ?? "3030";
  const n = Number(raw);
  return Number.isInteger(n) && n > 0 && n <= 65535 ? n : 3030;
}

/** Shared secret for web app → runtime calls. NEVER expose to the client. */
export function runtimeApiKey(): string {
  return process.env.RUNTIME_API_KEY ?? "";
}

/** Absolute path of the runtime data dir (staging/, bots/, logs/, builds/, state.json). */
export function runtimeDataDir(): string {
  const raw = process.env.RUNTIME_DATA_DIR?.trim() || "./bot-data";
  return path.resolve(process.cwd(), raw);
}

/**
 * True when the runtime is expected to run embedded next to the web app and
 * may be spawned by the supervisor. Set RUNTIME_EMBEDDED=false in production
 * (mandatory on Cloudflare Workers — they cannot spawn processes).
 */
export function isRuntimeEmbedded(env: RuntimeEnvLike = process.env): boolean {
  return env.RUNTIME_EMBEDDED !== "false";
}
