import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const siteUrl = (process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, "");

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "BotDock Cloud — Hosting for Telegram bots & automations",
    template: "%s — BotDock Cloud",
  },
  description:
    "Deploy Python, Node.js and Bun bots to isolated, resource-limited processes with real logs, real metrics, and an honest free plan.",
  keywords: ["BotDock", "bot hosting", "Telegram bot hosting", "Python bots", "Node.js bots", "cloud bots"],
  authors: [{ name: "BotDock Cloud" }],
  alternates: { canonical: "/" },
  openGraph: {
    title: "BotDock Cloud — Hosting for Telegram bots & automations",
    description: "Ship your bots to the cloud. Keep every process honest.",
    siteName: "BotDock Cloud",
    url: siteUrl,
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "BotDock Cloud",
    description: "Ship your bots to the cloud. Keep every process honest.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#080b14",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
