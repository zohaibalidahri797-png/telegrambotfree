import type { Metadata } from "next";
import { PageH1, PageLead, PublicPage } from "@/content/public-pages";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "BotDock Cloud Terms of Service: acceptable use, resource limits, billing and account termination.",
  alternates: { canonical: "/terms" },
};

export default function TermsPage() {
  return (
    <PublicPage>
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6">
        <PageH1>Terms of Service</PageH1>
        <PageLead>Last updated: March 2026. By creating an account you agree to these terms.</PageLead>

        <div className="mt-10 space-y-8 text-sm text-muted-foreground">
          <section>
            <h2 className="text-base font-semibold text-foreground">1. The service</h2>
            <p className="mt-2">
              BotDock Cloud hosts long-running bot and automation processes (Python, Node.js, Bun) in
              isolated, resource-limited runtimes. Features and limits depend on your plan and are
              enforced server-side.
            </p>
          </section>
          <section>
            <h2 className="text-base font-semibold text-foreground">2. Acceptable use</h2>
            <p className="mt-2">You may not use BotDock Cloud to:</p>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              <li>run malware, cryptominers, denial-of-service tools, or spam operations;</li>
              <li>attack, probe, or interfere with the platform, its users, or third parties;</li>
              <li>violate Telegram&apos;s Terms of Service or any applicable law;</li>
              <li>circumvent plan limits, rate limits, or isolation boundaries.</li>
            </ul>
            <p className="mt-2">
              Violations lead to suspension or termination and may be reported to authorities.
            </p>
          </section>
          <section>
            <h2 className="text-base font-semibold text-foreground">3. Your content</h2>
            <p className="mt-2">
              You keep ownership of the code and data you deploy. You are responsible for keeping
              backups; the platform provides log retention per plan but is not an archival service.
            </p>
          </section>
          <section>
            <h2 className="text-base font-semibold text-foreground">4. Billing</h2>
            <p className="mt-2">
              Paid plans renew monthly or yearly as selected. Quotas are enforced at the time of each
              operation. Downgrades take effect for new resource usage; running processes that exceed
              a new plan&apos;s limits may be stopped.
            </p>
          </section>
          <section>
            <h2 className="text-base font-semibold text-foreground">5. Availability</h2>
            <p className="mt-2">
              The service is provided as-is, without a guaranteed uptime SLA on free and trial usage.
              Platform health is published at <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">/api/health</code>.
            </p>
          </section>
          <section>
            <h2 className="text-base font-semibold text-foreground">6. Termination</h2>
            <p className="mt-2">
              You can delete your account and bots at any time from the dashboard. We may suspend or
              terminate accounts that violate these terms, with notice where practical.
            </p>
          </section>
        </div>
      </div>
    </PublicPage>
  );
}
