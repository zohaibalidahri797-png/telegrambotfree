/** GET /api/broadcasts/:id — delivery detail (admin only). */
import { ok, fail, requireAdmin } from "@/lib/api";
import { db } from "@/lib/db";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");

  const broadcast = await db.broadcast.findUnique({
    where: { id },
    include: {
      recipients: {
        orderBy: { createdAt: "asc" },
        select: { userId: true, channel: true, status: true, error: true, createdAt: true },
      },
    },
  });
  if (!broadcast) return fail(404, "broadcast_not_found");

  const byChannel: Record<string, { sent: number; failed: number; skipped: number }> = {};
  for (const r of broadcast.recipients) {
    byChannel[r.channel] ??= { sent: 0, failed: 0, skipped: 0 };
    if (r.status === "SENT" || r.status === "DELIVERED") byChannel[r.channel]!.sent += 1;
    else if (r.status === "FAILED") byChannel[r.channel]!.failed += 1;
    else if (r.status === "SKIPPED") byChannel[r.channel]!.skipped += 1;
  }

  return ok({ broadcast, byChannel, recipientCount: broadcast.recipients.length });
}
