/**
 * Broadcast system (admin only): site-wide announcements with real delivery
 * tracking per recipient and channel. Channels:
 *  - INAPP:    always deliverable → Notification rows linked to the broadcast
 *  - EMAIL:    only when Resend is configured; otherwise rows are recorded as
 *              SKIPPED with reason "email_not_configured" (never fake "sent")
 *  - TELEGRAM: only when TELEGRAM_BOT_TOKEN is configured AND the user has a
 *              linked telegramChatId
 * Large sends require an explicit confirm flag. Test sends target the admin.
 */
import { ok, fail, requireAdmin, originCheck, reqCtx, readJson } from "@/lib/api";
import { db } from "@/lib/db";
import { broadcastSchema, zodErrorMessage } from "@/lib/validation";
import { audit } from "@/lib/audit";
import { sendEmail, genericEmail, emailProviderConfigured, escapeHtml } from "@/lib/email";
import { rateLimit } from "@/lib/rate-limit";

const LARGE_SEND_THRESHOLD = 20;

async function resolveAudience(audience: string) {
  const base = { select: { id: true, email: true, name: true, telegramChatId: true, status: true }, orderBy: { createdAt: "asc" as const } };
  if (audience === "ALL") return db.user.findMany({ ...base });
  if (audience === "VERIFIED") return db.user.findMany({ where: { emailVerified: { not: null } }, ...base });
  if (audience === "SUSPENDED") return db.user.findMany({ where: { status: { in: ["SUSPENDED", "BANNED"] } }, ...base });
  if (audience.startsWith("PLAN:")) {
    const planId = audience.slice(5);
    return db.user.findMany({ where: { subscription: { planId } }, ...base });
  }
  return db.user.findMany({ ...base });
}

export async function GET() {
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const broadcasts = await db.broadcast.findMany({
    orderBy: { createdAt: "desc" },
    take: 50,
    include: { _count: { select: { recipients: true } } },
  });
  return ok({
    broadcasts,
    channels: {
      email: emailProviderConfigured(),
      telegram: Boolean(process.env.TELEGRAM_BOT_TOKEN),
    },
  });
}

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const rl = await rateLimit(`broadcast:${auth.user.id}`, 10, 3600);
  if (!rl.ok) return fail(429, "rate_limited", { retryAfterSec: rl.retryAfterSec });

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = broadcastSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const input = parsed.data;
  const confirm = body?.confirm === true;
  const isTest = body?.test === true;

  const channels = input.channels;
  const emailConfigured = emailProviderConfigured();
  const telegramConfigured = Boolean(process.env.TELEGRAM_BOT_TOKEN);
  const unavailable: string[] = [];
  if (channels.includes("EMAIL") && !emailConfigured) unavailable.push("EMAIL (no email provider configured)");
  if (channels.includes("TELEGRAM") && !telegramConfigured) unavailable.push("TELEGRAM (no bot token configured)");

  const broadcast = await db.broadcast.create({
    data: {
      title: input.title,
      body: input.body,
      level: input.level,
      category: input.category,
      audience: input.audience,
      channels: JSON.stringify(channels),
      status: "DRAFT",
      scheduledFor: input.scheduledFor ? new Date(input.scheduledFor) : null,
      createdBy: auth.user.id,
    },
  });

  if (!input.send) {
    await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "BROADCAST_DRAFT", targetType: "broadcast", targetId: broadcast.id, detail: { title: input.title }, ip, userAgent });
    return ok({ ok: true, broadcast, savedAs: "DRAFT" }, { status: 201 });
  }

  // recipients
  const recipients = isTest ? [{ id: auth.user.id, email: auth.user.email, name: auth.user.name, telegramChatId: null, status: "ACTIVE" }] : await resolveAudience(input.audience);
  if (!isTest && recipients.length > LARGE_SEND_THRESHOLD && !confirm) {
    // keep the draft; require explicit confirmation for large sends
    await db.broadcast.delete({ where: { id: broadcast.id } });
    return fail(428, "confirmation_required", {
      detail: `This broadcast targets ${recipients.length} users. Re-send with confirm:true after reviewing.`,
      recipientCount: recipients.length,
    });
  }
  if (isTest) {
    await db.broadcast.update({ where: { id: broadcast.id }, data: { title: `[TEST] ${input.title}` } });
  }

  await db.broadcast.update({ where: { id: broadcast.id }, data: { status: "SENDING", totalRecipients: recipients.length } });

  let delivered = 0;
  let failed = 0;
  let skipped = 0;

  for (const user of recipients) {
    for (const channel of channels) {
      let status = "QUEUED";
      let error: string | null = null;
      try {
        if (channel === "INAPP") {
          await db.notification.create({
            data: {
              userId: user.id,
              title: isTest ? `[TEST] ${input.title}` : input.title,
              body: input.body,
              level: input.level,
              category: "BROADCAST",
              broadcastId: broadcast.id,
            },
          });
          status = "SENT";
          delivered += 1;
        } else if (channel === "EMAIL") {
          if (!emailConfigured) {
            status = "SKIPPED";
            error = "email_not_configured";
            skipped += 1;
          } else {
            const mail = genericEmail(input.title, input.body);
            const res = await sendEmail({ to: user.email, subject: mail.subject, text: mail.text, html: mail.html, template: "broadcast", userId: user.id });
            if (res.delivered) {
              status = "SENT";
              delivered += 1;
            } else {
              status = "FAILED";
              error = res.error ?? "send_failed";
              failed += 1;
            }
          }
        } else if (channel === "TELEGRAM") {
          if (!telegramConfigured) {
            status = "SKIPPED";
            error = "telegram_not_configured";
            skipped += 1;
          } else if (!user.telegramChatId) {
            status = "SKIPPED";
            error = "user_has_no_telegram_linked";
            skipped += 1;
          } else {
            const tg = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ chat_id: user.telegramChatId, text: `<b>${escapeHtml(input.title)}</b>\n\n${escapeHtml(input.body)}`, parse_mode: "HTML" }),
            });
            const tgBody = (await tg.json().catch(() => ({}))) as { ok?: boolean; description?: string };
            if (tg.ok && tgBody.ok) {
              status = "SENT";
              delivered += 1;
            } else {
              status = "FAILED";
              error = `telegram_${tg.status}: ${tgBody.description ?? "unknown"}`.slice(0, 300);
              failed += 1;
            }
          }
        }
      } catch (err) {
        status = "FAILED";
        error = (err instanceof Error ? err.message : String(err)).slice(0, 300);
        failed += 1;
      }
      await db.broadcastRecipient.create({
        data: { broadcastId: broadcast.id, userId: user.id, channel, status, error },
      });
    }
  }

  const finalStatus = failed === 0 && skipped === 0 ? "SENT" : delivered > 0 ? "PARTIAL" : failed > 0 ? "PARTIAL" : "FAILED";
  const updated = await db.broadcast.update({
    where: { id: broadcast.id },
    data: { status: finalStatus, sentAt: new Date(), delivered, failed, skipped },
  });

  await audit({
    actorId: auth.user.id,
    actorEmail: auth.user.email,
    action: isTest ? "BROADCAST_TEST" : "BROADCAST_SEND",
    targetType: "broadcast",
    targetId: broadcast.id,
    detail: { recipients: recipients.length, channels, delivered, failed, skipped, unavailable },
    ip,
    userAgent,
  });

  return ok({ ok: true, broadcast: updated, unavailable, savedAs: finalStatus }, { status: 201 });
}
