/**
 * GET /api/deployments — the signed-in user's recent deployments
 * across all of their bots (newest first). Admins see everything.
 *
 * Query: ?limit=50 (max 100) · ?status=RUNNING|FAILED|… (optional filter)
 * Contract route from the platform specification — the per-bot list
 * remains at GET /api/bots/:id/deployments.
 */
import { ok, fail, requireUser } from "@/lib/api";
import { db } from "@/lib/db";

const VALID_STATUS = new Set(["QUEUED", "BUILDING", "DEPLOYING", "RUNNING", "FAILED", "CANCELED"]);

export async function GET(req: Request) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;

  const url = new URL(req.url);
  const limitParam = Number(url.searchParams.get("limit") ?? "50");
  const limit = Math.min(Math.max(Number.isFinite(limitParam) ? Math.floor(limitParam) : 50, 1), 100);
  const status = url.searchParams.get("status");
  const botId = url.searchParams.get("botId");

  if (status && !VALID_STATUS.has(status)) return fail(400, "invalid_status");
  if (botId && !/^[a-zA-Z0-9_-]{1,64}$/.test(botId)) return fail(400, "invalid_id");

  const isAdmin = auth.user.role === "ADMIN";
  const deployments = await db.deployment.findMany({
    where: {
      ...(isAdmin ? {} : { bot: { userId: auth.user.id } }),
      ...(status ? { status } : {}),
      ...(botId ? { botId } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: limit,
    include: { bot: { select: { name: true, userId: true } } },
  });

  return ok({
    deployments: deployments.map((d) => ({
      id: d.id,
      botId: d.botId,
      botName: d.bot.name,
      number: d.number,
      status: d.status,
      sourceType: d.sourceType,
      sourceRef: d.sourceRef,
      commitSha: d.commitSha,
      commitMessage: d.commitMessage,
      error: d.error,
      startedAt: d.startedAt,
      finishedAt: d.finishedAt,
      createdAt: d.createdAt,
    })),
    limit,
  });
}
