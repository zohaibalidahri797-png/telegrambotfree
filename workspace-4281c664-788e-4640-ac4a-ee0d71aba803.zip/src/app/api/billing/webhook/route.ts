/**
 * POST /api/billing/webhook — Stripe webhook with signature verification.
 * The subscription changes ONLY here (server-verified), never via browser
 * redirects. Configure STRIPE_WEBHOOK_SECRET and point Stripe at this route.
 */
import { NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/notify";
import { monetizationEnabled } from "@/lib/monetization";

function verifyStripeSignature(payload: string, header: string | null, secret: string): boolean {
  if (!header) return false;
  const parts = header.split(",").map((p) => p.trim().split("="));
  const t = parts.find((p) => p[0] === "t")?.[1];
  const v1 = parts.find((p) => p[0] === "v1")?.[1];
  if (!t || !v1) return false;
  const expected = createHmac("sha256", secret).update(`${t}.${payload}`, "utf8").digest("hex");
  const a = Buffer.from(expected, "utf8");
  const b = Buffer.from(v1, "utf8");
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function POST(req: Request) {
  // FREE-FIRST LAUNCH: no payments exist, so payment webhooks are inert.
  // The verified-webhook implementation below is retained for future
  // monetization and activates together with MONETIZATION_ENABLED.
  if (!monetizationEnabled()) {
    return NextResponse.json(
      { error: "billing_disabled", detail: "BotDock Cloud is free during launch — payment webhooks are disabled." },
      { status: 501 },
    );
  }
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  const payload = await req.text();

  if (!secret) {
    return NextResponse.json({ error: "webhook_not_configured", detail: "Set STRIPE_WEBHOOK_SECRET to enable payment webhooks." }, { status: 501 });
  }
  if (!verifyStripeSignature(payload, req.headers.get("stripe-signature"), secret)) {
    await audit({ action: "WEBHOOK_SIGNATURE_INVALID", targetType: "stripe", detail: {} }).catch(() => undefined);
    return NextResponse.json({ error: "invalid_signature" }, { status: 400 });
  }

  let event: { type?: string; data?: { object?: Record<string, unknown> } };
  try {
    event = JSON.parse(payload);
  } catch {
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }

  const obj = event.data?.object ?? {};
  switch (event.type) {
    case "checkout.session.completed": {
      const metadata = (obj.metadata ?? {}) as Record<string, unknown>;
      const userId = String(obj.client_reference_id ?? metadata.userId ?? "");
      const planId = String(metadata.planId ?? "");
      const billingCycle = String(metadata.billingCycle ?? "MONTHLY");
      const paymentIntent = typeof obj.payment_intent === "string" ? obj.payment_intent : null;
      if (userId && planId) {
        const periodEnd = new Date(Date.now() + (billingCycle === "YEARLY" ? 365 : 30) * 86400_000);
        await db.$transaction([
          db.subscription.upsert({
            where: { userId },
            update: { planId, status: "ACTIVE", billingCycle, currentPeriodStart: new Date(), currentPeriodEnd: periodEnd, provider: "STRIPE", cancelAtPeriodEnd: false },
            create: { userId, planId, status: "ACTIVE", billingCycle, provider: "STRIPE" },
          }),
          db.payment.updateMany({
            where: { userId, providerRef: obj.id as string | undefined, status: "PENDING" },
            data: { status: "SUCCEEDED", providerRef: paymentIntent ?? (obj.id as string | undefined) ?? null },
          }),
        ]);
        await audit({ actorId: userId, action: "PAYMENT_CONFIRMED", targetType: "subscription", targetId: planId, detail: { provider: "stripe", event: event.type } }).catch(() => undefined);
        await notify(userId, {
          title: "Payment confirmed",
          body: `Your subscription is now active on the ${planId} plan. Thank you for supporting BotDock Cloud!`,
          level: "SUCCESS",
          category: "BILLING",
        }).catch(() => undefined);
      }
      break;
    }
    case "invoice.payment_failed": {
      const customer = typeof obj.customer === "string" ? obj.customer : null;
      if (customer) {
        const sub = await db.subscription.findFirst({ where: { providerCustomerId: customer } });
        if (sub) {
          await db.subscription.update({ where: { id: sub.id }, data: { status: "PAST_DUE" } });
          await notify(sub.userId, {
            title: "Payment failed",
            body: "Your latest invoice could not be paid. Update your payment method to keep your plan active.",
            level: "ERROR",
            category: "BILLING",
          }).catch(() => undefined);
        }
      }
      break;
    }
    case "customer.subscription.deleted": {
      const subId = typeof obj.id === "string" ? obj.id : null;
      if (subId) {
        const sub = await db.subscription.findFirst({ where: { providerSubscriptionId: subId } });
        if (sub) {
          const free = await db.plan.findUnique({ where: { id: "free" } });
          await db.subscription.update({
            where: { id: sub.id },
            data: { planId: free ? "free" : sub.planId, status: "CANCELED", provider: "NONE", billingCycle: "NONE", cancelAtPeriodEnd: false },
          });
          await notify(sub.userId, {
            title: "Subscription cancelled",
            body: "Your paid subscription ended; the account moved back to the Free plan.",
            level: "WARNING",
            category: "BILLING",
          }).catch(() => undefined);
        }
      }
      break;
    }
    default:
      // unhandled event types are acknowledged but ignored
      break;
  }

  return NextResponse.json({ received: true });
}
