import { db } from "@/lib/db";
import { ok, fail, requireUser, originCheck, reqCtx, readJson } from "@/lib/api";
import { botCreateSchema, zodErrorMessage } from "@/lib/validation";
import { getEffectivePlan, checkBotSafety } from "@/lib/plans";
import { getTemplate } from "@/lib/templates";
import { writeTemplateFiles, RuntimeOfflineError, FileOpError } from "@/lib/bot-fs";
import { audit } from "@/lib/audit";
import { runtimeClient, isRuntimeUnavailable } from "@/lib/runtime-client";
import { ensureSeed } from "@/lib/seed";

/** GET /api/bots — the signed-in user's bots with live runtime status. */
export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;

  await ensureSeed().catch(() => undefined);
  const bots = await db.bot.findMany({
    where: { userId: auth.user.id },
    orderBy: { createdAt: "desc" },
  });

  const withRuntime = await Promise.all(
    bots.map(async (bot) => {
      let runtimeStatus: string | null = null;
      let runtimeReachable = false;
      let memoryMb: number | "unknown" | null = null;
      let uptimeSec: number | null = null;
      try {
        const st = await runtimeClient.status(bot.id);
        runtimeReachable = true;
        runtimeStatus = st.state ?? null;
        memoryMb = st.memoryMb ?? null;
        uptimeSec = st.uptimeSec ?? null;
      } catch (err) {
        runtimeStatus = isRuntimeUnavailable(err) ? "RUNTIME_OFFLINE" : null;
      }
      return {
        id: bot.id,
        name: bot.name,
        description: bot.description,
        runtime: bot.runtime,
        status: bot.status,
        runtimeStatus,
        runtimeReachable,
        memoryMb,
        uptimeSec,
        sourceType: bot.sourceType,
        sourceRef: bot.sourceRef,
        currentDeploymentId: bot.currentDeploymentId,
        lastDeployedAt: bot.lastDeployedAt,
        createdAt: bot.createdAt,
      };
    }),
  );

  const plan = await getEffectivePlan(auth.user.id);
  const anyRuntimeOffline = withRuntime.length > 0 && withRuntime.some((b) => !b.runtimeReachable);
  let runtimeReachableGlobal = true;
  try {
    await runtimeClient.health(2500);
  } catch {
    runtimeReachableGlobal = false;
  }

  return ok({
    bots: withRuntime,
    plan: {
      id: plan.planId,
      name: plan.planName,
      limits: plan.limits,
    },
    usage: { botsUsed: bots.length },
    runtimeReachable: runtimeReachableGlobal,
    runtimeNote: runtimeReachableGlobal ? null : "The bot runtime service is offline — bots cannot start, stop or deploy right now.",
  });
}

/** POST /api/bots — create a bot from a template (JSON). */
export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  if (!body) return fail(400, "invalid_json");
  const parsed = botCreateSchema.safeParse(body);
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const input = parsed.data;

  const plan = await getEffectivePlan(auth.user.id);
  const safety = await checkBotSafety(auth.user.id);
  if (!safety.ok) return fail(403, safety.reason!, { detail: safety.detail });

  if (input.sourceType === "TEMPLATE") {
    const template = getTemplate(input.templateId ?? "");
    if (!template) return fail(400, "unknown_template", { detail: "Pick a valid template." });
    if (template.runtime !== input.runtime) {
      return fail(400, "template_runtime_mismatch", { detail: `Template "${template.name}" targets the ${template.runtime} runtime.` });
    }
    if (!plan.limits.runtimes.includes(input.runtime)) {
      return fail(403, "runtime_not_enabled", { detail: `The ${input.runtime} runtime is not enabled on this deployment.` });
    }

    const bot = await db.bot.create({
      data: {
        userId: auth.user.id,
        name: input.name,
        description: input.description || template.description.slice(0, 300),
        runtime: input.runtime,
        startCommand: input.startCommand || template.startCommand,
        sourceType: "TEMPLATE",
        sourceRef: template.id,
        status: "CREATED",
      },
    });
    try {
      await writeTemplateFiles(bot.id, template.files); // via runtime service
    } catch (err) {
      // Roll back — never leave a bot without its template files.
      await db.bot.delete({ where: { id: bot.id } }).catch(() => undefined);
      if (err instanceof RuntimeOfflineError) {
        return fail(503, "runtime_unavailable", {
          detail: "The bot runtime service is not reachable, so bot workspaces cannot be created right now. It may be starting — try again shortly.",
        });
      }
      const detail = err instanceof FileOpError || err instanceof Error ? err.message : "template_write_failed";
      return fail(500, "template_write_failed", { detail });
    }
    await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "BOT_CREATE", targetType: "bot", targetId: bot.id, detail: { name: bot.name, template: template.id, runtime: bot.runtime }, ip, userAgent });
    return ok({ ok: true, bot: { id: bot.id, name: bot.name } }, { status: 201 });
  }

  return fail(400, "use_upload_or_github", { detail: "For archives use /api/bots/upload; for repositories use /api/github/import." });
}

export function PUT() {
  return fail(405, "method_not_allowed");
}
