/**
 * GET /api/bots/:id/logs — runtime logs (tail) or build logs for a deployment.
 * Query: ?build=<deploymentId> for build logs; ?tail=N (max 1000).
 */
import { ok, fail, requireUser } from "@/lib/api";
import { db } from "@/lib/db";
import { runtimeClient, isRuntimeUnavailable, type RuntimeLogLine } from "@/lib/runtime-client";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");

  const bot = await db.bot.findUnique({ where: { id } });
  if (!bot || (bot.userId !== auth.user.id && auth.user.role !== "ADMIN")) return fail(404, "bot_not_found");

  const url = new URL(req.url);
  const tailParam = Number(url.searchParams.get("tail") ?? "200");
  const tail = Math.min(Math.max(Number.isFinite(tailParam) ? Math.floor(tailParam) : 200, 1), 1000);
  const buildId = url.searchParams.get("build");

  try {
    if (buildId) {
      // verify the deployment belongs to this bot
      const dep = await db.deployment.findFirst({ where: { id: buildId, botId: id } });
      if (!dep) return fail(404, "deployment_not_found");
      const res = await runtimeClient.buildLogs(id, buildId, tail);
      if (res.error === "build_log_not_found") {
        return ok({ lines: [] as RuntimeLogLine[], truncated: false, note: "No build log stored for this deployment." });
      }
      const lines: RuntimeLogLine[] = (res.lines ?? []).map((text: string | RuntimeLogLine) =>
        typeof text === "string" ? { ts: 0, stream: "out" as const, text } : text,
      );
      return ok({ lines, truncated: res.truncated ?? false, kind: "build", deploymentId: buildId, status: dep.status });
    }
    const res = await runtimeClient.logs(id, tail);
    return ok({ lines: res.lines ?? [], truncated: res.truncated ?? false, kind: "runtime" });
  } catch (err) {
    if (isRuntimeUnavailable(err)) {
      return ok({
        lines: [],
        truncated: false,
        kind: buildId ? "build" : "runtime",
        runtimeUnavailable: true,
        note: "The bot runtime service is offline, so logs are temporarily unavailable.",
      });
    }
    return fail(500, "logs_failed", { detail: err instanceof Error ? err.message : String(err) });
  }
}
