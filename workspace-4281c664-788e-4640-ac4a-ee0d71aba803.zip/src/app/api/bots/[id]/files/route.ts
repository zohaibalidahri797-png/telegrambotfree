/**
 * Bot workspace file manager API — proxies to the botdock-runtime service
 * (the runtime owns the disk; the web app must stay Cloudflare-compatible).
 *
 *  GET  ?path=dir        → list entries
 *  GET  ?path=file&read=1 → read a text file
 *  PUT  { path, content } → write a text file
 *  POST { path }          → create a directory
 *  DELETE ?path=...       → delete file/dir
 */
import { ok, fail, requireUser, originCheck, readJson } from "@/lib/api";
import {
  listFiles,
  readFileContent,
  writeFileContent,
  makeDir,
  deletePath,
  FileOpError,
  RuntimeOfflineError,
} from "@/lib/bot-fs";
import { db } from "@/lib/db";
import { fileWriteSchema, fileMkdirSchema, zodErrorMessage } from "@/lib/validation";

async function ownedBot(botId: string, userId: string, role: string) {
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(botId)) return null;
  const bot = await db.bot.findUnique({ where: { id: botId } });
  if (!bot) return null;
  if (bot.userId !== userId && role !== "ADMIN") return null;
  return bot;
}

function opError(err: unknown): NextResponseError {
  if (err instanceof RuntimeOfflineError) {
    return fail(503, "runtime_unavailable", {
      detail: "The bot runtime service is not reachable, so file operations are unavailable right now.",
    }) as NextResponseError;
  }
  const msg = err instanceof FileOpError ? err.message : err instanceof Error ? err.message : "file_error";
  return fail(400, "file_error", { detail: msg }) as NextResponseError;
}
type NextResponseError = ReturnType<typeof fail>;

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  const bot = await ownedBot(id, auth.user.id, auth.user.role);
  if (!bot) return fail(404, "bot_not_found");

  const url = new URL(req.url);
  const relPath = url.searchParams.get("path") ?? "";
  const wantsRead = url.searchParams.get("read") === "1";

  try {
    if (wantsRead) {
      const file = await readFileContent(id, relPath);
      return ok({ file });
    }
    return ok({ entries: await listFiles(id, relPath) });
  } catch (err) {
    return opError(err);
  }
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  const bot = await ownedBot(id, auth.user.id, auth.user.role);
  if (!bot) return fail(404, "bot_not_found");

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = fileWriteSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));

  try {
    await writeFileContent(id, parsed.data.path, parsed.data.content);
    return ok({ ok: true });
  } catch (err) {
    return opError(err);
  }
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  const bot = await ownedBot(id, auth.user.id, auth.user.role);
  if (!bot) return fail(404, "bot_not_found");

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = fileMkdirSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));

  try {
    await makeDir(id, parsed.data.path);
    return ok({ ok: true });
  } catch (err) {
    return opError(err);
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  const bot = await ownedBot(id, auth.user.id, auth.user.role);
  if (!bot) return fail(404, "bot_not_found");

  const url = new URL(req.url);
  const relPath = url.searchParams.get("path") ?? "";
  if (!relPath) return fail(400, "path_required");

  try {
    await deletePath(id, relPath);
    return ok({ ok: true });
  } catch (err) {
    return opError(err);
  }
}
