/**
 * Bot environment variables: secret values are encrypted at rest and NEVER
 * returned to the client after saving (only masked previews for secret rows
 * the user has not chosen to expose... secrets stay masked, period).
 *  GET           → list (masked values)
 *  PUT {key,...} → upsert one var
 *  DELETE ?key=  → delete one var
 * Changes take effect on the next deploy/restart.
 */
import { ok, fail, requireUser, originCheck, readJson } from "@/lib/api";
import { db } from "@/lib/db";
import { encryptSecret } from "@/lib/crypto";
import { envVarSchema, zodErrorMessage } from "@/lib/validation";
import { audit } from "@/lib/audit";
import { reqCtx } from "@/lib/api";

async function ownedBot(botId: string, userId: string, role: string) {
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(botId)) return null;
  const bot = await db.bot.findUnique({ where: { id: botId } });
  if (!bot) return null;
  if (bot.userId !== userId && role !== "ADMIN") return null;
  return bot;
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  const bot = await ownedBot(id, auth.user.id, auth.user.role);
  if (!bot) return fail(404, "bot_not_found");

  const rows = await db.envVar.findMany({ where: { botId: id }, orderBy: { key: "asc" } });
  return ok({
    vars: rows.map((r) => ({
      key: r.key,
      isSecret: r.isSecret,
      // masked preview: first 2 chars only for non-secrets; secrets fully masked
      preview: r.isSecret ? "••••••••" : `${r.key} is stored (value hidden; edit to replace)`,
      updatedAt: r.updatedAt,
    })),
    note: "Secret values are encrypted at rest and cannot be viewed after saving. Restart or redeploy the bot to apply changes.",
  });
}

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  const bot = await ownedBot(id, auth.user.id, auth.user.role);
  if (!bot) return fail(404, "bot_not_found");
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = envVarSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const { key, value, isSecret } = parsed.data;

  const count = await db.envVar.count({ where: { botId: id } });
  if (count >= 64) return fail(403, "too_many_vars", { detail: "Up to 64 environment variables per bot." });

  await db.envVar.upsert({
    where: { botId_key: { botId: id, key } },
    update: { valueEnc: encryptSecret(value), isSecret },
    create: { botId: id, key, valueEnc: encryptSecret(value), isSecret },
  });

  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "BOT_ENV_SET", targetType: "bot", targetId: id, detail: { key, isSecret }, ip, userAgent });
  return ok({ ok: true, key, note: "Saved (encrypted). Restart or redeploy the bot to apply." });
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  const bot = await ownedBot(id, auth.user.id, auth.user.role);
  if (!bot) return fail(404, "bot_not_found");
  const { ip, userAgent } = reqCtx(req);

  const url = new URL(req.url);
  const key = url.searchParams.get("key") ?? "";
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) return fail(400, "invalid_key");

  await db.envVar.deleteMany({ where: { botId: id, key } });
  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "BOT_ENV_DELETE", targetType: "bot", targetId: id, detail: { key }, ip, userAgent });
  return ok({ ok: true, key });
}
