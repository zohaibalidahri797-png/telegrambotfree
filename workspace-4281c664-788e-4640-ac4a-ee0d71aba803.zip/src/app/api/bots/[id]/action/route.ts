import { ok, fail, requireUser, originCheck, reqCtx, readJson } from "@/lib/api";
import { botActionSchema, zodErrorMessage } from "@/lib/validation";
import { deployBot, startBot, stopBot, restartBot } from "@/lib/bot-lifecycle";

/**
 * POST /api/bots/:id/action { action: start | stop | restart | deploy }
 * Deploy runs the full BUILD → START pipeline against the runtime service and
 * can take minutes for dependency installation. The result reflects what the
 * runtime actually reported — never a fabricated success.
 */
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { id } = await params;
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(id)) return fail(400, "invalid_id");
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = botActionSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const { action } = parsed.data;

  const ctx = { actorId: auth.user.id, actorEmail: auth.user.email, ip, userAgent };

  let result;
  switch (action) {
    case "deploy":
      result = await deployBot(id, ctx);
      break;
    case "start":
      result = await startBot(id, ctx);
      break;
    case "stop":
      result = await stopBot(id, ctx);
      break;
    case "restart":
      result = await restartBot(id, ctx);
      break;
    default:
      return fail(400, "unsupported_action");
  }

  if (!result.ok) {
    return ok(
      { ok: false, error: result.error, detail: result.detail, ...(result.data ?? {}) },
      { status: result.status },
    );
  }
  return ok({ ok: true, ...(result.data ?? {}) }, { status: result.status });
}
