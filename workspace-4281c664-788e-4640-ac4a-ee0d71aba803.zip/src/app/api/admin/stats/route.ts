/** GET /api/admin/stats — platform overview with REAL counts and runtime metrics. */
import { ok, requireAdmin } from "@/lib/api";
import { db } from "@/lib/db";
import { runtimeClient, isRuntimeUnavailable } from "@/lib/runtime-client";

export async function GET() {
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;

  const since24h = new Date(Date.now() - 24 * 3600_000);

  const [users, verifiedUsers, suspended, botsByStatus, deployments24h, failed24h, broadcasts, emails, auditCount] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { emailVerified: { not: null } } }),
    db.user.count({ where: { status: { in: ["SUSPENDED", "BANNED"] } } }),
    db.bot.groupBy({ by: ["status"], _count: { _all: true } }),
    db.deployment.count({ where: { createdAt: { gte: since24h } } }),
    db.deployment.count({ where: { createdAt: { gte: since24h }, status: "FAILED" } }),
    db.broadcast.count(),
    db.emailLog.groupBy({ by: ["status"], _count: { _all: true } }),
    db.auditLog.count(),
  ]);

  let runtime: Record<string, unknown> | null = null;
  let runtimeError: string | null = null;
  try {
    const health = await runtimeClient.health(3000);
    let metrics: { bots?: Array<Record<string, unknown>> } = {};
    try {
      const raw = await runtimeClient.metrics();
      metrics = { bots: (raw.bots ?? []) as Array<Record<string, unknown>> };
    } catch {
      // metrics optional
    }
    runtime = { health, bots: metrics.bots ?? [] };
  } catch (err) {
    runtimeError = isRuntimeUnavailable(err) ? "runtime_unavailable" : String(err);
  }

  return ok({
    users: { total: users, verified: verifiedUsers, suspendedOrBanned: suspended },
    bots: Object.fromEntries(botsByStatus.map((b) => [b.status, b._count._all])),
    deployments: { last24h: deployments24h, failedLast24h: failed24h },
    broadcasts,
    emails: Object.fromEntries(emails.map((e) => [e.status, e._count._all])),
    auditLogEntries: auditCount,
    runtime,
    runtimeError,
  });
}
