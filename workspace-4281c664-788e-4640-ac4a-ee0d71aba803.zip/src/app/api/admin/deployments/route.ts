/** GET /api/admin/deployments — recent deployments across the platform (admin). */
import { ok, requireAdmin } from "@/lib/api";
import { db } from "@/lib/db";

export async function GET(req: Request) {
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const url = new URL(req.url);
  const status = url.searchParams.get("status");
  const take = Math.min(Number(url.searchParams.get("take") ?? "50") || 50, 100);

  const deployments = await db.deployment.findMany({
    where: status ? { status } : {},
    orderBy: { createdAt: "desc" },
    take,
    include: { bot: { select: { name: true, runtime: true, user: { select: { email: true } } } } },
  });
  return ok({
    deployments: deployments.map((d) => ({
      id: d.id,
      number: d.number,
      status: d.status,
      error: d.error,
      sourceType: d.sourceType,
      triggeredBy: d.triggeredBy,
      createdAt: d.createdAt,
      finishedAt: d.finishedAt,
      botName: d.bot.name,
      runtime: d.bot.runtime,
      ownerEmail: d.bot.user.email,
    })),
  });
}
