/**
 * Admin user management (server-enforced ADMIN role).
 *  GET   ?q=&page=       → user list with bot counts
 *  PATCH { userId, ... } → role/status/emailVerified changes (audited)
 */
import { ok, fail, requireAdmin, originCheck, reqCtx, readJson } from "@/lib/api";
import { db } from "@/lib/db";
import { adminUserUpdateSchema, zodErrorMessage } from "@/lib/validation";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/notify";

export async function GET(req: Request) {
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const url = new URL(req.url);
  const q = (url.searchParams.get("q") ?? "").trim().toLowerCase();
  const page = Math.max(1, Number(url.searchParams.get("page") ?? "1") || 1);
  const pageSize = 25;

  const where = q
    ? {
        OR: [{ email: { contains: q } }, { name: { contains: q } }],
      }
    : {};

  const [total, users] = await Promise.all([
    db.user.count({ where }),
    db.user.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        status: true,
        emailVerified: true,
        suspensionReason: true,
        createdAt: true,
        _count: { select: { bots: true } },
        subscription: { select: { planId: true, status: true } },
      },
    }),
  ]);

  return ok({ users, total, page, pageSize, pages: Math.ceil(total / pageSize) });
}

export async function PATCH(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  const userId = typeof body?.userId === "string" ? body.userId : "";
  if (!/^[a-zA-Z0-9_-]{1,64}$/.test(userId)) return fail(400, "invalid_user_id");

  const parsed = adminUserUpdateSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const { role, status, suspensionReason, emailVerified } = parsed.data;

  const target = await db.user.findUnique({ where: { id: userId } });
  if (!target) return fail(404, "user_not_found");

  // Guard: an admin cannot demote/ban themselves (avoid lockout).
  if (target.id === auth.user.id && (role === "USER" || (status && status !== "ACTIVE"))) {
    return fail(400, "self_demotion_forbidden", { detail: "You cannot change your own role or suspend your own account." });
  }
  // Guard: last remaining admin cannot be demoted.
  if (target.role === "ADMIN" && role === "USER") {
    const admins = await db.user.count({ where: { role: "ADMIN", status: "ACTIVE" } });
    if (admins <= 1) return fail(400, "last_admin", { detail: "There must be at least one active administrator." });
  }

  const updated = await db.user.update({
    where: { id: userId },
    data: {
      ...(role !== undefined ? { role } : {}),
      ...(status !== undefined ? { status, ...(status === "ACTIVE" ? { suspensionReason: null } : { suspensionReason: suspensionReason ?? "Policy violation" }) } : {}),
      ...(emailVerified !== undefined ? { emailVerified: emailVerified ? (target.emailVerified ?? new Date()) : null } : {}),
    },
  });

  await audit({
    actorId: auth.user.id,
    actorEmail: auth.user.email,
    action: "ADMIN_USER_UPDATE",
    targetType: "user",
    targetId: userId,
    detail: { role, status, emailVerified },
    ip,
    userAgent,
  });

  if (status === "SUSPENDED" || status === "BANNED") {
    await notify(userId, {
      title: `Account ${status.toLowerCase()}`,
      body: updated.suspensionReason ?? "Your account status changed. Contact support for details.",
      level: "ERROR",
      category: "SECURITY",
    });
  }
  if (emailVerified === true && !target.emailVerified) {
    await notify(userId, {
      title: "Email verified by an administrator",
      body: "Your email address is now verified. You can deploy bots.",
      level: "SUCCESS",
      category: "SECURITY",
    });
  }

  return ok({ ok: true, user: { id: updated.id, role: updated.role, status: updated.status, emailVerified: updated.emailVerified } });
}
