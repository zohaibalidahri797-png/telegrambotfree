/**
 * Platform settings (admin): GET current merged settings; PUT partial updates.
 * Settings are data (PlatformSetting rows) — registration toggles, maintenance
 * mode, monetization/ads configuration switches, support contacts.
 */
import { ok, fail, requireAdmin, originCheck, reqCtx, readJson } from "@/lib/api";
import { db } from "@/lib/db";
import { settingsSchema, zodErrorMessage } from "@/lib/validation";
import { audit } from "@/lib/audit";

const KEYS = [
  "registrationEnabled",
  "maintenanceMode",
  "maintenanceMessage",
  "adsEnabled",
  "adsProviderNote",
  "rewardedAdsEnabled",
  "referralCreditsEnabled",
  "supportEmail",
  "telegramAnnounceChat",
] as const;

async function readSettings(): Promise<Record<string, unknown>> {
  const rows = await db.platformSetting.findMany({ where: { key: { in: [...KEYS] } } });
  const out: Record<string, unknown> = {};
  for (const r of rows) {
    try {
      out[r.key] = JSON.parse(r.value);
    } catch {
      out[r.key] = r.value;
    }
  }
  return out;
}

export async function GET() {
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  return ok({ settings: await readSettings() });
}

export async function PUT(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireAdmin();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = settingsSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));

  const changes: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(parsed.data)) {
    if (v === undefined) continue;
    await db.platformSetting.upsert({ where: { key: k }, update: { value: JSON.stringify(v) }, create: { key: k, value: JSON.stringify(v) } });
    changes[k] = v;
  }

  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "SETTINGS_UPDATE", targetType: "platform", detail: changes, ip, userAgent });
  return ok({ ok: true, settings: await readSettings() });
}
