/**
 * GET /api/health — platform diagnostics.
 *
 * Reports each component INDEPENDENTLY with a clear status:
 *   healthy | unconfigured | unreachable | error
 *
 *   app        — configuration (APP_URL / APP_SECRET presence, never values)
 *   database   — live `SELECT 1` probe + which transport is in use
 *   auth       — session signing readiness + which OAuth providers are set
 *   email      — whether a delivery provider is configured (optional)
 *   runtime    — LIVE ping of the bot runtime service (independent of the DB)
 *
 * A component being down or unconfigured never marks an independent component
 * unhealthy, and no secret values are ever included in the response.
 * Also lazily seeds default plans/settings and nudges the runtime supervisor.
 */
import { ok } from "@/lib/api";
import { dbHealthy } from "@/lib/api";
import { runtimeClient } from "@/lib/runtime-client";
import { isRuntimeEmbedded, resolveRuntimeUrl } from "@/lib/runtime-config";
import { ensureRuntime } from "@/lib/runtime-supervisor";
import { ensureSeed } from "@/lib/seed";
import { buildHealthReport } from "@/lib/platform-health";
import { db } from "@/lib/db";
import { NextResponse } from "next/server";

export async function GET() {
  const dbOk = await dbHealthy();

  // Runtime is probed live — never inferred from "the web server responded".
  const runtimeResolution = resolveRuntimeUrl();
  const ping = { ok: false };
  let runtimeDetail: { version?: string; uptimeSec?: number; activeBots?: number } = {};
  try {
    if (!runtimeResolution.invalid) {
      if (isRuntimeEmbedded()) await ensureRuntime();
      const h = await runtimeClient.health(2500);
      ping.ok = h.ok === true;
      runtimeDetail = {
        ...(h.version ? { version: h.version } : {}),
        ...(h.uptimeSec !== undefined ? { uptimeSec: h.uptimeSec } : {}),
        ...(h.activeBots !== undefined ? { activeBots: h.activeBots } : {}),
      };
    }
  } catch {
    ping.ok = false;
  }

  // Best-effort bootstrap flag (fresh production deployment → first admin
  // needs the setup token). A DB error here must not break the health report.
  let bootstrapRequired = false;
  if (dbOk && process.env.NODE_ENV === "production") {
    try {
      bootstrapRequired = (await db.user.count()) === 0;
    } catch {
      bootstrapRequired = false;
    }
  }

  await ensureSeed().catch(() => undefined);

  const report = buildHealthReport(
    {
      dbOk,
      runtimePing: { ok: ping.ok, ...runtimeDetail },
      ...(runtimeResolution.invalid ? { runtimeConfigError: runtimeResolution.reason } : {}),
      bootstrapRequired,
      runtimeEmbedded: isRuntimeEmbedded(),
      runtimeUrlSource: runtimeResolution.source,
    },
    process.env,
  );

  // Note: the runtime URL itself is intentionally omitted from the response —
  // it can reveal internal infrastructure topology.
  return ok(report);
}

export function POST(): NextResponse {
  return NextResponse.json({ error: "method_not_allowed" }, { status: 405 });
}
