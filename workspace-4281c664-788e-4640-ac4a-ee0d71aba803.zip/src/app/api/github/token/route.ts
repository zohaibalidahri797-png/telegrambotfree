/**
 * GitHub token management.
 *  GET    → status (configured or not, scopes, label) — never returns the token
 *  PUT    → save/replace PAT (encrypted at rest)
 *  DELETE → remove PAT
 */
import { ok, fail, requireUser, originCheck, reqCtx, readJson } from "@/lib/api";
import { saveGithubToken, deleteGithubToken, hasGithubToken, probeScopes } from "@/lib/github";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { z } from "zod";

const putSchema = z.object({ token: z.string().trim().min(20).max(255), label: z.string().trim().max(80).optional() });

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const configured = await hasGithubToken(auth.user.id);
  const row = configured ? await db.githubToken.findFirst({ where: { userId: auth.user.id } }) : null;
  return ok({
    configured,
    label: row?.label ?? null,
    scopes: row?.scopes ?? null,
    note: configured ? "A GitHub token is stored (encrypted). It is never displayed again — replace it to change." : "Add a GitHub Personal Access Token to import repositories. Use a fine-grained token with read-only Contents permission, or a classic token with `public_repo` / `repo`.",
  });
}

export async function PUT(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = putSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, "invalid_token", { detail: "Provide a GitHub token (20–255 chars)." });

  // validate the token against GitHub before storing
  const scopes = await probeScopes(parsed.data.token);
  if (scopes === "" ) {
    // /user succeeded but no scopes header, or token invalid — distinguish:
    const test = await fetch("https://api.github.com/user", {
      headers: { Authorization: `Bearer ${parsed.data.token}`, "User-Agent": "botdock-cloud" },
    }).catch(() => null);
    if (!test || !test.ok) {
      return fail(400, "token_rejected", { detail: "GitHub rejected this token. Check that it is valid and not expired." });
    }
  }

  await saveGithubToken(auth.user.id, parsed.data.token, parsed.data.label ?? "GitHub PAT");
  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "GITHUB_TOKEN_SAVED", detail: { scopes }, ip, userAgent });
  return ok({ ok: true, scopes, note: "Token saved (encrypted at rest)." });
}

export async function DELETE(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);
  await deleteGithubToken(auth.user.id);
  await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "GITHUB_TOKEN_REMOVED", detail: {}, ip, userAgent });
  return ok({ ok: true });
}
