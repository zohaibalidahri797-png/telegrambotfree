/** GET /api/github/repos — list the user's GitHub repositories (requires PAT). */
import { ok, fail, requireUser } from "@/lib/api";
import { listRepos } from "@/lib/github";

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  try {
    const repos = await listRepos(auth.user.id);
    return ok({ repos });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (msg === "no_github_token") return fail(400, "no_github_token", { detail: "Add a GitHub token first (Settings → GitHub)." });
    if (msg.startsWith("github_error_401")) return fail(401, "github_token_invalid", { detail: "GitHub rejected the stored token — it may have expired. Replace it in Settings → GitHub." });
    return fail(502, "github_error", { detail: msg });
  }
}
