/**
 * GET /api/usage — dashboard overview numbers derived ONLY from real records:
 * bot counts by status, deployments today, workspace storage. Free launch:
 * usage is reported as genuine measurements — NO plan-based caps are sent.
 */
import { ok, requireUser } from "@/lib/api";
import { db } from "@/lib/db";
import { getEffectivePlan, deploymentsToday } from "@/lib/plans";
import { workspaceUsageBytes } from "@/lib/bot-fs";
import { RESOURCE_POLICY, CAPACITY_NOTE } from "@/lib/capacity";

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const userId = auth.user.id;

  const [bots, plan, deploysToday, recentDeployments, recentNotifications, usageRecords] = await Promise.all([
    db.bot.findMany({ where: { userId }, select: { id: true, name: true, status: true, runtime: true } }),
    getEffectivePlan(userId),
    deploymentsToday(userId),
    db.deployment.findMany({
      where: { bot: { userId } },
      orderBy: { createdAt: "desc" },
      take: 6,
      include: { bot: { select: { name: true } } },
    }),
    db.notification.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 5 }),
    db.usageRecord.findMany({ where: { userId }, orderBy: { createdAt: "desc" }, take: 50 }),
  ]);

  const statusCounts = bots.reduce<Record<string, number>>((acc, b) => {
    acc[b.status] = (acc[b.status] ?? 0) + 1;
    return acc;
  }, {});

  // real workspace bytes per user's bots (queried from the runtime service;
  // each call falls back to 0 when the runtime is unreachable or the
  // workspace does not exist yet)
  const usageList = await Promise.all(bots.map((b) => workspaceUsageBytes(b.id)));
  const workspaceBytes = usageList.reduce((a, n) => a + n, 0);

  return ok({
    botsTotal: bots.length,
    botsRunning: statusCounts["RUNNING"] ?? 0,
    botsStopped: (statusCounts["STOPPED"] ?? 0) + (statusCounts["CREATED"] ?? 0),
    botsFailed: statusCounts["FAILED"] ?? 0,
    statusCounts,
    plan,
    deploymentsToday: deploysToday,
    storageBytes: workspaceBytes,
    resourcePolicy: {
      memoryMbPerBot: RESOURCE_POLICY.memoryMbPerBot,
      cpuPercent: RESOURCE_POLICY.cpuPercent,
      diskMbPerBot: RESOURCE_POLICY.diskMbPerBot,
    },
    capacityNote: CAPACITY_NOTE,
    bots: bots.map((b) => ({ id: b.id, name: b.name, status: b.status, runtime: b.runtime })),
    recentDeployments: recentDeployments.map((d) => ({
      id: d.id,
      botName: d.bot.name,
      number: d.number,
      status: d.status,
      createdAt: d.createdAt,
      finishedAt: d.finishedAt,
    })),
    recentNotifications,
    deployCount30d: usageRecords.filter((u) => u.kind === "DEPLOYMENT" && Date.now() - u.createdAt.getTime() < 30 * 86400_000).length,
  });
}
