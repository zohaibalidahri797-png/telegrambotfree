import { ok } from "@/lib/api";
import { db } from "@/lib/db";
import { emailProviderStatus, oauthProviderStatus } from "@/lib/platform-health";

/**
 * GET /api/auth/config — tells the client which OAuth providers (and email
 * delivery) are configured, so buttons can fail with a clear configuration
 * message instead of silently doing nothing. Also reports whether the
 * first-administrator setup token is currently required (fresh production
 * deployment), so the register form can show the field.
 *
 * Configuration detection is shared with /api/health via
 * src/lib/platform-health.ts (single source of truth — the two endpoints can
 * never disagree about what is configured).
 */
export async function GET() {
  let bootstrapRequired = false;
  try {
    const isFirstUser = (await db.user.count()) === 0;
    // On any fresh production deployment the FIRST registration must present
    // the operator's one-time setup token — show the field up front (whether
    // or not ADMIN_BOOTSTRAP_TOKEN is already configured; if it is not, the
    // register endpoint refuses with a clearer operator-facing error).
    bootstrapRequired = isFirstUser && process.env.NODE_ENV === "production";
  } catch {
    bootstrapRequired = false;
  }

  const providers = oauthProviderStatus();
  const email = emailProviderStatus();

  return ok({
    google: providers.google,
    githubOAuth: providers.github,
    emailConfigured: email.provider === "resend",
    registrationEnabled: true,
    // Fresh production deployment with no ADMIN_BOOTSTRAP_TOKEN set yet —
    // the operator must complete setup before anyone can register.
    bootstrapRequired,
  });
}
