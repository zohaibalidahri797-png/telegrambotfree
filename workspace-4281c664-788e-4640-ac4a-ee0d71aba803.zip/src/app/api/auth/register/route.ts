import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { ok, fail, originCheck, reqCtx, readJson } from "@/lib/api";
import { registerSchema, zodErrorMessage } from "@/lib/validation";
import { hashPassword, passwordIssues } from "@/lib/password";
import { randomToken, sha256Hex } from "@/lib/crypto";
import { sendEmail, verificationEmail, devLinksEnabled, emailProviderConfigured } from "@/lib/email";
import { rateLimit } from "@/lib/rate-limit";
import { audit } from "@/lib/audit";
import { createSession } from "@/lib/session";
import { ensureSeed } from "@/lib/seed";
import {
  ADMIN_BOOTSTRAP_KEY,
  bootstrapEnforced,
  bootstrapTokenValid,
  isUniqueViolation,
} from "@/lib/admin-bootstrap";

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;

  const { ip, userAgent } = reqCtx(req);
  const rl = await rateLimit(`register:${ip}`, 5, 3600);
  if (!rl.ok) return fail(429, "too_many_attempts", { retryAfterSec: rl.retryAfterSec });

  const body = await readJson<Record<string, unknown>>(req);
  if (!body) return fail(400, "invalid_json");

  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const { name, email, password } = parsed.data;

  const pwIssues = passwordIssues(password);
  if (pwIssues.length > 0) {
    return fail(400, "weak_password", { detail: `Password needs ${pwIssues.join(", ")}.` });
  }

  await ensureSeed().catch(() => undefined);

  // A database that is not reachable (unset/misconfigured DATABASE_URL) must
  // surface as an honest, machine-readable failure — never an empty 500.
  try {
    const regSetting = await db.platformSetting.findUnique({ where: { key: "registrationEnabled" } });
    if (regSetting && regSetting.value === "false") {
      return fail(403, "registration_disabled", { detail: "New registrations are currently disabled by the administrators." });
    }
  } catch {
    return fail(503, "database_unavailable", {
      detail: "The account database is not reachable. An administrator must verify the DATABASE_URL configuration. See /api/health for diagnostics.",
    });
  }

  const existing = await db.user.findUnique({ where: { email } });
  if (existing) {
    return fail(409, "email_already_registered", { detail: "An account with this email already exists. Try signing in or reset your password." });
  }

  // ── First-administrator bootstrap (race-safe, see lib/admin-bootstrap.ts) ──
  // The ADMIN grant is decided by an atomic unique marker row, so concurrent
  // registrations can never produce two admins (or an accidental admin).
  const isFirstUser = (await db.user.count()) === 0;
  let grantAdmin = false;

  if (isFirstUser) {
    if (bootstrapEnforced() && !bootstrapTokenValid(parsed.data.bootstrapToken)) {
      await audit({ actorEmail: email, action: "ADMIN_BOOTSTRAP_DENIED", targetType: "user", detail: { reason: "missing_or_invalid_token" }, ip, userAgent });
      return fail(403, "admin_bootstrap_required", {
        detail: process.env.ADMIN_BOOTSTRAP_TOKEN
          ? "This is a fresh deployment: the FIRST account must include the one-time setup token (ADMIN_BOOTSTRAP_TOKEN) to become the administrator. Register without normal privileges is not possible until setup is complete."
          : "This deployment is not fully set up yet: the operator must configure ADMIN_BOOTSTRAP_TOKEN (one-time setup token) before the first administrator account can be created.",
      });
    }
    grantAdmin = true;
  }

  const passwordHash = await hashPassword(password);
  const baseData = { email, name, passwordHash };

  let user;
  if (grantAdmin) {
    try {
      user = await db.$transaction(async (tx) => {
        const created = await tx.user.create({ data: { ...baseData, role: "ADMIN" } });
        // Atomic guard: unique key ⇒ only ONE bootstrap can ever succeed.
        await tx.platformSetting.create({
          data: { key: ADMIN_BOOTSTRAP_KEY, value: JSON.stringify({ userId: created.id, at: new Date().toISOString() }) },
        });
        return created;
      });
    } catch (err) {
      if (!isUniqueViolation(err)) throw err;
      // Lost the bootstrap race (another registration became admin first).
      user = await db.user.create({ data: { ...baseData, role: "USER" } });
      grantAdmin = false;
    }
  } else {
    user = await db.user.create({ data: { ...baseData, role: "USER" } });
  }

  if (grantAdmin) {
    await audit({ actorId: user.id, actorEmail: email, action: "FIRST_USER_ADMIN", targetType: "user", targetId: user.id, detail: { via: "bootstrap" }, ip, userAgent });
  }

  // Assign default (free) plan
  try {
    await db.subscription.create({
      data: { userId: user.id, planId: "free", provider: "NONE" },
    });
  } catch {
    // plan row may not exist yet on a fresh DB — seed and retry once
    await ensureSeed().catch(() => undefined);
    await db.subscription.create({ data: { userId: user.id, planId: "free", provider: "NONE" } }).catch(() => undefined);
  }

  // Email verification token (24h)
  const raw = randomToken(32);
  await db.verificationToken.create({
    data: { email, tokenHash: sha256Hex(raw), type: "EMAIL_VERIFY", expiresAt: new Date(Date.now() + 24 * 3600_000) },
  });

  const mail = verificationEmail(name, raw);
  const sent = await sendEmail({ to: email, subject: mail.subject, text: mail.text, html: mail.html, template: "verify_email", userId: user.id });

  await audit({ actorId: user.id, actorEmail: email, action: "USER_REGISTER", targetType: "user", targetId: user.id, detail: { firstUser: grantAdmin, emailProvider: sent.provider }, ip, userAgent });

  const response: Record<string, unknown> = {
    ok: true,
    user: { id: user.id, email: user.email, name: user.name, role: user.role },
    emailDelivery: {
      configured: emailProviderConfigured(),
      delivered: sent.delivered,
      note: sent.delivered
        ? "A verification email is on its way. Check your inbox."
        : "Email delivery is not configured on this deployment, so the verification email could NOT be sent. An administrator can verify your account from the admin panel.",
    },
  };

  // Auto sign-in: registration creates a session so the new user lands in
  // their dashboard (with the "verify your email" banner) instead of hitting
  // a dead end. Email verification is still REQUIRED before deploying.
  try {
    await createSession({ userId: user.id, ip, userAgent });
    response.sessionCreated = true;
  } catch {
    // Session creation must never fail the registration itself.
  }

  if (!sent.delivered && devLinksEnabled()) {
    response.devVerificationLink = `/api/auth/verify-email?token=${raw}`;
    response.devNote = "DEV_SHOW_EMAIL_LINKS is enabled and no email provider is configured — the link is shown here for local testing only.";
  }

  return ok(response, { status: 201 });
}

export function GET() {
  return NextResponse.json({ error: "method_not_allowed" }, { status: 405 });
}
