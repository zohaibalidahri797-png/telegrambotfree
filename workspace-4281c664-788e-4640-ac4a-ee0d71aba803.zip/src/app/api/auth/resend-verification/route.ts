import { db } from "@/lib/db";
import { ok, fail, originCheck, reqCtx } from "@/lib/api";
import { requireUser } from "@/lib/api";
import { randomToken, sha256Hex } from "@/lib/crypto";
import { sendEmail, verificationEmail, devLinksEnabled, emailProviderConfigured } from "@/lib/email";
import { rateLimit } from "@/lib/rate-limit";
import { audit } from "@/lib/audit";

/** POST: resend the verification email for the signed-in user. */
export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { user } = auth;
  const { ip, userAgent } = reqCtx(req);

  const rl = await rateLimit(`resend-verify:${user.id}`, 3, 3600);
  if (!rl.ok) return fail(429, "too_many_attempts", { retryAfterSec: rl.retryAfterSec, detail: "Please wait before requesting another verification email." });

  if (user.emailVerified) {
    return fail(409, "already_verified", { detail: "Your email is already verified." });
  }

  const raw = randomToken(32);
  await db.verificationToken.create({
    data: { email: user.email, tokenHash: sha256Hex(raw), type: "EMAIL_VERIFY", expiresAt: new Date(Date.now() + 24 * 3600_000) },
  });

  const mail = verificationEmail(user.name ?? user.email, raw);
  const sent = await sendEmail({ to: user.email, subject: mail.subject, text: mail.text, html: mail.html, template: "verify_email", userId: user.id });

  await audit({ actorId: user.id, actorEmail: user.email, action: "RESEND_VERIFICATION", detail: { delivered: sent.delivered }, ip, userAgent });

  const response: Record<string, unknown> = {
    ok: true,
    emailDelivery: {
      configured: emailProviderConfigured(),
      delivered: sent.delivered,
      note: sent.delivered ? "Verification email sent." : "Email delivery is not configured on this deployment — the email could NOT be sent.",
    },
  };
  if (!sent.delivered && devLinksEnabled()) {
    response.devVerificationLink = `/api/auth/verify-email?token=${raw}`;
    response.devNote = "DEV_SHOW_EMAIL_LINKS enabled — test-only link shown because no email provider is configured.";
  }
  return ok(response);
}
