import { db } from "@/lib/db";
import { ok, fail, originCheck, reqCtx, readJson } from "@/lib/api";
import { loginSchema, zodErrorMessage } from "@/lib/validation";
import { verifyPassword } from "@/lib/password";
import { createSession } from "@/lib/session";
import { rateLimit } from "@/lib/rate-limit";
import { audit } from "@/lib/audit";

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;

  const { ip, userAgent } = reqCtx(req);
  const body = await readJson<Record<string, unknown>>(req);
  if (!body) return fail(400, "invalid_json");

  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const { email, password } = parsed.data;

  // Brute-force protection: per-IP and per-account limits.
  const ipRl = await rateLimit(`login-ip:${ip}`, 20, 900);
  if (!ipRl.ok) return fail(429, "too_many_attempts", { retryAfterSec: ipRl.retryAfterSec, detail: "Too many sign-in attempts. Try again later." });
  const acctRl = await rateLimit(`login-acct:${email}`, 8, 900);
  if (!acctRl.ok) return fail(429, "too_many_attempts", { retryAfterSec: acctRl.retryAfterSec, detail: "Too many sign-in attempts for this account. Try again later." });

  // A database that is not reachable (unset/misconfigured DATABASE_URL) must
  // surface as an honest, machine-readable failure — never an empty 500.
  let user: Awaited<ReturnType<typeof db.user.findUnique>> = null;
  try {
    user = await db.user.findUnique({ where: { email } });
  } catch {
    return fail(503, "database_unavailable", {
      detail: "The account database is not reachable. An administrator must verify the DATABASE_URL configuration. See /api/health for diagnostics.",
    });
  }
  const valid = user ? await verifyPassword(password, user.passwordHash) : false;

  if (!user || !valid) {
    await audit({ actorId: user?.id ?? null, actorEmail: email, action: "LOGIN_FAILED", detail: {}, ip, userAgent });
    return fail(401, "invalid_credentials", { detail: "Incorrect email or password." });
  }

  if (user.status === "BANNED") {
    return fail(403, "account_banned", { detail: "This account has been banned. Contact support." });
  }
  if (user.status === "SUSPENDED") {
    return fail(403, "account_suspended", { detail: "This account is suspended. Contact support." });
  }

  await createSession({ userId: user.id, ip, userAgent });
  await audit({ actorId: user.id, actorEmail: email, action: "USER_LOGIN", detail: {}, ip, userAgent });

  return ok({
    ok: true,
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      emailVerified: Boolean(user.emailVerified),
    },
  });
}
