/**
 * OAuth 2.0 start: GET /api/auth/oauth/{google|github}
 * Generates a state token stored in a short-lived httpOnly cookie, then
 * redirects to the provider. If the provider is not configured, returns a
 * clear 501 JSON error (the client shows a configuration notice — never a
 * dead button).
 */
import { NextResponse } from "next/server";
import { randomToken } from "@/lib/crypto";
import { fail, reqCtx } from "@/lib/api";
import { audit } from "@/lib/audit";

const OAUTH_COOKIE = "bd_oauth_state";
const STATE_TTL_SEC = 600;

function appUrl(): string {
  return (process.env.APP_URL ?? "http://localhost:3000").replace(/\/$/, "");
}

export async function GET(req: Request, { params }: { params: Promise<{ provider: string }> }) {
  const { provider } = await params;
  const { ip, userAgent } = reqCtx(req);

  if (provider !== "google" && provider !== "github") {
    return fail(404, "unknown_provider");
  }

  const clientId =
    provider === "google" ? process.env.GOOGLE_CLIENT_ID : process.env.GITHUB_CLIENT_ID;
  const clientSecret =
    provider === "google" ? process.env.GOOGLE_CLIENT_SECRET : process.env.GITHUB_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    return fail(501, "oauth_not_configured", {
      detail: `${provider} sign-in is not configured on this deployment. An administrator must set ${provider === "google" ? "GOOGLE_CLIENT_ID/GOOGLE_CLIENT_SECRET" : "GITHUB_CLIENT_ID/GITHUB_CLIENT_SECRET"} in the environment. See docs/SETUP.md.`,
    });
  }

  const state = randomToken(32);
  const redirectUri = `${appUrl()}/api/auth/oauth/${provider}/callback`;

  let authorizeUrl: string;
  if (provider === "google") {
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: "code",
      scope: "openid email profile",
      state,
      access_type: "offline",
      prompt: "select_account",
    });
    authorizeUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  } else {
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      scope: "read:user user:emails",
      state,
      allow_signup: "true",
    });
    authorizeUrl = `https://github.com/login/oauth/authorize?${params.toString()}`;
  }

  await audit({ action: "OAUTH_START", actorEmail: null, detail: { provider }, ip, userAgent }).catch(() => undefined);

  const res = NextResponse.redirect(authorizeUrl, { status: 302 });
  res.cookies.set(OAUTH_COOKIE, `${provider}:${state}`, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: STATE_TTL_SEC,
  });
  return res;
}
