import { db } from "@/lib/db";
import { ok, fail, originCheck, reqCtx, readJson } from "@/lib/api";
import { passwordIssues } from "@/lib/password";
import { hashPassword } from "@/lib/password";
import { sha256Hex } from "@/lib/crypto";
import { rateLimit } from "@/lib/rate-limit";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/notify";
import { revokeAllUserSessions } from "@/lib/session";

/** POST /api/auth/reset-password { token, password } */
export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const { ip, userAgent } = reqCtx(req);

  const rl = await rateLimit(`reset:${ip}`, 10, 3600);
  if (!rl.ok) return fail(429, "too_many_attempts", { retryAfterSec: rl.retryAfterSec });

  const body = await readJson<Record<string, unknown>>(req);
  const token = typeof body?.token === "string" ? body.token : "";
  const password = typeof body?.password === "string" ? body.password : "";

  if (token.length < 32 || !/^[a-f0-9]+$/.test(token)) {
    return fail(400, "invalid_token", { detail: "This reset link is malformed." });
  }
  const issues = passwordIssues(password);
  if (issues.length > 0) {
    return fail(400, "weak_password", { detail: `Password needs ${issues.join(", ")}.` });
  }

  const row = await db.verificationToken.findUnique({ where: { tokenHash: sha256Hex(token) } });
  if (!row || row.type !== "PASSWORD_RESET" || row.usedAt || row.expiresAt.getTime() < Date.now()) {
    return fail(400, "invalid_or_expired_token", { detail: "This reset link is invalid, already used, or expired. Request a new one." });
  }

  const user = await db.user.findUnique({ where: { email: row.email } });
  if (!user) return fail(400, "user_not_found");

  const passwordHash = await hashPassword(password);
  await db.$transaction([
    db.verificationToken.update({ where: { id: row.id }, data: { usedAt: new Date() } }),
    db.user.update({ where: { id: user.id }, data: { passwordHash } }),
  ]);

  // Security: a password change revokes every existing session.
  await revokeAllUserSessions(user.id);
  await audit({ actorId: user.id, actorEmail: user.email, action: "PASSWORD_RESET_COMPLETED", detail: {}, ip, userAgent });
  await notify(user.id, {
    title: "Password changed",
    body: "Your password was reset. All sessions were signed out. If this wasn't you, contact support immediately.",
    level: "WARNING",
    category: "SECURITY",
  });

  return ok({ ok: true, detail: "Password updated. Sign in with your new password." });
}
