import { db } from "@/lib/db";
import { ok, fail, originCheck, reqCtx, readJson } from "@/lib/api";
import { emailSchema, zodErrorMessage } from "@/lib/validation";
import { randomToken, sha256Hex } from "@/lib/crypto";
import { sendEmail, passwordResetEmail, devLinksEnabled } from "@/lib/email";
import { rateLimit } from "@/lib/rate-limit";
import { audit } from "@/lib/audit";

/**
 * POST /api/auth/forgot-password { email }
 * Always returns ok:true (does not reveal whether the account exists).
 * If the account exists, a reset link valid for 1 hour is emailed.
 */
export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const { ip, userAgent } = reqCtx(req);

  const rl = await rateLimit(`forgot:${ip}`, 5, 3600);
  if (!rl.ok) return fail(429, "too_many_attempts", { retryAfterSec: rl.retryAfterSec });

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = emailSchema.safeParse(body?.email);
  if (!parsed.success) return fail(400, zodErrorMessage(parsed.error));
  const email = parsed.data;

  const user = await db.user.findUnique({ where: { email } });
  let devLink: string | undefined;

  if (user) {
    const raw = randomToken(32);
    await db.verificationToken.create({
      data: { email, tokenHash: sha256Hex(raw), type: "PASSWORD_RESET", expiresAt: new Date(Date.now() + 3600_000) },
    });
    const mail = passwordResetEmail(user.name ?? email, raw);
    const sent = await sendEmail({ to: email, subject: mail.subject, text: mail.text, html: mail.html, template: "password_reset", userId: user.id });
    await audit({ actorId: user.id, actorEmail: email, action: "PASSWORD_RESET_REQUESTED", detail: { delivered: sent.delivered }, ip, userAgent });
    if (!sent.delivered && devLinksEnabled()) {
      devLink = `/api/auth/reset-password?token=${raw}`;
    }
  } else {
    await audit({ action: "PASSWORD_RESET_UNKNOWN_EMAIL", actorEmail: email, detail: {}, ip, userAgent });
  }

  const response: Record<string, unknown> = {
    ok: true,
    detail: "If an account with that email exists, a password reset link has been generated. Check your inbox — and if delivery is not configured on this deployment, contact an administrator.",
  };
  if (devLink) {
    response.devResetLink = devLink;
    response.devNote = "DEV_SHOW_EMAIL_LINKS enabled — test-only link shown because no email provider is configured.";
  }
  return ok(response);
}
