import { ok, requireUser, fail } from "@/lib/api";
import { db } from "@/lib/db";
import { getEffectivePlan } from "@/lib/plans";
import { formatUsd } from "@/lib/plans";
import { emailProviderConfigured } from "@/lib/email";

/** GET /api/auth/me — current user + plan summary for the SPA shell. */
export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const user = auth.user;

  const plan = await getEffectivePlan(user.id);
  const unread = await db.notification.count({ where: { userId: user.id, readAt: null } });

  return ok({
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      status: user.status,
      emailVerified: user.emailVerified !== null,
      image: user.image,
    },
    plan: {
      id: plan.planId,
      name: plan.planName,
      priceLabel: formatUsd(plan.priceMonthly),
      status: plan.status,
      limits: plan.limits,
    },
    emailConfigured: emailProviderConfigured(),
    unreadNotifications: unread,
  });
}

export function POST() {
  return fail(405, "method_not_allowed");
}
