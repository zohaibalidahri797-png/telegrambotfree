/**
 * Subscription management.
 *  GET  → current subscription + billing history
 *  POST { planId, billingCycle } → request a plan change.
 *
 * Payment policy (honest by design):
 *  - STRIPE_SECRET_KEY set  → a real Stripe Checkout Session is created via the
 *    Stripe REST API; the subscription only changes after the signed webhook
 *    confirms payment (see /api/billing/webhook).
 *  - otherwise (MANUAL mode) → a PENDING change request is recorded and an
 *    admin applies it; nothing is ever marked paid without a verified payment.
 */
import { ok, fail, requireUser, originCheck, reqCtx, readJson } from "@/lib/api";
import { db } from "@/lib/db";
import { getEffectivePlan, formatUsd } from "@/lib/plans";
import { audit } from "@/lib/audit";
import { notify } from "@/lib/notify";
import { monetizationEnabled, FREE_LAUNCH_NOTE } from "@/lib/monetization";
import { z } from "zod";

const changeSchema = z.object({
  planId: z.string().trim().min(1).max(40),
  billingCycle: z.enum(["MONTHLY", "YEARLY"]).default("MONTHLY"),
});

export async function GET() {
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const plan = await getEffectivePlan(auth.user.id);
  const payments = await db.payment.findMany({
    where: { userId: auth.user.id },
    orderBy: { createdAt: "desc" },
    take: 30,
  });
  return ok({
    plan,
    payments: payments.map((p) => ({
      id: p.id,
      amount: p.amount,
      amountLabel: formatUsd(p.amount),
      currency: p.currency,
      status: p.status,
      provider: p.provider,
      description: p.description,
      createdAt: p.createdAt,
    })),
  });
}

export async function POST(req: Request) {
  const csrf = originCheck(req);
  if (csrf) return csrf;
  const auth = await requireUser();
  if ("response" in auth) return auth.response;
  const { ip, userAgent } = reqCtx(req);

  // FREE-FIRST LAUNCH: checkout is disabled. Every eligible user is already on
  // the free plan; there is nothing to buy. Billing code below stays dormant
  // for future monetization (see docs/SETUP.md).
  if (!monetizationEnabled()) {
    await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "CHECKOUT_BLOCKED_FREE_LAUNCH", ip, userAgent });
    return fail(501, "free_only_launch", { detail: FREE_LAUNCH_NOTE });
  }

  const body = await readJson<Record<string, unknown>>(req);
  const parsed = changeSchema.safeParse(body ?? {});
  if (!parsed.success) return fail(400, "invalid_request", { detail: "planId and billingCycle are required." });
  const { planId, billingCycle } = parsed.data;

  const target = await db.plan.findUnique({ where: { id: planId } });
  if (!target || !target.isActive) return fail(404, "plan_not_found");

  const stripeConfigured = Boolean(process.env.STRIPE_SECRET_KEY);

  if (!stripeConfigured) {
    // MANUAL mode — record the request (audit + notification); an admin applies
    // it via the admin panel. No Payment row: nothing was paid.
    await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "PLAN_CHANGE_REQUESTED", targetType: "plan", targetId: planId, detail: { billingCycle, mode: "manual" }, ip, userAgent });
    await notify(auth.user.id, {
      title: "Plan change requested",
      body: `Your request to move to the ${target.name} plan was recorded. An administrator will review and apply it — nothing has been charged.`,
      level: "INFO",
      category: "BILLING",
    });
    return ok({
      ok: true,
      mode: "manual",
      detail: "Online payments are not configured on this deployment. Your plan change was recorded as a request — an administrator will apply it. Nothing was charged.",
    });
  }

  // Stripe Checkout via REST API (no SDK dependency).
  const origin = process.env.APP_URL?.replace(/\/$/, "") ?? new URL(req.url).origin;
  const amount = billingCycle === "YEARLY" ? target.priceYearly : target.priceMonthly;
  if (amount === 0) {
    return fail(400, "free_plan", { detail: "The Free plan needs no checkout. Contact support if you want to switch back to Free." });
  }
  try {
    const form = new URLSearchParams();
    form.set("mode", "subscription");
    form.set("success_url", `${origin}/#/billing?checkout=success`);
    form.set("cancel_url", `${origin}/#/billing?checkout=cancelled`);
    form.set("client_reference_id", auth.user.id);
    form.set("customer_email", auth.user.email);
    form.set("line_items[0][quantity]", "1");
    form.set("line_items[0][price_data][currency]", "usd");
    form.set("line_items[0][price_data][unit_amount]", String(amount));
    form.set("line_items[0][price_data][recurring][interval]", billingCycle === "YEARLY" ? "year" : "month");
    form.set("line_items[0][price_data][product_data][name]", `BotDock Cloud — ${target.name} plan`);
    form.set("metadata[planId]", planId);
    form.set("metadata[userId]", auth.user.id);
    form.set("metadata[billingCycle]", billingCycle);

    const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.STRIPE_SECRET_KEY}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: form.toString(),
    });
    const data = (await res.json().catch(() => ({}))) as { url?: string; id?: string; error?: { message?: string } };
    if (!res.ok || !data.url) {
      const msg = data.error?.message ?? `stripe_http_${res.status}`;
      await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "CHECKOUT_FAILED", detail: { error: msg }, ip, userAgent });
      return fail(502, "checkout_failed", { detail: `Stripe rejected the checkout session: ${msg}` });
    }
    await db.payment.create({
      data: {
        userId: auth.user.id,
        amount,
        status: "PENDING",
        provider: "STRIPE",
        providerRef: data.id ?? null,
        description: `Checkout session for ${target.name} (${billingCycle.toLowerCase()})`,
      },
    });
    await audit({ actorId: auth.user.id, actorEmail: auth.user.email, action: "CHECKOUT_CREATED", targetType: "plan", targetId: planId, detail: { sessionId: data.id }, ip, userAgent });
    return ok({ ok: true, mode: "stripe", checkoutUrl: data.url, detail: "Complete payment on Stripe. Your plan activates only after Stripe's signed webhook confirms it." });
  } catch (err) {
    return fail(502, "checkout_failed", { detail: err instanceof Error ? err.message : String(err) });
  }
}
