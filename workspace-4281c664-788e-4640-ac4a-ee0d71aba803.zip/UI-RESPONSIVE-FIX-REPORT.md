# UI-RESPONSIVE-FIX-REPORT — BotDock Cloud mobile/responsive repair

**Deliverables:** `BotDock-Cloud-Responsive-Fixed.zip` + `BotDock-Cloud-Responsive-Fixed.tar.gz` (identical trees) · **Date:** 2026-10-29 · **Scope:** responsive/layout/accessibility repair only — zero backend, API, schema, or feature changes.

---

## 1. Which frontend actually serves which route (audited first)

| URL | Frontend |
|---|---|
| `/` (landing, auth, dashboard, bots, admin — the SPA) | **React** (`src/components/app/*`, hash router in `AppRoot.tsx`) |
| `/index.html`, `/docs.html`, `/dashboard.html`, … | Legacy **static** frontend under `public/` (also part of the Pages-option deliverable) |

The mobile recording shows the **React landing** (`landing.tsx`), served at `/` for anonymous visitors. The legacy `public/assets/css/style.css` was audited too and was already correct (`clamp()` typography, `auto-fit` grids, `.table-wrap { overflow-x: auto }`, viewport metas) — no changes needed there.

---

## 2. Root causes of the recorded mobile overflow (all confirmed by live measurement)

### Cause A — THE root cause: JSX stripped the terminal's newlines (measured, not guessed)

The hero terminal is a `<pre>` whose five log lines were written as JSX *text lines* separated by source newlines. JSX removes newlines adjacent to tags/text at build time, so the DOM contained **one single unbreakable 200-character line** (verified: `pre.textContent.includes('\n') === false`).

Consequences (measured in the browser at 320px):

- `pre` min-content width = **1455px** (`white-space: pre` never wraps; `overflow-x: auto` on the pre does NOT reduce the min-content contribution its ancestors see).
- The hero grid track stretched to **1457px** → the *entire* hero (heading, badge, paragraph, buttons, stats) was laid out at 1457px on a 320px phone → everything appeared to "overflow the right edge".
- Bonus bug: the terminal never displayed its intended multi-line deploy log on **any** viewport — it was one long scrolling line.

This is exactly why the recording shows the hero heading, buttons and description cut at the right edge.

**Fix:** explicit `{"…\n"}` string literals between log segments (real newlines in the DOM), plus `min-w-0` on both hero grid columns so the track can shrink below the `pre`'s intrinsic width. Longest real line (≈352px) now scrolls *inside* the terminal (`overflow-x-auto`), never pushing the page.

### Cause B — no shrink permission on grid/flex children

Grid items default to `min-width: auto` (content minimum). Combined with Cause A this made the track unshrinkable. Fixed with `min-w-0` at the exact places where children must shrink (hero grid + columns).

### Cause C — heading sized past the smallest viewport

`text-4xl` (36px extrabold) made the unbreakable word "Infrastructure." ≈297px vs 288px available at 320px. Fixed with a smaller mobile step (`text-[2rem]`), `text-balance` and `break-words`; tablet/desktop sizes unchanged (`sm:text-5xl lg:text-[3.4rem]`).

### Cause D — absolutely-positioned status pill wider than the viewport

The floating "status measured from the live process — never fabricated" pill (~330px + `left-6`) extended past 320px screens (clipped by the section's `overflow-hidden`). Fixed: static badge **below** the terminal on phones, floating from `sm:` up, `max-w-full` + natural wrap.

### Cause E — statistics grid forced 3 columns at every width

`grid-cols-3 gap-4 max-w-md` → 61px of inner width per card at 320px. Fixed: horizontal icon+label **rows** below 420px (`grid-cols-1`), compact centered 3-column grid from 420px up (`min-[420px]:grid-cols-3`).

### Cause F — footer brand row could not wrap

`flex items-center gap-6` (logo + copyright ≈344px) overflowed 320px. Fixed with `flex-wrap` + centered mobile layout.

### Cause G — long identifiers could break app pages

Long bot names / file names / paths had no wrap permission in a few flex/table contexts (bot-detail `h1`, files breadcrumb, filename cells, editor dialog title, admin runtime-bot list, dashboard bot cards). Fixed with `min-w-0`, `break-words`, `[overflow-wrap:anywhere]`.

### Safety net (not a masking layer)

`html, body { overflow-x: clip }` added in `globals.css` as a belt-and-braces guard — it creates no scroll container (sticky headers/drawer keep working). Every actual cause above was fixed at its source; nothing relies on clipping.

---

## 3. Files changed and why

| File | Change | Why |
|---|---|---|
| `src/components/app/landing.tsx` | Real `\n` in terminal `pre`; `min-w-0` on hero grid + columns; heading `text-[2rem] … text-balance break-words`; stats rows→3-col at `min-[420px]`; status pill static→floating; full-width CTAs on mobile; footer brand row wraps | Causes A–F (the recorded bugs) |
| `src/app/globals.css` | `overflow-x: clip` on html/body; `scroll-behavior: smooth` behind `prefers-reduced-motion: no-preference`; `overflow-wrap: anywhere` on `pre, code` | Safety net + a11y + long-token wrapping |
| `src/components/app/bot-detail.tsx` | `min-w-0 flex-wrap break-words` on bot title + subtitle; `min-w-0 flex-wrap` on files breadcrumb; `[overflow-wrap:anywhere]` on filename cells; `break-all` on editor dialog path title | Cause G |
| `src/components/app/dashboard.tsx` | `min-w-0` + `break-words` on bot-card name button | Cause G |
| `src/components/app/admin.tsx` | `min-w-0` + `[overflow-wrap:anywhere]` on runtime-bot list values | Cause G |
| `src/components/app/shell.tsx` | Notifications popover `w-[min(20rem,calc(100vw-1.5rem))]` (was fixed `w-80`) | Popover must fit 320px screens |
| `scripts/package-release.sh` | Emits the two `BotDock-Cloud-Responsive-Fixed.*` deliverables (byte-identical validated archives) | Required packaging |
| `src/app/api/download/route.ts` | Allowlist + the two new archive names | Downloadable in-app |
| `UI-RESPONSIVE-FIX-REPORT.md` | This report | Required documentation |

**Not changed:** all application logic, API routes, auth, Prisma schema/migrations, bot runtime, `wrangler.jsonc`, `open-next.config.ts`, env variable names, existing UI features, the legacy `public/` frontend (audited; already correct).

**Repair during verification (sandbox artifacts, unrelated to UI):** the sandbox reset again deleted `src/app/api/bots/upload/route.ts` and `src/app/api/bots/[id]/files/upload/route.ts`, `.open-next/`, and the dev server process. Both routes were restored byte-identical from git (`93d1716`), `.open-next/` rebuilt, server restarted. No application code was altered by this repair.

---

## 4. Responsive tests performed (real browser, real measurements)

Browser: headless Chromium via agent-browser against the running app. Probe: `document.documentElement.scrollWidth > window.innerWidth` (true = unintended horizontal page overflow), plus per-element bounding boxes and `min-content` measurements.

### Landing page — overflow probe (all PASS)

| Viewport | 320 | 360 | 375 | 390 | 414 | 430 | 768 | 1024 | 1280 | 1440 |
|---|---|---|---|---|---|---|---|---|---|---|
| Horizontal overflow | none | none | none | none | none | none | none | none | none | none |

### Element-level checks (320px)

- `h1` width = 288px = container width, wraps to 3 balanced lines, "One Dock." gradient aligned — PASS
- Terminal: 6 real log lines render; longest line scrolls **inside** the card (`scrollWidth > clientWidth` on the pre, page untouched) — PASS
- Status pill below terminal, wraps, inside viewport — PASS
- Stats: 3 readable rows at 320/375/390; compact 3-column grid from 420px — PASS
- CTA buttons full-width and inside viewport — PASS
- Footer logo row wraps, nothing clipped — PASS

### Screenshots captured (before/after)

`tool-results/ui-shots/`: `landing-320.png` (BEFORE — overflow visible), `landing-320-after.png`, `landing-320-term2.png`, `landing-375.png`, `landing-390.png`, `landing-768.png`, `landing-1440.png`, `menu-320-open.png`, `login-375.png`, `register-375.png`, `dashboard-320.png`, `botdetail-320.png`, `botdetail-1440.png`, `admin-1440.png`.

### Interactive + authenticated flows exercised in the browser

- Mobile menu (Sheet) opens/closes at 320px with accessible names; links + buttons reachable — PASS
- Login & register pages at 375px: forms fit, inputs inside cards, no overflow — PASS
- Real registration → email-verify → login → dashboard at 320/375px: stat grid, resource card, mobile topbar all fit — PASS
- Bot create dialog → bot detail at 320px: title, wrapped action buttons, 2-col live stats, wrapping tabs — PASS
- Admin panel at 1440px: sidebar, stat cards, contained tables — PASS
- Bots list / billing / settings / admin at 320px: no overflow — PASS
- Admin users table: contained horizontal-scroll region (`overflow-x-auto` + `min-w-[800px]`) — by construction (same pattern verified in E2E)

*(Test data used for the authenticated walkthrough was deleted afterwards — 0 users / 0 bots remain.)*

### Regression battery (after all changes)

| Check | Result |
|---|---|
| `bunx tsc --noEmit` | **0 errors** |
| `bun run lint` | **clean** |
| `bun test tests/` | **33/33 pass** |
| `bash tests/full-e2e.sh` | **70 PASS / 0 FAIL** (credential-limited items honestly listed by the harness) |
| `tests/worker-route-matrix.sh` (workerd) | **exit 0 — all 12 assertions** |
| `MATRIX_NO_APP_URL=1` variant | **exit 0 — all 12 assertions** |
| `bun run cf:build` | PASS (Worker saved; cf-clean scrub applied) |
| `bun run cf:verify` | RESULT: OK (8 gates) |

### Not run (honest limitations)

- Physical device testing (iOS Safari / Android Chrome on real hardware) — headless Chromium only.
- The final upload to a real Cloudflare account (needs user credentials; build verified to the dry-run boundary).

---

## 5. How to verify after extracting the archive

1. `bun install && cp .env.example .env` (set `APP_SECRET` + `RUNTIME_API_KEY`, see README) → `bun run db:push` → `bun run dev`.
2. Open the site at a phone width (DevTools device toolbar, 320px) — the hero must fit, the terminal shows the multi-line log, nothing scrolls sideways.
3. Full check list: §4 above.
